
#include "stdafx.h"
#include "UART_CRC_16_IBM.h"
#include "math.h"
#include <iostream>
using namespace std;
#define SYNC_init 0x55 
// ��ʼ�� DIO ģ��
void UART_CRC_16_IBM::Init(DIO &UART_CH)
{
	UART_CH.Init();
}

UART_CRC_16_IBM::UART_CRC_16_IBM(double _Trans_Feq)
{
	crcInitial();
	Trans_Feq = _Trans_Feq;
}
UART_CRC_16_IBM::~UART_CRC_16_IBM()
{
//	crcInitial();
}
//void UART_Write_Data_Single_Mode(DIO����, ��ǰsite)��
DWORD UART_CRC_16_IBM::Get_Data_Single_Mode(DIO &UART_CH, int SiteNo)
{
	DWORD reBYTE;
	reBYTE=UART_CH.GetSerialPatternResultWithLabel(SiteNo*2+1, "READ_START", "READ_STOP", LSB);
	//reBYTE = (reBYTE >> 1) & 0xFF;
	reBYTE = (reBYTE >> 2) & 0xFF;
	//reBYTE = (reBYTE >> 3) & 0xFF;
	return 	reBYTE;
}

//void UART_Write_Data_Single_Mode(DIO����, �ӻ���ַ, �Ĵ�����ַ, SITE1 ��������)��
void UART_CRC_16_IBM::UART_Write_Data_Single_Mode(DIO &UART_CH, int address, int regAddress, BYTE data0)
{
	int Pattern_counter = 0;
	//�����һ�����е�pattern
	UART_CH.ClearPattern();
	/*�� synchronization frame (SYNC)�ź� 01010101 (0x55) �̶�����*/
	UART_CH.LoadPatternWithLabel("X0X0X0X0", "SYNC_START");
	for (SIZE_T i = 0; i < 8; i++)
	{
		char str_pattern[50] = "X";
		char str_temp[2] = "X";
		long BIT_TEMP = ceil(pow(2, i));   //����ȡ��2��i����
		int SHOW_BIT = (SYNC_init & BIT_TEMP) >> i;  //SYNC_init 0x55 ��BIT_TEMP 2��i���ݣ��������iλ
		SHOW_BIT += '0';                             //û��������SHOW_BIT����˸�0
		str_temp[0] = char(SHOW_BIT);
		//ƴ��site4
		strcat(str_pattern, str_temp); //"X0" 0��Ϊʾ����������ʵ�ʾ���0
		//ƴ��site3
		strcat(str_pattern, "X"); //"X0X"
		strcat(str_pattern, str_temp); //"X0X0"
		//ƴ��site2
		strcat(str_pattern, "X"); //"X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0"
		//ƴ��site1
		strcat(str_pattern, "X"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
	}
	UART_CH.LoadPatternWithLabel("X1X1X1X1", "SYNC_STOP");
	Pattern_counter += 10;
	//��address ת�� pattern
	UART_CH.LoadPatternWithLabel("X0X0X0X0", "Address_START");
	for (SIZE_T i = 0; i < 8; i++)
	{
		char str_pattern[50] = "X";
		char str_temp[2] = "X";
		long BIT_TEMP = ceil(pow(2, i));
		int SHOW_BIT = (address & BIT_TEMP) >> i;
		SHOW_BIT += '0';
		str_temp[0] = char(SHOW_BIT);
		//ƴ��site4
		strcat(str_pattern, str_temp); //"X0" 0��Ϊʾ����������ʵ�ʾ���0
		//ƴ��site3
		strcat(str_pattern, "X"); //"X0X"
		strcat(str_pattern, str_temp); //"X0X0"
		//ƴ��site2
		strcat(str_pattern, "X"); //"X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0"
		//ƴ��site1
		strcat(str_pattern, "X"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
	}
	UART_CH.LoadPatternWithLabel("X1X1X1X1", "Address_STOP");
	Pattern_counter += 10;
	//��regAddress ת�� pattern
	UART_CH.LoadPatternWithLabel("X0X0X0X0", "RegAddress_START");
	for (SIZE_T i = 0; i < 8; i++)
	{

		char str_pattern[50] = "X";
		char str_temp[2] = "X";
		long BIT_TEMP = ceil(pow(2, i));
		int SHOW_BIT = (regAddress & BIT_TEMP) >> i;
		SHOW_BIT += '0';
		str_temp[0] = char(SHOW_BIT);
		//ƴ��site4
		strcat(str_pattern, str_temp); //"X0" 0��Ϊʾ����������ʵ�ʾ���0
		//ƴ��site3
		strcat(str_pattern, "X"); //"X0X"
		strcat(str_pattern, str_temp); //"X0X0"
		//ƴ��site2
		strcat(str_pattern, "X"); //"X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0"
		//ƴ��site1
		strcat(str_pattern, "X"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
	}
	UART_CH.LoadPatternWithLabel("X1X1X1X1", "RegAddress_STOP");
	Pattern_counter += 10;
	//��DATA ת�� pattern
	UART_CH.LoadPatternWithLabel("X0X0X0X0", "DATA0_START");
	//UART_CH.LoadPatternWithLabel("X0X0X0X0", "DATA0_START");//
	for (SIZE_T i = 0; i < 8; i++)
	{

		char str_pattern[50] = "X";
		char str_temp[2] = "X";
		long BIT_TEMP = ceil(pow(2, i));
		int SHOW_BIT = (data0 & BIT_TEMP) >> i;
		SHOW_BIT += '0';
		str_temp[0] = char(SHOW_BIT);
		//ƴ��site4
		strcat(str_pattern, str_temp); //"X0" 0��Ϊʾ����������ʵ�ʾ���0
		//ƴ��site3
		strcat(str_pattern, "X"); //"X0X"
		strcat(str_pattern, str_temp); //"X0X0"
		//ƴ��site2
		strcat(str_pattern, "X"); //"X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0"
		//ƴ��site1
		strcat(str_pattern, "X"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
	}
	UART_CH.LoadPatternWithLabel("X1X1X1X1", "DATA0_STOP");
	Pattern_counter += 11;///
	/*����CRC*/
	unsigned int sentData[256];
	//SYNC 
	sentData[0] = 0x55;
	//address
	sentData[1] = address;
	//regAddress
	sentData[2] = regAddress;
	//DATA
	sentData[3] = data0;

	int CRC_Value = CRC_LUT(sentData, 4);
	//��CRC ת�� pattern
	UART_CH.LoadPatternWithLabel("X0X0X0X0", "CRC_START");
	for (SIZE_T i = 0; i < 8; i++)
	{
		char str_pattern[10] = "X";
		char str_temp[2] = "X";
		long BIT_TEMP = ceil(pow(2, i));
		int SHOW_BIT = (CRC_Value & BIT_TEMP) >> i;
		SHOW_BIT += '0';
		str_temp[0] = char(SHOW_BIT);
		//ƴ��site4
		strcat(str_pattern, str_temp); //"X0" 0��Ϊʾ����������ʵ�ʾ���0
		//ƴ��site3
		strcat(str_pattern, "X"); //"X0X"
		strcat(str_pattern, str_temp); //"X0X0"
		//ƴ��site2
		strcat(str_pattern, "X"); //"X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0"
		//ƴ��site1
		strcat(str_pattern, "X"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
	}
	UART_CH.LoadPatternWithLabel("X1X1X1X1", "CRC_STOP");
	Pattern_counter += 10;
	//��¼TX �ϻش�������STATUS �� CRC �ض�ֵ
	UART_CH.LoadPatternWithLabel("X1X1X1X1", "REBACK_START");
	for (SIZE_T i = 0; i < 10; i++)
	{
		UART_CH.LoadPatternWithLabel("X1X1X1X1");
	}
	UART_CH.LoadPatternWithLabel("X1X1X1X1");
	UART_CH.LoadPatternWithLabel("X1X1X1X1");
	UART_CH.LoadPatternWithLabel("X1X1X1X1", "REBACK_STOP");
	Pattern_counter += 14;
	UART_CH.RunPatternWithLabel("SYNC_START", "REBACK_STOP");

	delay_ms(long(ceil(1 / Trans_Feq * Pattern_counter * 1000))+1);
}

BYTE  UART_CRC_16_IBM::UART_Read_Data_Single_Mode(DIO &UART_CH, int address, int regAddress)
{
	BYTE UART_CRC_READ;
	int Pattern_counter = 0;
	//�����һ�����е�pattern
	UART_CH.ClearPattern();
	/*�� synchronization frame (SYNC)�ź� 01010101 (0x55) �̶�����*/
	UART_CH.LoadPatternWithLabel("H0H0H0H0", "SYNC_START");
	for (SIZE_T i = 0; i < 8; i++)
	{
		char str_pattern[50] = "H";
		char str_temp[2] = "H";
		long BIT_TEMP = ceil(pow(2, i));
		int SHOW_BIT = (SYNC_init & BIT_TEMP) >> i;
		SHOW_BIT += '0';
		str_temp[0] = char(SHOW_BIT);
		//ƴ��site4
		strcat(str_pattern, str_temp); //"X0" 0��Ϊʾ����������ʵ�ʾ���0
		//ƴ��site3
		strcat(str_pattern, "H"); //"X0X"
		strcat(str_pattern, str_temp); //"X0X0"
		//ƴ��site2
		strcat(str_pattern, "H"); //"X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0"
		//ƴ��site1
		strcat(str_pattern, "H"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
	}
	UART_CH.LoadPatternWithLabel("H1H1H1H1", "SYNC_STOP");
	Pattern_counter += 10;
	//��address ת�� pattern
	UART_CH.LoadPatternWithLabel("H0H0H0H0", "Address_START");
	for (SIZE_T i = 0; i < 8; i++)
	{
		char str_pattern[50] = "H";
		char str_temp[2] = "H";
		long BIT_TEMP = ceil(pow(2, i));
		int SHOW_BIT = (address & BIT_TEMP) >> i;
		SHOW_BIT += '0';
		str_temp[0] = char(SHOW_BIT);
		//ƴ��site4
		strcat(str_pattern, str_temp); //"X0" 0��Ϊʾ����������ʵ�ʾ���0
		//ƴ��site3
		strcat(str_pattern, "H"); //"X0X"
		strcat(str_pattern, str_temp); //"X0X0"
		//ƴ��site2
		strcat(str_pattern, "H"); //"X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0"
		//ƴ��site1
		strcat(str_pattern, "H"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
	}
	UART_CH.LoadPatternWithLabel("H1H1H1H1", "Address_STOP");
	Pattern_counter += 10;
	//��regAddress ת�� pattern
	UART_CH.LoadPatternWithLabel("H0H0H0H0", "RegAddress_START");
	for (SIZE_T i = 0; i < 8; i++)
	{

		char str_pattern[50] = "H";
		char str_temp[2] = "H";
		long BIT_TEMP = ceil(pow(2, i));
		int SHOW_BIT = (regAddress & BIT_TEMP) >> i;
		SHOW_BIT += '0';
		str_temp[0] = char(SHOW_BIT);
		//ƴ��site4
		strcat(str_pattern, str_temp); //"X0" 0��Ϊʾ����������ʵ�ʾ���0
		//ƴ��site3
		strcat(str_pattern, "H"); //"X0X"
		strcat(str_pattern, str_temp); //"X0X0"
		//ƴ��site2
		strcat(str_pattern, "H"); //"X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0"
		//ƴ��site1
		strcat(str_pattern, "H"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
	}
	UART_CH.LoadPatternWithLabel("H1H1H1H1", "RegAddress_STOP");
	Pattern_counter += 10;
	/*����CRC*/
	unsigned int sentData[256];
	//SYNC 
	sentData[0] = 0x55;
	//address
	sentData[1] = address;
	//regAddress
	sentData[2] = regAddress;


	int CRC_Value = CRC_LUT(sentData, 3);
	UART_CRC_READ = CRC_Value;
	//��CRC ת�� pattern
	UART_CH.LoadPatternWithLabel("H0H0H0H0", "CRC_START");
	for (SIZE_T i = 0; i < 8; i++)
	{
		char str_pattern[10] = "H";
		char str_temp[2] = "H";
		long BIT_TEMP = ceil(pow(2, i));
		int SHOW_BIT = (CRC_Value & BIT_TEMP) >> i;
		SHOW_BIT += '0';
		str_temp[0] = char(SHOW_BIT);
		//ƴ��site4
		strcat(str_pattern, str_temp); //"X0" 0��Ϊʾ����������ʵ�ʾ���0
		//ƴ��site3
		strcat(str_pattern, "H"); //"X0X"
		strcat(str_pattern, str_temp); //"X0X0"
		//ƴ��site2
		strcat(str_pattern, "H"); //"X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0"
		//ƴ��site1
		strcat(str_pattern, "H"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
	}
	UART_CH.LoadPatternWithLabel("H1H1H1H1", "CRC_STOP");
	Pattern_counter += 10;
	//��¼TX �ϻش�������STATUS �� CRC �ض�ֵ
	UART_CH.LoadPatternWithLabel("H1H1H1H1", "READ_START");
	for (SIZE_T i = 0; i < 20; i++)
	{
		UART_CH.LoadPatternWithLabel("H1H1H1H1");
	}

	UART_CH.LoadPatternWithLabel("H1H1H1H1", "READ_STOP");
	UART_CH.LoadPatternWithLabel("XXXXXXXX");
	UART_CH.LoadPatternWithLabel("XXXXXXXX", "REBACK_STOP");
	Pattern_counter += 24;
	UART_CH.RunPatternWithLabel("SYNC_START", "REBACK_STOP");

	delay_ms(long(ceil(1 / Trans_Feq * Pattern_counter * 1000)) + 1);
	return UART_CRC_READ;
}
//void UART_Write_Data_Burst_Mode(DIO����, �ӻ���ַ, �Ĵ�����ַ, д�������ֽڵĸ���, SITE1 �������ݵ������׵�ַ)��
void UART_CRC_16_IBM::UART_Write_Data_Burst_Mode(DIO &UART_CH, int address, int regAddress, int writeByteCount, BYTE *data0)
{
	int Pattern_counter = 0;
	//�����һ�����е�pattern
	UART_CH.ClearPattern();
	/*�� synchronization frame (SYNC)�ź� 01010101 (0x55) �̶�����*/
	UART_CH.LoadPatternWithLabel("X0X0X0X0", "SYNC_START");
	for (SIZE_T i = 0; i < 8; i++)
	{
		char str_pattern[50] = "X";
		char str_temp[2] = "X";
		long BIT_TEMP = ceil(pow(2, i));
		int SHOW_BIT = (SYNC_init & BIT_TEMP) >> i;
		SHOW_BIT += '0';
		str_temp[0] = char(SHOW_BIT);
		//ƴ��site4
		strcat(str_pattern, str_temp); //"X0" 0��Ϊʾ����������ʵ�ʾ���0
		//ƴ��site3
		strcat(str_pattern, "X"); //"X0X"
		strcat(str_pattern, str_temp); //"X0X0"
		//ƴ��site2
		strcat(str_pattern, "X"); //"X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0"
		//ƴ��site1
		strcat(str_pattern, "X"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
	}
	UART_CH.LoadPatternWithLabel("X1X1X1X1", "SYNC_STOP");
	Pattern_counter += 20;
	//��address ת�� pattern
	UART_CH.LoadPatternWithLabel("X0X0X0X0", "Address_START");
	for (SIZE_T i = 0; i < 8; i++)
	{
		char str_pattern[50] = "X";
		char str_temp[2] = "X";
		long BIT_TEMP = ceil(pow(2, i));
		int SHOW_BIT = (address & BIT_TEMP) >> i;
		SHOW_BIT += '0';
		str_temp[0] = char(SHOW_BIT);
		//ƴ��site4
		strcat(str_pattern, str_temp); //"X0" 0��Ϊʾ����������ʵ�ʾ���0
		//ƴ��site3
		strcat(str_pattern, "X"); //"X0X"
		strcat(str_pattern, str_temp); //"X0X0"
		//ƴ��site2
		strcat(str_pattern, "X"); //"X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0"
		//ƴ��site1
		strcat(str_pattern, "X"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
	}
	UART_CH.LoadPatternWithLabel("X1X1X1X1", "Address_STOP");
	Pattern_counter += 10;
	//��regAddress ת�� pattern
	UART_CH.LoadPatternWithLabel("X0X0X0X0", "RegAddress_START");
	for (SIZE_T i = 0; i < 8; i++)
	{

		char str_pattern[50] = "X";
		char str_temp[2] = "X";
		long BIT_TEMP = ceil(pow(2, i));
		int SHOW_BIT = (regAddress & BIT_TEMP) >> i;
		SHOW_BIT += '0';
		str_temp[0] = char(SHOW_BIT);
		//ƴ��site4
		strcat(str_pattern, str_temp); //"X0" 0��Ϊʾ����������ʵ�ʾ���0
		//ƴ��site3
		strcat(str_pattern, "X"); //"X0X"
		strcat(str_pattern, str_temp); //"X0X0"
		//ƴ��site2
		strcat(str_pattern, "X"); //"X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0"
		//ƴ��site1
		strcat(str_pattern, "X"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
	}
	UART_CH.LoadPatternWithLabel("X1X1X1X1", "RegAddress_STOP");
	Pattern_counter += 20;
	//��DATA ת�� pattern

	for (SIZE_T i = 0; i < writeByteCount; i++)
	{
		char str1_data_pattern[50] = "DATA";
		char str2_data_pattern[50] = "DATA";
		char str1_data_temp[2] = "X";
		str1_data_temp[0] = i + '0';
		strcat(str1_data_pattern, str1_data_temp);
		strcat(str1_data_pattern, "_START");
		strcat(str2_data_pattern, str1_data_temp);
		strcat(str2_data_pattern, "_STOP");
		UART_CH.LoadPatternWithLabel("X0X0X0X0", str1_data_pattern);
		for (SIZE_T j = 0; j < 8; j++)
		{

			char str_pattern[50] = "X";
			char str_temp[2] = "X";
			long BIT_TEMP = ceil(pow(2, j));
			int SHOW_BIT = (data0[i] & BIT_TEMP) >> j;
			SHOW_BIT += '0';
			str_temp[0] = char(SHOW_BIT);
			//ƴ��site4
			strcat(str_pattern, str_temp); //"X0" 0��Ϊʾ����������ʵ�ʾ���0
			//ƴ��site3
			strcat(str_pattern, "X"); //"X0X"
			strcat(str_pattern, str_temp); //"X0X0"
			//ƴ��site2
			strcat(str_pattern, "X"); //"X0X0X"
			strcat(str_pattern, str_temp); //"X0X0X0"
			//ƴ��site1
			strcat(str_pattern, "X"); //"X0X0X0X"
			strcat(str_pattern, str_temp); //"X0X0X0X0"
			UART_CH.LoadPatternWithLabel(str_pattern);
		}
		UART_CH.LoadPatternWithLabel("X1X1X1X1", str2_data_pattern);
		Pattern_counter += 20;

	}
	
	/*����CRC*/
	unsigned int sentData[256];
	//SYNC 
	sentData[0] = 0x55;
	//address
	sentData[1] = address;
	//regAddress
	sentData[2] = regAddress;
	//DATA
	for (SIZE_T i = 0; i < writeByteCount; i++)
	{
		sentData[3+i] = data0[i];
	}


	int CRC_Value = CRC_LUT(sentData, 3 + writeByteCount);
	//��CRC ת�� pattern
	UART_CH.LoadPatternWithLabel("X0X0X0X0", "CRC_START");
	for (SIZE_T i = 0; i < 8; i++)
	{
		char str_pattern[10] = "X";
		char str_temp[2] = "X";
		long BIT_TEMP = ceil(pow(2, i));
		int SHOW_BIT = (CRC_Value & BIT_TEMP) >> i;
		SHOW_BIT += '0';
		str_temp[0] = char(SHOW_BIT);
		//ƴ��site4
		strcat(str_pattern, str_temp); //"X0" 0��Ϊʾ����������ʵ�ʾ���0
		//ƴ��site3
		strcat(str_pattern, "X"); //"X0X"
		strcat(str_pattern, str_temp); //"X0X0"
		//ƴ��site2
		strcat(str_pattern, "X"); //"X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0"
		//ƴ��site1
		strcat(str_pattern, "X"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
	}
	UART_CH.LoadPatternWithLabel("X1X1X1X1", "CRC_STOP");
	Pattern_counter += 20;
	//��¼TX �ϻش�������STATUS �� CRC �ض�ֵ
	UART_CH.LoadPatternWithLabel("X1X1X1X1", "REBACK_START");
	for (SIZE_T i = 0; i < 10; i++)
	{
		UART_CH.LoadPatternWithLabel("X1X1X1X1");
	}
	UART_CH.LoadPatternWithLabel("X1X1X1X1");
	UART_CH.LoadPatternWithLabel("X1X1X1X1");
	UART_CH.LoadPatternWithLabel("X1X1X1X1", "REBACK_STOP");
	UART_CH.LoadPatternWithLabel("X1X1X1X1");
	UART_CH.LoadPatternWithLabel("X1X1X1X1");
	Pattern_counter += 27;
	UART_CH.RunPatternWithLabel("SYNC_START", "REBACK_STOP");
	delay_ms(long(ceil(1 / Trans_Feq * Pattern_counter * 1000)) + 1);
}
BYTE UART_CRC_16_IBM::UART_Read_Data_Burst_Mode(DIO &UART_CH, int address, int regAddress, int writeByteCount)
{
	BYTE UART_CRC_READ;
	int Pattern_counter = 0;
	//�����һ�����е�pattern
	UART_CH.ClearPattern();
	/*�� synchronization frame (SYNC)�ź� 01010101 (0x55) �̶�����*/
	UART_CH.LoadPatternWithLabel("H0H0H0H0", "SYNC_START");
	for (SIZE_T i = 0; i < 8; i++)
	{
		char str_pattern[50] = "H";
		char str_temp[2] = "H";
		long BIT_TEMP = ceil(pow(2, i));
		int SHOW_BIT = (SYNC_init & BIT_TEMP) >> i;
		SHOW_BIT += '0';
		str_temp[0] = char(SHOW_BIT);
		//ƴ��site4
		strcat(str_pattern, str_temp); //"X0" 0��Ϊʾ����������ʵ�ʾ���0
		//ƴ��site3
		strcat(str_pattern, "H"); //"X0X"
		strcat(str_pattern, str_temp); //"X0X0"
		//ƴ��site2
		strcat(str_pattern, "H"); //"X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0"
		//ƴ��site1
		strcat(str_pattern, "H"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
	}
	UART_CH.LoadPatternWithLabel("H1H1H1H1", "SYNC_STOP");
	Pattern_counter += 20;
	//��address ת�� pattern
	UART_CH.LoadPatternWithLabel("H0H0H0H0", "Address_START");
	for (SIZE_T i = 0; i < 8; i++)
	{
		char str_pattern[50] = "H";
		char str_temp[2] = "H";
		long BIT_TEMP = ceil(pow(2, i));
		int SHOW_BIT = (address & BIT_TEMP) >> i;
		SHOW_BIT += '0';
		str_temp[0] = char(SHOW_BIT);
		//ƴ��site4
		strcat(str_pattern, str_temp); //"X0" 0��Ϊʾ����������ʵ�ʾ���0
		//ƴ��site3
		strcat(str_pattern, "H"); //"X0X"
		strcat(str_pattern, str_temp); //"X0X0"
		//ƴ��site2
		strcat(str_pattern, "H"); //"X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0"
		//ƴ��site1
		strcat(str_pattern, "H"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
	}
	UART_CH.LoadPatternWithLabel("H1H1H1H1", "Address_STOP");
	Pattern_counter += 20;
	//��regAddress ת�� pattern
	UART_CH.LoadPatternWithLabel("H0H0H0H0", "RegAddress_START");
	for (SIZE_T i = 0; i < 8; i++)
	{

		char str_pattern[50] = "H";
		char str_temp[2] = "H";
		long BIT_TEMP = ceil(pow(2, i));
		int SHOW_BIT = (regAddress & BIT_TEMP) >> i;
		SHOW_BIT += '0';
		str_temp[0] = char(SHOW_BIT);
		//ƴ��site4
		strcat(str_pattern, str_temp); //"X0" 0��Ϊʾ����������ʵ�ʾ���0
		//ƴ��site3
		strcat(str_pattern, "H"); //"X0X"
		strcat(str_pattern, str_temp); //"X0X0"
		//ƴ��site2
		strcat(str_pattern, "H"); //"X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0"
		//ƴ��site1
		strcat(str_pattern, "H"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
	}
	UART_CH.LoadPatternWithLabel("H1H1H1H1", "RegAddress_STOP");
	Pattern_counter += 20;
	/*����CRC*/
	unsigned int sentData[256];
	//SYNC 
	sentData[0] = 0x55;
	//address
	sentData[1] = address;
	//regAddress
	sentData[2] = regAddress;


	int CRC_Value = CRC_LUT(sentData, 3);
	UART_CRC_READ = CRC_Value;
	//��CRC ת�� pattern
	UART_CH.LoadPatternWithLabel("H0H0H0H0", "CRC_START");
	for (SIZE_T i = 0; i < 8; i++)
	{
		char str_pattern[10] = "H";
		char str_temp[2] = "H";
		long BIT_TEMP = ceil(pow(2, i));
		int SHOW_BIT = (CRC_Value & BIT_TEMP) >> i;
		SHOW_BIT += '0';
		str_temp[0] = char(SHOW_BIT);
		//ƴ��site4
		strcat(str_pattern, str_temp); //"X0" 0��Ϊʾ����������ʵ�ʾ���0
		//ƴ��site3
		strcat(str_pattern, "H"); //"X0X"
		strcat(str_pattern, str_temp); //"X0X0"
		//ƴ��site2
		strcat(str_pattern, "H"); //"X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0"
		//ƴ��site1
		strcat(str_pattern, "H"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
	}
	UART_CH.LoadPatternWithLabel("H1H1H1H1", "CRC_STOP");
	Pattern_counter += 20;
//	UART_CH.LoadPatternWithLabel("H1H1H1H1", "READ_START");
//	UART_CH.LoadPatternWithLabel("H1H1H1H1");
	Pattern_counter += 2;
	//��¼TX �ϻش�������STATUS �� CRC �ض�ֵ
	for (SIZE_T i = 0; i < writeByteCount; i++)
	{
		char str1_data_pattern[50] = "READ_DATA";
		char str2_data_pattern[50] = "READ_DATA";
		char str1_data_temp[2] = "X";
		str1_data_temp[0] = i + '0';
		strcat(str1_data_pattern, str1_data_temp);
		strcat(str1_data_pattern, "_START");
		strcat(str2_data_pattern, str1_data_temp);
		strcat(str2_data_pattern, "_STOP");
		UART_CH.LoadPatternWithLabel("H1H1H1H1", str1_data_pattern);
		for (SIZE_T j = 0; j < 8; j++)
		{
			UART_CH.LoadPatternWithLabel("H1H1H1H1");
		}
		UART_CH.LoadPatternWithLabel("H1H1H1H1", str2_data_pattern);
		Pattern_counter += 20;
	//	UART_CH.LoadPatternWithLabel("H1H1H1H1");//DIA82920 ���ֽڼ��������ڣ���Ʒû�м������
	//	Pattern_counter += 1;
	}

	UART_CH.LoadPatternWithLabel("H1H1H1H1", "READ_CRC_START");

	for (SIZE_T j = 0; j < 8; j++)
	{
		UART_CH.LoadPatternWithLabel("H1H1H1H1");
	}
	UART_CH.LoadPatternWithLabel("H1H1H1H1", "READ_CRC_STOP");
	Pattern_counter += 20;
	UART_CH.LoadPatternWithLabel("H1H1H1H1", "READ_STOP");
	UART_CH.LoadPatternWithLabel("XXXXXXXX");
	UART_CH.LoadPatternWithLabel("XXXXXXXX");
	UART_CH.LoadPatternWithLabel("XXXXXXXX");
	UART_CH.LoadPatternWithLabel("XXXXXXXX");
	UART_CH.LoadPatternWithLabel("XXXXXXXX");
	UART_CH.LoadPatternWithLabel("XXXXXXXX");
	UART_CH.LoadPatternWithLabel("XXXXXXXX");
	UART_CH.LoadPatternWithLabel("XXXXXXXX");
	UART_CH.LoadPatternWithLabel("XXXXXXXX");
	UART_CH.LoadPatternWithLabel("XXXXXXXX", "REBACK_STOP");
	Pattern_counter += 16;
	UART_CH.RunPatternWithLabel("SYNC_START", "REBACK_STOP");

	delay_ms(long(ceil(1 / Trans_Feq * Pattern_counter * 1000)) + 1);
	return UART_CRC_READ;

}
BYTE UART_CRC_16_IBM::UART_Read_Data_Burst_Mode(DIO &UART_CH, int address, int regAddress, int writeByteCount, int FreSplitTime)
{

	BYTE UART_CRC_READ;
	int Pattern_counter = 0;
	//�����һ�����е�pattern
	UART_CH.ClearPattern();
	/*�� synchronization frame (SYNC)�ź� 01010101 (0x55) �̶�����*/
	UART_CH.LoadPatternWithLabel("H0H0H0H0", "SYNC_START");

	for (SIZE_T i = 0; i < FreSplitTime-1; i++)
	{
		UART_CH.LoadPatternWithLabel("H0H0H0H0");
	}


	for (SIZE_T i = 0; i < 8; i++)
	{
		char str_pattern[50] = "H";
		char str_temp[2] = "H";
		long BIT_TEMP = ceil(pow(2, i));
		int SHOW_BIT = (SYNC_init & BIT_TEMP) >> i;
		SHOW_BIT += '0';
		str_temp[0] = char(SHOW_BIT);
		//ƴ��site4
		strcat(str_pattern, str_temp); //"X0" 0��Ϊʾ����������ʵ�ʾ���0
		//ƴ��site3
		strcat(str_pattern, "H"); //"X0X"
		strcat(str_pattern, str_temp); //"X0X0"
		//ƴ��site2
		strcat(str_pattern, "H"); //"X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0"
		//ƴ��site1
		strcat(str_pattern, "H"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
		for (SIZE_T j = 0; j < FreSplitTime - 1; j++)
		{
			UART_CH.LoadPatternWithLabel(str_pattern);
		}
		//UART_CH.LoadPatternWithLabel(str_pattern);
	}
	for (SIZE_T i = 0; i < FreSplitTime - 1; i++)
	{
		UART_CH.LoadPatternWithLabel("H1H1H1H1");
	}
	//UART_CH.LoadPatternWithLabel("H1H1H1H1");
	UART_CH.LoadPatternWithLabel("H1H1H1H1", "SYNC_STOP");
	Pattern_counter += FreSplitTime*10;
	//��address ת�� pattern
	UART_CH.LoadPatternWithLabel("H0H0H0H0", "Address_START");
	for (SIZE_T i = 0; i < FreSplitTime - 1; i++)
	{
		UART_CH.LoadPatternWithLabel("H0H0H0H0");
	}
	for (SIZE_T i = 0; i < 8; i++)
	{
		char str_pattern[50] = "H";
		char str_temp[2] = "H";
		long BIT_TEMP = ceil(pow(2, i));
		int SHOW_BIT = (address & BIT_TEMP) >> i;
		SHOW_BIT += '0';
		str_temp[0] = char(SHOW_BIT);
		//ƴ��site4
		strcat(str_pattern, str_temp); //"X0" 0��Ϊʾ����������ʵ�ʾ���0
		//ƴ��site3
		strcat(str_pattern, "H"); //"X0X"
		strcat(str_pattern, str_temp); //"X0X0"
		//ƴ��site2
		strcat(str_pattern, "H"); //"X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0"
		//ƴ��site1
		strcat(str_pattern, "H"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
		for (SIZE_T j = 0; j < FreSplitTime - 1; j++)
		{
			UART_CH.LoadPatternWithLabel(str_pattern);
		}
		//UART_CH.LoadPatternWithLabel(str_pattern);
	}
	for (SIZE_T i = 0; i < FreSplitTime - 1; i++)
	{
		UART_CH.LoadPatternWithLabel("H1H1H1H1");
	}
	UART_CH.LoadPatternWithLabel("H1H1H1H1", "Address_STOP");
	Pattern_counter += FreSplitTime * 10;
	//��regAddress ת�� pattern
	UART_CH.LoadPatternWithLabel("H0H0H0H0", "RegAddress_START");
	for (SIZE_T i = 0; i < FreSplitTime - 1; i++)
	{
		UART_CH.LoadPatternWithLabel("H0H0H0H0");
	}
	for (SIZE_T i = 0; i < 8; i++)
	{

		char str_pattern[50] = "H";
		char str_temp[2] = "H";
		long BIT_TEMP = ceil(pow(2, i));
		int SHOW_BIT = (regAddress & BIT_TEMP) >> i;
		SHOW_BIT += '0';
		str_temp[0] = char(SHOW_BIT);
		//ƴ��site4
		strcat(str_pattern, str_temp); //"X0" 0��Ϊʾ����������ʵ�ʾ���0
		//ƴ��site3
		strcat(str_pattern, "H"); //"X0X"
		strcat(str_pattern, str_temp); //"X0X0"
		//ƴ��site2
		strcat(str_pattern, "H"); //"X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0"
		//ƴ��site1
		strcat(str_pattern, "H"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
		for (SIZE_T j = 0; j < FreSplitTime - 1; j++)
		{
			UART_CH.LoadPatternWithLabel(str_pattern);
		}
	}
	for (SIZE_T i = 0; i < FreSplitTime - 1; i++)
	{
		UART_CH.LoadPatternWithLabel("H1H1H1H1");
	}
	UART_CH.LoadPatternWithLabel("H1H1H1H1", "RegAddress_STOP");
	Pattern_counter += FreSplitTime * 10;
	/*����CRC*/
	unsigned int sentData[256];
	//SYNC 
	sentData[0] = 0x55;
	//address
	sentData[1] = address;
	//regAddress
	sentData[2] = regAddress;


	int CRC_Value = CRC_LUT(sentData, 3);
	UART_CRC_READ = CRC_Value;
	//��CRC ת�� pattern
	UART_CH.LoadPatternWithLabel("H0H0H0H0", "CRC_START");
	for (SIZE_T i = 0; i < FreSplitTime - 1; i++)
	{
		UART_CH.LoadPatternWithLabel("H0H0H0H0");
	}
	for (SIZE_T i = 0; i < 8; i++)
	{
		char str_pattern[10] = "H";
		char str_temp[2] = "H";
		long BIT_TEMP = ceil(pow(2, i));
		int SHOW_BIT = (CRC_Value & BIT_TEMP) >> i;
		SHOW_BIT += '0';
		str_temp[0] = char(SHOW_BIT);
		//ƴ��site4
		strcat(str_pattern, str_temp); //"X0" 0��Ϊʾ����������ʵ�ʾ���0
		//ƴ��site3
		strcat(str_pattern, "H"); //"X0X"
		strcat(str_pattern, str_temp); //"X0X0"
		//ƴ��site2
		strcat(str_pattern, "H"); //"X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0"
		//ƴ��site1
		strcat(str_pattern, "H"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
		for (SIZE_T j = 0; j < FreSplitTime - 1; j++)
		{
			UART_CH.LoadPatternWithLabel(str_pattern);
		}
	}
	for (SIZE_T i = 0; i < FreSplitTime - 1; i++)
	{
		UART_CH.LoadPatternWithLabel("H1H1H1H1");
	}
	UART_CH.LoadPatternWithLabel("H1H1H1H1", "CRC_STOP");
	Pattern_counter += FreSplitTime * 10;
	//	UART_CH.LoadPatternWithLabel("H1H1H1H1", "READ_START");
	//	UART_CH.LoadPatternWithLabel("H1H1H1H1");
	//Pattern_counter += 2;
	//��¼TX �ϻش�������STATUS �� CRC �ض�ֵ
	for (SIZE_T i = 0; i < writeByteCount; i++)
	{
		for (SIZE_T j = 0; j < FreSplitTime; j++)
		{
			UART_CH.LoadPatternWithLabel("H1H1H1H1");
		}
		char str1_data_pattern[50] = "READ_DATA";
		char str2_data_pattern[50] = "READ_DATA";
		char str1_data_temp[2] = "X";
		str1_data_temp[0] = i + '0';
		strcat(str1_data_pattern, str1_data_temp);
		strcat(str1_data_pattern, "_START");
		strcat(str2_data_pattern, str1_data_temp);
		strcat(str2_data_pattern, "_STOP");
		UART_CH.LoadPatternWithLabel("H1H1H1H1", str1_data_pattern);
		for (SIZE_T j = 0; j < FreSplitTime - 1; j++)
		{
			UART_CH.LoadPatternWithLabel("H1H1H1H1");
		}

		for (SIZE_T j = 1; j < 7 ; j++)
		{
			for (SIZE_T K = 0; K < FreSplitTime; K++)
			{
				UART_CH.LoadPatternWithLabel("H1H1H1H1");
			}
		}
		for (SIZE_T j = 0; j < FreSplitTime - 1; j++)
		{
			UART_CH.LoadPatternWithLabel("H1H1H1H1");
		}
		UART_CH.LoadPatternWithLabel("H1H1H1H1", str2_data_pattern);
		for (SIZE_T j = 0; j < FreSplitTime; j++)
		{
			UART_CH.LoadPatternWithLabel("H1H1H1H1");
		}
		Pattern_counter += FreSplitTime * 10;
	}

	UART_CH.LoadPatternWithLabel("H1H1H1H1", "READ_CRC_START");
	for (SIZE_T i = 0; i < FreSplitTime - 1; i++)
	{
		UART_CH.LoadPatternWithLabel("H1H1H1H1");
	}

	for (SIZE_T j = 0; j < 8 * FreSplitTime; j++)
	{
		UART_CH.LoadPatternWithLabel("H1H1H1H1");
	//	UART_CH.LoadPatternWithLabel("H1H1H1H1");
	}
	for (SIZE_T i = 0; i < FreSplitTime - 1; i++)
	{
		UART_CH.LoadPatternWithLabel("H1H1H1H1");
	}
	UART_CH.LoadPatternWithLabel("H1H1H1H1", "READ_CRC_STOP");
	Pattern_counter += FreSplitTime * 10;
	for (SIZE_T i = 0; i < FreSplitTime - 1; i++)
	{
		UART_CH.LoadPatternWithLabel("H1H1H1H1");
	}
	UART_CH.LoadPatternWithLabel("H1H1H1H1", "READ_STOP");
	UART_CH.LoadPatternWithLabel("XXXXXXXX");
	UART_CH.LoadPatternWithLabel("XXXXXXXX");
	UART_CH.LoadPatternWithLabel("XXXXXXXX");
	UART_CH.LoadPatternWithLabel("XXXXXXXX");
	UART_CH.LoadPatternWithLabel("XXXXXXXX");
	UART_CH.LoadPatternWithLabel("XXXXXXXX");
	UART_CH.LoadPatternWithLabel("XXXXXXXX");
	UART_CH.LoadPatternWithLabel("XXXXXXXX");
	UART_CH.LoadPatternWithLabel("XXXXXXXX");
	UART_CH.LoadPatternWithLabel("XXXXXXXX", "REBACK_STOP");
	Pattern_counter += 16;
	UART_CH.RunPatternWithLabel("SYNC_START", "REBACK_STOP");

	delay_ms(long(ceil(1 / Trans_Feq * Pattern_counter * 1000)) + 1);
	return UART_CRC_READ;
}
//void Get_Data_Burst_Mode(DIO����, ��ǰsite)��




DWORD * UART_CRC_16_IBM::Get_Data_Burst_Mode(DIO &UART_CH, int SiteNo, int writeByteCount)
{


	for (SIZE_T i = 0; i < writeByteCount; i++)
	{

		DWORD temp_DATA = 999;
		char str1_data_pattern[50] = "READ_DATA";
		char str2_data_pattern[50] = "READ_DATA";
		char str1_data_temp[2] = "X";
		str1_data_temp[0] = i + '0';
		strcat(str1_data_pattern, str1_data_temp);
		strcat(str1_data_pattern, "_START");
		strcat(str2_data_pattern, str1_data_temp);
		strcat(str2_data_pattern, "_STOP");
	//	reDATA1[i] = UART_CH.GetSerialPatternResult(SiteNo * 2 + 1, 0,32, LSB);
		reDATA1[i] = UART_CH.GetSerialPatternResultWithLabel(SiteNo * 2 + 1, str1_data_pattern, str2_data_pattern, LSB);
	//    reDATA1[i] = (UART_CH.GetSerialPatternResultWithLabel(SiteNo * 2 + 1, str1_data_pattern, str2_data_pattern, LSB) >> 2) & 0xFFFF;

	
	}

	ptrData = &reDATA1[0];
	return ptrData;

}
//void Get_Data_Burst_Mode(DIO����, ��ǰsite, ��Ƶ����)��
DWORD * UART_CRC_16_IBM::Get_Data_Burst_Mode(DIO &UART_CH, int SiteNo, int writeByteCount, int FreSplitTime)
{
	int m, n;
	int linshi[128] = { 0 };
	DWORD shuju3[128];
	for (SIZE_T i = 0; i < writeByteCount; i++)
	{

		DWORD temp_DATA = 999;
		char str1_data_pattern[50] = "READ_DATA";
		char str2_data_pattern[50] = "READ_DATA";
		char str1_data_temp[2] = "X";
		str1_data_temp[0] = i + '0';
		strcat(str1_data_pattern, str1_data_temp);
		strcat(str1_data_pattern, "_START");
		strcat(str2_data_pattern, str1_data_temp);
		strcat(str2_data_pattern, "_STOP");
		//	reDATA1[i] = UART_CH.GetSerialPatternResult(SiteNo * 2 + 1, 0,32, LSB);
		reDATA1[i] = UART_CH.GetSerialPatternResultWithLabel(SiteNo * 2 + 1, str1_data_pattern, str2_data_pattern, LSB);
		//    reDATA1[i] = (UART_CH.GetSerialPatternResultWithLabel(SiteNo * 2 + 1, str1_data_pattern, str2_data_pattern, LSB) >> 2) & 0xFFFF;
		linshi[i] = 0;
		for (n = 0; n < 8; n++)
		{
			shuju3[i] = reDATA1[i] & 0xf;
			if (shuju3[i] == 0xf)
			{
				linshi[i] = linshi[i] + 1 * pow(2, n);
				reDATA1[i] = reDATA1[i] >> 4;
			}
			else if (shuju3[i] == 0x0)
			{
				linshi[i] = linshi[i] + 0 * pow(2, n);
				reDATA1[i] = reDATA1[i] >> 4;
			}
			else
			{
				reDATA1[i] = -1;
				break;
			}
		}
		reDATA1[i] = linshi[i];

	}

	ptrData = &reDATA1[0];
	return ptrData;

}
/* as UART transmit from LSB to MSB,
* invert the polynomial 0x31 (0011 0001) to 0x8C (1000 1100)
*/
#define polynomialINV 0x8C 
#define LSB1 0x01


/* calculate and store the CRC of data from 0x00 to 0xFF */
void UART_CRC_16_IBM::crcInitial()
{
	unsigned int k, j, remainder;
	for (k = 0; k<256; k++)
	{
		remainder = k;
		for (j = 8; j>0; j--)
		{
			if (remainder & LSB1)
			{
				/* right shift 1 bit and do the XOR operation with 0x8C */
				remainder = (remainder >> 1) ^ polynomialINV;
			}
			else
			{
				remainder = remainder >> 1;
			}
		}
		crcArray[k] = remainder;
	}
}

/* calculate CRC of command frame LSB*/
unsigned int UART_CRC_16_IBM::CRC_LUT(unsigned int commandFrame_withoutCRC[], unsigned int byteLength)
{
	unsigned int remainder, tempData, k;
	/* assign the initial value 0xFF */
	remainder = 0xFF;
	/* the first SYNC byte not engage CRC calculation */
	for (k = 1; k<byteLength; k++)
	{
		/* input data byte XOR remainder */
		tempData = remainder ^ commandFrame_withoutCRC[k];
		/* use tempData as the index to retrieve its CRC from crcArray */
		remainder = crcArray[tempData];
	}
	/* we have to reverse the final remainder to get the CRC value, for example
	* for example, if final remainder = 0010 1100, we need to reverse it to 0011 0100
	*/
	remainder = ((remainder & 0x80) >> 7) + ((remainder & 0x40) >> 5) + ((remainder & 0x20) >> 3) + ((remainder & 0x10) >> 1) + ((remainder & 0x08) << 1) + ((remainder & 0x04) << 3) + ((remainder & 0x02) << 5) + ((remainder & 0x01) << 7);
	return remainder;
}

/* calculate CRC of command frame MSB*/
unsigned int UART_CRC_16_IBM::CRC_MUT(unsigned int commandFrame_withoutCRC[], unsigned int byteLength)
{
	unsigned int remainder, tempData, k;
	/* assign the initial value 0xFF */
	remainder = 0xFF;
	/* the first SYNC byte not engage CRC calculation */
	for (k = 1; k<byteLength; k++)
	{
		/* input data byte XOR remainder */
		tempData = remainder ^ commandFrame_withoutCRC[k];
		/* use tempData as the index to retrieve its CRC from crcArray */
		remainder = crcArray[tempData];
	}
	return remainder;
}


/**/
#define BIT0 (0x01)
#define BIT1 (0x02)
#define BIT2 (0x04)
#define BIT3 (0x08)
#define BIT4 (0x10)
#define BIT5 (0x20)
#define BIT6 (0x40)
#define BIT7 (0x80)
/*���ֽ�CRC����*/
unsigned int UART_CRC_16_IBM::CRC_Calculation(unsigned int CRC_Initial, unsigned int Input_Data)
{
	unsigned int Temp_Bit, Input_Bit;
	/* store every bit value of Input_Data */
	unsigned int bit0, bit1, bit2, bit3, bit4, bit5, bit6, bit7;
	/* store the Input_Data (byte) 's CRC */
	unsigned int CRC = 0;
	/* get every bit of CRC initial value */
	unsigned int i = 0; bit0 = CRC_Initial & BIT0;

	bit1 = (CRC_Initial & BIT1) >> 1;
	bit2 = (CRC_Initial & BIT2) >> 2;
	bit3 = (CRC_Initial & BIT3) >> 3;
	bit4 = (CRC_Initial & BIT4) >> 4;
	bit5 = (CRC_Initial & BIT5) >> 5;
	bit6 = (CRC_Initial & BIT6) >> 6;
	bit7 = (CRC_Initial & BIT7) >> 7;

	for (i = 0; i<8; i++)
	{
		/* extract one bit of Input Data (from LSB to MSB) */
		Input_Bit = (Input_Data >> i) & 0x01;
		/* Do Input_Bit XOR bit7 */
		Temp_Bit = Input_Bit ^ bit7;
		bit7 = bit6;
		bit6 = bit5;
		/* Do bit4 XOR Temp_Bit */
		bit4 = bit4 ^ Temp_Bit;
		bit5 = bit4;
		/* Do bit3 XOR Tmep_Bit */
		bit3 = bit3 ^ Temp_Bit;
		bit4 = bit3;
		bit3 = bit2;
		bit2 = bit1;
		bit1 = bit0;
		bit0 = Temp_Bit;
	}

	CRC = (bit7 << 7) | (bit6 << 6) | (bit5 << 5) | (bit4 << 4) | (bit3 << 3) | (bit2 << 2) | (bit1 << 1) | bit0;
	return CRC;
}
/*����CRC*/
unsigned int UART_CRC_16_IBM::CRC(unsigned int commandFrame_withoutCRC[], unsigned int byteLength)
{
	unsigned int j;
	unsigned int CRCtemp;
	for (j = 0; j<byteLength - 1; j++)
	{
		if (j == 0)
		{
			/* CRC initial value is 0xFF, and SYNC byte is not engaged in CRC calculation
			*/
			CRCtemp = CRC_Calculation(0xFF, commandFrame_withoutCRC[j + 1]);
		}
		else
		{
			/* assign the last calculated CRC to CRC_initial and calculate the second,
			* third,..., byte's CRC value until all bytes have been calculated
			*/
			CRCtemp = CRC_Calculation(CRCtemp, commandFrame_withoutCRC[j + 1]);
		}
	}
	/* after calculating the final byte's CRC value we get this frame's CRC */
	return CRCtemp;
}


DWORD UART_CRC_16_IBM::CRC16_IBM(unsigned int commandFrame_withoutCRC[], size_t size)
{
	DWORD CRCFull = 0x0000;
	DWORD CRCLSB;

	for (int i = 0; i < size; i++)
	{
		CRCFull = (DWORD)(CRCFull ^ commandFrame_withoutCRC[i]);  //commandFrame_withoutCRC[i]

		for (int j = 0; j < 8; j++)
		{
			CRCLSB = (DWORD)(CRCFull & 0x0001);               //0x0001
			CRCFull = (DWORD)((CRCFull >> 1) & 0x7FFF);        //0x0000

			if (CRCLSB == 1)
				CRCFull = (DWORD)(CRCFull ^ 0xA001);               //0xA001
		}
	}
	return CRCFull;

}
void UART_CRC_16_IBM::UART16_Write_Data_Single_Mode(DIO &UART_CH, int INIT, int DevID, int regAddress, BYTE data0)
{

	int Pattern_counter = 0;
	//�����һ�����е�pattern
	UART_CH.ClearPattern();


	UART_CH.LoadPatternWithLabel("X0X0X0X0", "URAT16_START");
	for (SIZE_T i = 0; i < 8; i++)
	{
		char str_pattern[50] = "X0X0X0";
		char str_temp[2] = "X";
		long BIT_TEMP = ceil(pow(2, i));    
		int SHOW_BIT = (INIT & BIT_TEMP) >> i;     //INIT=ABCDEFGH ��2��i���ݣ�i=0,SHOW_BIT=H, i+1,SHOW_BIT=G...
		SHOW_BIT += '0';     //��һ���ַ�0�����ֱ��ַ���
		str_temp[0] = char(SHOW_BIT);

		//ƴ��site1
		strcat(str_pattern, "X"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
	}
	UART_CH.LoadPatternWithLabel("X1X1X1X1", "URAT16_STOP");
	Pattern_counter += 10;
	//��address ת�� pattern
	UART_CH.LoadPatternWithLabel("X0X0X0X0", "DevID_START");
	for (SIZE_T i = 0; i < 8; i++)
	{
		char str_pattern[50] = "X0X0X0";
		char str_temp[2] = "X";
		long BIT_TEMP = ceil(pow(2, i));
		int SHOW_BIT = (DevID & BIT_TEMP) >> i;
		SHOW_BIT += '0';
		str_temp[0] = char(SHOW_BIT);

		//ƴ��site1
		strcat(str_pattern, "X"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
	}
	UART_CH.LoadPatternWithLabel("X1X1X1X1", "DevID_STOP");
	Pattern_counter += 10;
	//��regAddress ת�� pattern
	UART_CH.LoadPatternWithLabel("X0X0X0X0", "RegAddress_START");
	for (SIZE_T i = 0; i < 8; i++)
	{

		char str_pattern[50] = "X0X0X0";
		char str_temp[2] = "X";
		long BIT_TEMP = ceil(pow(2, i));
		int SHOW_BIT = (regAddress & BIT_TEMP) >> i;
		SHOW_BIT += '0';
		str_temp[0] = char(SHOW_BIT);

		//ƴ��site1
		strcat(str_pattern, "X"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
	}
	UART_CH.LoadPatternWithLabel("X1X1X1X1", "RegAddress_STOP");
	Pattern_counter += 10;
	//��DATA ת�� pattern
	UART_CH.LoadPatternWithLabel("X0X0X0X0", "DATA0_START");

	for (SIZE_T i = 0; i < 8; i++)
	{
		char str_pattern[50] = "X0X0X0";
		char str_temp[2] = "X";
		long BIT_TEMP = ceil(pow(2, i));
		int SHOW_BIT = (data0 & BIT_TEMP) >> i;
		SHOW_BIT += '0';
		str_temp[0] = char(SHOW_BIT);
		//ƴ��site1
		strcat(str_pattern, "X"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
	}
	UART_CH.LoadPatternWithLabel("X1X1X1X1", "DATA0_STOP");
	Pattern_counter += 11;///

	/*����CRC*/
	unsigned int data[] = { INIT, DevID, regAddress, data0 };
	DWORD crc = CRC16_IBM(data, 4);
	CRC_L = crc & 0xFF;
	CRC_H = (crc & 0xFF00) >> 8;
	CRC_TEMP = crc;
	//��CRCL ת�� pattern
	UART_CH.LoadPatternWithLabel("X0X0X0X0", "CRCL_START");
	for (SIZE_T i = 0; i < 8; i++)
	{
		char str_pattern[10] = "X0X0X0";
		char str_temp[2] = "X";
		long BIT_TEMP = ceil(pow(2, i));
		int SHOW_BIT = (CRC_L & BIT_TEMP) >> i;
		SHOW_BIT += '0';
		str_temp[0] = char(SHOW_BIT);

		//ƴ��site1
		strcat(str_pattern, "X"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
	}
	UART_CH.LoadPatternWithLabel("X1X1X1X1", "CRCL_STOP");
	Pattern_counter += 10;

	//��CRCH ת�� pattern
	UART_CH.LoadPatternWithLabel("X0X0X0X0", "CRCH_START");
	for (SIZE_T i = 0; i < 8; i++)
	{
		char str_pattern[10] = "X0X0X0";
		char str_temp[2] = "X";
		long BIT_TEMP = ceil(pow(2, i));
		int SHOW_BIT = (CRC_H & BIT_TEMP) >> i;
		SHOW_BIT += '0';
		str_temp[0] = char(SHOW_BIT);

		//ƴ��site1
		strcat(str_pattern, "X"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
	}
	UART_CH.LoadPatternWithLabel("X1X1X1X1", "CRCH_STOP");
	Pattern_counter += 10;
	//��¼TX �ϻش�������STATUS �� CRC �ض�ֵ
	UART_CH.LoadPatternWithLabel("X1X1X1X1", "REBACK_START");
	for (SIZE_T i = 0; i < 10; i++)
	{
		UART_CH.LoadPatternWithLabel("X1X1X1X1");
	}
	UART_CH.LoadPatternWithLabel("X1X1X1X1");
	UART_CH.LoadPatternWithLabel("X1X1X1X1");
	UART_CH.LoadPatternWithLabel("X1X1X1X1", "REBACK_STOP");
	Pattern_counter += 14;
	UART_CH.RunPatternWithLabel("URAT16_START", "REBACK_STOP");

	delay_ms(long(ceil(1 / Trans_Feq * Pattern_counter * 1000)) + 1);

}
void UART_CRC_16_IBM::UART16_Write_Data_Single_Mode(DIO &UART_CH, int INIT, int DevID, int regAddress, BYTE data0, BYTE data1, BYTE data2, BYTE data3)
{
	int Pattern_counter = 0;
	//�����һ�����е�pattern
	UART_CH.ClearPattern();


	UART_CH.LoadPatternWithLabel("X0X0X0X0", "URAT16_START");
	for (SIZE_T i = 0; i < 8; i++)
	{
		char str_pattern[50] = "X0X0X0";
		char str_temp[2] = "X";
		long BIT_TEMP = ceil(pow(2, i));
		int SHOW_BIT = (INIT & BIT_TEMP) >> i;     //INIT=ABCDEFGH ��2��i���ݣ�i=0,SHOW_BIT=H, i+1,SHOW_BIT=G...
		SHOW_BIT += '0';     //��һ���ַ�0�����ֱ��ַ���
		str_temp[0] = char(SHOW_BIT);

		//ƴ��site1
		strcat(str_pattern, "X"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
	}
	UART_CH.LoadPatternWithLabel("X1X1X1X1", "URAT16_STOP");
	Pattern_counter += 10;
	//��address ת�� pattern
	UART_CH.LoadPatternWithLabel("X0X0X0X0", "DevID_START");
	for (SIZE_T i = 0; i < 8; i++)
	{
		char str_pattern[50] = "X0X0X0";
		char str_temp[2] = "X";
		long BIT_TEMP = ceil(pow(2, i));
		int SHOW_BIT = (DevID & BIT_TEMP) >> i;
		SHOW_BIT += '0';
		str_temp[0] = char(SHOW_BIT);

		//ƴ��site1
		strcat(str_pattern, "X"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
	}
	UART_CH.LoadPatternWithLabel("X1X1X1X1", "DevID_STOP");
	Pattern_counter += 10;
	//��regAddress ת�� pattern
	UART_CH.LoadPatternWithLabel("X0X0X0X0", "RegAddress_START");
	for (SIZE_T i = 0; i < 8; i++)
	{

		char str_pattern[50] = "X0X0X0";
		char str_temp[2] = "X";
		long BIT_TEMP = ceil(pow(2, i));
		int SHOW_BIT = (regAddress & BIT_TEMP) >> i;
		SHOW_BIT += '0';
		str_temp[0] = char(SHOW_BIT);

		//ƴ��site1
		strcat(str_pattern, "X"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
	}
	UART_CH.LoadPatternWithLabel("X1X1X1X1", "RegAddress_STOP");
	Pattern_counter += 10;
	//��DATA ת�� pattern
	UART_CH.LoadPatternWithLabel("X0X0X0X0", "DATA0_START");

	for (SIZE_T i = 0; i < 8; i++)
	{
		char str_pattern[50] = "X0X0X0";
		char str_temp[2] = "X";
		long BIT_TEMP = ceil(pow(2, i));
		int SHOW_BIT = (data0 & BIT_TEMP) >> i;
		SHOW_BIT += '0';
		str_temp[0] = char(SHOW_BIT);
		//ƴ��site1
		strcat(str_pattern, "X"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
	}
	UART_CH.LoadPatternWithLabel("X1X1X1X1", "DATA0_STOP");
	Pattern_counter += 11;///
	//��DATA ת�� pattern
	UART_CH.LoadPatternWithLabel("X0X0X0X0", "DATA1_START");

	for (SIZE_T i = 0; i < 8; i++)
	{
		char str_pattern[50] = "X0X0X0";
		char str_temp[2] = "X";
		long BIT_TEMP = ceil(pow(2, i));
		int SHOW_BIT = (data1 & BIT_TEMP) >> i;
		SHOW_BIT += '0';
		str_temp[0] = char(SHOW_BIT);
		//ƴ��site1
		strcat(str_pattern, "X"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
	}
	UART_CH.LoadPatternWithLabel("X1X1X1X1", "DATA1_STOP");
	Pattern_counter += 11;///

	//��DATA ת�� pattern
	UART_CH.LoadPatternWithLabel("X0X0X0X0", "DATA2_START");

	for (SIZE_T i = 0; i < 8; i++)
	{
		char str_pattern[50] = "X0X0X0";
		char str_temp[2] = "X";
		long BIT_TEMP = ceil(pow(2, i));
		int SHOW_BIT = (data2 & BIT_TEMP) >> i;
		SHOW_BIT += '0';
		str_temp[0] = char(SHOW_BIT);
		//ƴ��site1
		strcat(str_pattern, "X"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
	}
	UART_CH.LoadPatternWithLabel("X1X1X1X1", "DATA2_STOP");
	Pattern_counter += 11;///

	//��DATA ת�� pattern
	UART_CH.LoadPatternWithLabel("X0X0X0X0", "DATA3_START");

	for (SIZE_T i = 0; i < 8; i++)
	{
		char str_pattern[50] = "X0X0X0";
		char str_temp[2] = "X";
		long BIT_TEMP = ceil(pow(2, i));
		int SHOW_BIT = (data3 & BIT_TEMP) >> i;
		SHOW_BIT += '0';
		str_temp[0] = char(SHOW_BIT);
		//ƴ��site1
		strcat(str_pattern, "X"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
	}
	UART_CH.LoadPatternWithLabel("X1X1X1X1", "DATA3_STOP");
	Pattern_counter += 11;///
	/*����CRC*/
	unsigned int data[] = { INIT, DevID, regAddress, data0, data1, data2, data3 };
	DWORD crc = CRC16_IBM(data, 7);
	CRC_L = crc & 0xFF;
	CRC_H = (crc & 0xFF00) >> 8;
	CRC_TEMP = crc;
	//��CRCL ת�� pattern
	UART_CH.LoadPatternWithLabel("X0X0X0X0", "CRCL_START");
	for (SIZE_T i = 0; i < 8; i++)
	{
		char str_pattern[10] = "X0X0X0";
		char str_temp[2] = "X";
		long BIT_TEMP = ceil(pow(2, i));
		int SHOW_BIT = (CRC_L & BIT_TEMP) >> i;
		SHOW_BIT += '0';
		str_temp[0] = char(SHOW_BIT);

		//ƴ��site1
		strcat(str_pattern, "X"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
	}
	UART_CH.LoadPatternWithLabel("X1X1X1X1", "CRCL_STOP");
	Pattern_counter += 10;

	//��CRCH ת�� pattern
	UART_CH.LoadPatternWithLabel("X0X0X0X0", "CRCH_START");
	for (SIZE_T i = 0; i < 8; i++)
	{
		char str_pattern[10] = "X0X0X0";
		char str_temp[2] = "X";
		long BIT_TEMP = ceil(pow(2, i));
		int SHOW_BIT = (CRC_H & BIT_TEMP) >> i;
		SHOW_BIT += '0';
		str_temp[0] = char(SHOW_BIT);

		//ƴ��site1
		strcat(str_pattern, "X"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
	}
	UART_CH.LoadPatternWithLabel("X1X1X1X1", "CRCH_STOP");
	Pattern_counter += 10;
	//��¼TX �ϻش�������STATUS �� CRC �ض�ֵ
	UART_CH.LoadPatternWithLabel("X1X1X1X1", "REBACK_START");
	for (SIZE_T i = 0; i < 10; i++)
	{
		UART_CH.LoadPatternWithLabel("X1X1X1X1");
	}
	UART_CH.LoadPatternWithLabel("X1X1X1X1");
	UART_CH.LoadPatternWithLabel("X1X1X1X1");
	UART_CH.LoadPatternWithLabel("X1X1X1X1", "REBACK_STOP");
	Pattern_counter += 14;
	UART_CH.RunPatternWithLabel("URAT16_START", "REBACK_STOP");

	delay_ms(long(ceil(1 / Trans_Feq * Pattern_counter * 1000)) + 1);
}
//Read
/*void UART_Read_Data_Single_Mode(DIO����, �ӻ���ַ, �Ĵ�����ַ)��
*/
BYTE  UART_CRC_16_IBM::UART16_Read_Data_Single_Mode(DIO &UART_CH, int INIT, int DevID, int regAddress)
{
	int Pattern_counter = 0;
	//�����һ�����е�pattern
	UART_CH.ClearPattern();


	UART_CH.LoadPatternWithLabel("X0X0X0H0", "URAT16_START");
	for (SIZE_T i = 0; i < 8; i++)
	{
		char str_pattern[50] = "X0X0X0";
		char str_temp[2] = "X";
		long BIT_TEMP = ceil(pow(2, i));
		int SHOW_BIT = (INIT & BIT_TEMP) >> i;
		SHOW_BIT += '0';
		str_temp[0] = char(SHOW_BIT);

		//ƴ��site1
		strcat(str_pattern, "H"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
	}
	UART_CH.LoadPatternWithLabel("X1X1X1H1", "URAT16_STOP");
	Pattern_counter += 10;
	//��address ת�� pattern
	UART_CH.LoadPatternWithLabel("X0X0X0H0", "DevID_START");
	for (SIZE_T i = 0; i < 8; i++)
	{
		char str_pattern[50] = "X0X0X0";
		char str_temp[2] = "X";
		long BIT_TEMP = ceil(pow(2, i));
		int SHOW_BIT = (DevID & BIT_TEMP) >> i;
		SHOW_BIT += '0';
		str_temp[0] = char(SHOW_BIT);

		//ƴ��site1
		strcat(str_pattern, "H"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
	}
	UART_CH.LoadPatternWithLabel("X1X1X1H1", "DevID_STOP");
	Pattern_counter += 10;
	//��regAddress ת�� pattern
	UART_CH.LoadPatternWithLabel("X0X0X0H0", "RegAddress_START");
	for (SIZE_T i = 0; i < 8; i++)
	{

		char str_pattern[50] = "X0X0X0";
		char str_temp[2] = "X";
		long BIT_TEMP = ceil(pow(2, i));
		int SHOW_BIT = (regAddress & BIT_TEMP) >> i;
		SHOW_BIT += '0';
		str_temp[0] = char(SHOW_BIT);

		//ƴ��site1
		strcat(str_pattern, "H"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
	}
	UART_CH.LoadPatternWithLabel("X1X1X1H1", "RegAddress_STOP");
	Pattern_counter += 10;


	/*����CRC*/
	unsigned int data[] = { INIT, DevID, regAddress };
	DWORD crc = CRC16_IBM(data, 3);
	CRC_L = crc & 0xFF;
	CRC_H = (crc & 0xFF00) >> 8;
	CRC_TEMP = crc;
	//��CRCL ת�� pattern
	UART_CH.LoadPatternWithLabel("X0X0X0H0", "CRCL_START");
	for (SIZE_T i = 0; i < 8; i++)
	{
		char str_pattern[10] = "X0X0X0";
		char str_temp[2] = "X";
		long BIT_TEMP = ceil(pow(2, i));
		int SHOW_BIT = (CRC_L & BIT_TEMP) >> i;
		SHOW_BIT += '0';
		str_temp[0] = char(SHOW_BIT);

		//ƴ��site1
		strcat(str_pattern, "H"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
	}
	UART_CH.LoadPatternWithLabel("X1X1X1H1", "CRCL_STOP");
	Pattern_counter += 10;

	//��CRCH ת�� pattern
	UART_CH.LoadPatternWithLabel("X0X0X0H0", "CRCH_START");
	for (SIZE_T i = 0; i < 8; i++)
	{
		char str_pattern[10] = "X0X0X0";
		char str_temp[2] = "X";
		long BIT_TEMP = ceil(pow(2, i));
		int SHOW_BIT = (CRC_H & BIT_TEMP) >> i;
		SHOW_BIT += '0';
		str_temp[0] = char(SHOW_BIT);

		//ƴ��site1
		strcat(str_pattern, "H"); //"X0X0X0X"
		strcat(str_pattern, str_temp); //"X0X0X0X0"
		UART_CH.LoadPatternWithLabel(str_pattern);
	}
	UART_CH.LoadPatternWithLabel("X1X1X1H1", "CRCH_STOP");
	Pattern_counter += 10;
	//��¼TX �ϻش�������STATUS �� CRC �ض�ֵ
	UART_CH.LoadPatternWithLabel("X1X1X1H1", "REBACK_START");
	for (SIZE_T i = 0; i < 20; i++)
	{
		UART_CH.LoadPatternWithLabel("X1X1X1H1");
	}
	UART_CH.LoadPatternWithLabel("X1X1X1H1");
	UART_CH.LoadPatternWithLabel("X1X1X1H1");
	UART_CH.LoadPatternWithLabel("X1X1X1H1", "REBACK_STOP");
	Pattern_counter += 14;
	UART_CH.RunPatternWithLabel("URAT16_START", "REBACK_STOP");

	delay_ms(long(ceil(1 / Trans_Feq * Pattern_counter * 1000)) + 1);

	return crc;
}
//Get CRC_L
DWORD UART_CRC_16_IBM::Get_CRC_L()
{
	return CRC_L;
	//return CRC_TEMP;
}
//Get CRC_H
DWORD UART_CRC_16_IBM::Get_CRC_H()
{
	return CRC_H;
}

DWORD UART_CRC_16_IBM::Get16_Data_Single_Mode(DIO &UART_CH, int SiteNo)
{
	DWORD reBYTE;
	reBYTE = UART_CH.GetSerialPatternResultWithLabel(SiteNo * 2 + 1, "CRCH_STOP", "REBACK_STOP", LSB);
	reBYTE = reBYTE  & 0xFFFF;
	for (int i = 0; i < 32; i++)
	{
		if ((reBYTE & 0x0001) == 0)
		{
			reBYTE = ((reBYTE >> 1) & 0xFF);
			break;
		}
		else
		{
			reBYTE = reBYTE >> 1;
		}

	}
	//reBYTE = (reBYTE >> 2) & 0xFF;
	//reBYTE = (reBYTE >> 3) & 0xFF;
	return 	reBYTE;
}