#include "stdafx.h"
#include "math.h"
#include <string.h>
#include <string>
#include "time.h"
#include <iostream>
#include "UART_CRC_16_IBM.h"

using namespace std;

#define SITENUM 1 //Site ��
#define NUM_SITE 1

#define Write_Init 0x87  //���ֽ�д
#define Read_Init 0x4B  //���ֽڶ�

#define DevID_VOL 0x20 //����ҼĴ���������Address ����GND ����0x20
#define DevID_MTP 0x80  //������ҼĴ���������Address ����GND ����0x20

int i;
double adresult[8] = { 0 };
double adresult1[8] = { 0 };
double adresult2[8] = { 0 };
double adresult3[8] = { 0 };
double adresult4[8] = { 0 };
double adresult5[8] = { 0 };
FPVI10 CP_TOP(0, "CP_TOP");
FPVI10 FPVI1(1, "CP_BOT");
FPVI10 VDDK(2, "VDDK");
FPVI10 FPVI3(3, "VDD");
FPVI10 FPVI4(4, "FPVI4");
//FPVI10 OSC(5, "OSC");
//FPVI10 VDD_1D5V(6, "VDD_1D5V");
FPVI10 FPVI6(6, "FPVI6");
FPVI10 SYNC1(7, "SYNC1");

FOVI LED1K(0, "LED1K");
FOVI LED1A(1, "LED1A");
FOVI LED2(2, "LED2");
FOVI LED3(3, "LED3");
FOVI LED4(4, "LED4");
FOVI LED5K(5, "LED5K");
FOVI LED5A(6, "LED5A");
FOVI LED6(7, "LED6");
FOVI LED7(8, "LED7");
FOVI LED8(9, "LED8");
FOVI LED9K(10, "LED9K");
FOVI LED9A(11, "LED9A");
FOVI LED10(12, "LED10");
FOVI LED11(13, "LED11");
FOVI LED12(14, "LED12");
FOVI LED13K(15, "LED13K");
FOVI LED13A(16, "LED13A");
FOVI LED14(17, "LED14");
FOVI LED15(18, "LED15");
FOVI LED16(19, "LED16");
FOVI NC5(20, "NC5");
FOVI NC4(21, "NC4");
FOVI CS_NC3(22, "CS-NC3");
FOVI PULL_UP(23, "PULL_UP");
FOVI FOVI24(25, "CLK_L1");
FOVI FOVI25(24, "CLK_H1");
FOVI FOVI26(26, "RX1");
FOVI FOVI27(27, "TX1");
FOVI FOVI28(28, "ADDR3_TM-NC1");
FOVI FOVI29(29, "ADDR2_TM-NC2");
FOVI FOVI30(30, "ADDR1_ADC2");
FOVI FOVI31(31, "FS_ADC1");

double Trans_Freq = 1000e3;//Khz

DIO UART_CH(0);

CBIT128 CBIT;

UART_CRC_16_IBM UART_trans(Trans_Freq);

QTMU_PLUS qtmu0(0);
QTMU_PLUS qtmu1(1);
QTMU_PLUS qtmu2(2);
QTMU_PLUS qtmu3(3);

#define K1  1
#define K2  2
#define K3  3
#define K4  4
#define K5  5
#define K6  6
#define K7  7
#define K8  8
#define K9  9
#define K10  10
#define K11  11
#define K12  12
#define K13  13
#define K14  14
#define K15  15
#define K32  32
#define K33  33
#define K34  34
#define K35  35
#define K36  36
#define K37  37
#define K38  38
#define K39  39
#define K40  40
#define K41  41
#define K42  42
#define K43  43
#define K44  44
#define K45  45
#define K46  46
#define K47  47
#define K96  96
#define K97  97
#define K98  98
#define K99  99
#define K100  100
#define K101  101
#define K102  102
#define K103  103
#define K104  104
#define K105  105
#define K106  106
#define K107  107
#define K108  108
#define K109  109
#define K110  110


//multisite settings should be included here
DUT_API void HardWareCfg()
{
	/*For example: four channels dvi to config two sites*/
	/*StsSetModuleToSite(MD_DVI400,SITE_1,0,1,-1);
		StsSetModuleToSite(MD_DVI400,SITE_2,2,3,-1);*/
	//FPVI
	StsSetModuleToSite(MD_FPVI10, SITE_1, 0, 1, 2, 3, 4, 5, 6, 7, -1);//Site 1

	//FOVI
	StsSetModuleToSite(MD_FOVI, SITE_1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, -1);//Site 1

	//QTMU
	StsSetModuleToSite(MD_QTMUPLUS, SITE_1, 0,1,2,3, -1);


	/*DIO INIT*/
	UART_CH.Init();

	UART_CH.SetVIH(3.3);
	UART_CH.SetVIL(0.0);

	UART_CH.SetVOH(2.0);//�ض�4.5���4.0(20240808)
	UART_CH.SetVOL(0.5);

	UART_CH.SetClockFreq(Trans_Freq);//Freq = 100KHz
	//UART_CH.SetClockPeriod(1/Trans_Freq);
	
	//UART_CH.SetDelay(0, 0, 1 / Trans_Freq / 2);//Set the delay time for channel 0. The driver leading edge to 10ns,the drivertrailingedge to 9us, thereceiver strobeedge to 5us.
	//UART_CH.SetDelay(1, 0, 1 / Trans_Freq / 20, 1 / Trans_Freq / 20);//Set the delay time for channel 1. The driver leading edge to 10ns,the drivertrailingedge to 9us, thereceiver strobeedge to 5us.

	UART_CH.SetDelay(0, 0, 1 / Trans_Freq / 2);//Set the delay time for channel 0. The driver leading edge to 10ns,the drivertrailingedge to 9us, thereceiver strobeedge to 5us.
	UART_CH.SetDelay(1, 1 / Trans_Freq / 6, 1 / Trans_Freq / 2, 2 / Trans_Freq / 3);//Set the delay time for channel 1. The driver leading edge to 10ns,the drivertrailingedge to 9us, thereceiver strobeedge to 5us.
	UART_CH.SetDelay(2, 0, 1 / Trans_Freq / 2);//Set the delay time for channel 0. The driver leading edge to 10ns,the drivertrailingedge to 9us, thereceiver strobeedge to 5us.
	UART_CH.SetDelay(3, 1 / Trans_Freq / 6, 1 / Trans_Freq / 2, 2 / Trans_Freq / 3);//Set the delay time for channel 1. The driver leading edge to 10ns,the drivertrailingedge to 9us, thereceiver strobeedge to 5us.
	UART_CH.SetDelay(4, 0, 1 / Trans_Freq / 2);//Set the delay time for channel 0. The driver leading edge to 10ns,the drivertrailingedge to 9us, thereceiver strobeedge to 5us.
	UART_CH.SetDelay(5, 1 / Trans_Freq / 6, 1 / Trans_Freq / 2, 2 / Trans_Freq / 3);//Set the delay time for channel 1. The driver leading edge to 10ns,the drivertrailingedge to 9us, thereceiver strobeedge to 5us.
	UART_CH.SetDelay(6, 0, 1 / Trans_Freq / 2);//Set the delay time for channel 0. The driver leading edge to 10ns,the drivertrailingedge to 9us, thereceiver strobeedge to 5us.
	UART_CH.SetDelay(7, 1 / Trans_Freq / 6, 1 / Trans_Freq / 2, 2 / Trans_Freq / 3);//Set the delay time for channel 1. The driver leading edge to 10ns,the drivertrailingedge to 9us, thereceiver strobeedge to 5us.

	UART_CH.SetWaveFormat(0, "NRZ");//��ͨ��0��ʽ
	UART_CH.SetWaveFormat(1, "NRZ");//��ͨ��1��ʽ
	UART_CH.SetWaveFormat(2, "NRZ");//��ͨ��2��ʽ
	UART_CH.SetWaveFormat(3, "NRZ");//��ͨ��3��ʽ
	UART_CH.SetWaveFormat(4, "NRZ");//��ͨ��4��ʽ
	UART_CH.SetWaveFormat(5, "NRZ");//��ͨ��5��ʽ
	UART_CH.SetWaveFormat(6, "NRZ");//��ͨ��6��ʽ
	UART_CH.SetWaveFormat(7, "NRZ");//��ͨ��7��ʽ


}
/************************************************************************/
/*                                                                      */
/************************************************************************/
//initialize function will be called before all the test functions.
DUT_API void InitBeforeTestFlow()
{
}
/************************************************************************/
/*                                                                      */
/************************************************************************/
//initializefunction will be called after all the test functions.
DUT_API void InitAfterTestFlow()
{		
}
/************************************************************************/
/*                                                                      */
/************************************************************************/
//Fail site hardware set function will be called after failed params, it can be called for serveral times. 
DUT_API void SetupFailSite(const unsigned char*byFailSite)
{			
}
/************************************************************************/
/*                                                                      */
/************************************************************************/


DUT_API int OS(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *OS_LED1K = StsGetParam(funcindex,"OS_LED1K");
    CParam *OS_LED1A = StsGetParam(funcindex,"OS_LED1A");
    CParam *OS_LED2 = StsGetParam(funcindex,"OS_LED2");
    CParam *OS_LED3 = StsGetParam(funcindex,"OS_LED3");
    CParam *OS_LED4 = StsGetParam(funcindex,"OS_LED4");
    CParam *OS_LED5K = StsGetParam(funcindex,"OS_LED5K");
    CParam *OS_LED5A = StsGetParam(funcindex,"OS_LED5A");
    CParam *OS_LED6 = StsGetParam(funcindex,"OS_LED6");
    CParam *OS_LED7 = StsGetParam(funcindex,"OS_LED7");
    CParam *OS_LED8 = StsGetParam(funcindex,"OS_LED8");
    CParam *OS_LED9K = StsGetParam(funcindex,"OS_LED9K");
    CParam *OS_LED9A = StsGetParam(funcindex,"OS_LED9A");
    CParam *OS_LED10 = StsGetParam(funcindex,"OS_LED10");
    CParam *OS_LED11 = StsGetParam(funcindex,"OS_LED11");
    CParam *OS_LED12 = StsGetParam(funcindex,"OS_LED12");
    CParam *OS_LED13K = StsGetParam(funcindex,"OS_LED13K");
    CParam *OS_LED13A = StsGetParam(funcindex,"OS_LED13A");
    CParam *OS_LED14 = StsGetParam(funcindex,"OS_LED14");
    CParam *OS_LED15 = StsGetParam(funcindex,"OS_LED15");
    CParam *OS_LED16 = StsGetParam(funcindex,"OS_LED16");
    CParam *OS_FS = StsGetParam(funcindex,"OS_FS");
    CParam *OS_NC5 = StsGetParam(funcindex,"OS_NC5");
    CParam *OS_NC4 = StsGetParam(funcindex,"OS_NC4");
    CParam *OS_ADC1 = StsGetParam(funcindex,"OS_ADC1");
    CParam *OS_VDDK = StsGetParam(funcindex,"OS_VDDK");
    CParam *OS_ADC2 = StsGetParam(funcindex,"OS_ADC2");
    CParam *OS_ADDR1 = StsGetParam(funcindex,"OS_ADDR1");
    CParam *OS_SYNC1 = StsGetParam(funcindex,"OS_SYNC1");
    CParam *OS_RX = StsGetParam(funcindex,"OS_RX");
    CParam *OS_TX = StsGetParam(funcindex,"OS_TX");
    CParam *OS_ADDR2 = StsGetParam(funcindex,"OS_ADDR2");
    CParam *OS_ADDR3 = StsGetParam(funcindex,"OS_ADDR3");
    CParam *OS_CP_TOP = StsGetParam(funcindex,"OS_CP_TOP");
    CParam *OS_CP_BOT = StsGetParam(funcindex,"OS_CP_BOT");
    CParam *OS_CS_NC3 = StsGetParam(funcindex,"OS_CS_NC3");
    CParam *OS_VDD = StsGetParam(funcindex,"OS_VDD");
    CParam *OS_CLK_H1 = StsGetParam(funcindex,"OS_CLK_H1");
    CParam *OS_CLK_L1 = StsGetParam(funcindex,"OS_CLK_L1");
    CParam *OS_TM_NC1 = StsGetParam(funcindex,"OS_TM_NC1");
    CParam *OS_TM_NC2 = StsGetParam(funcindex,"OS_TM_NC2");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	double test_sample = 30;
	double test_cycle = 20;//us
	//////////////////LED1K//////////////////
	LED1K.Set(FI, -100e-6, FOVI_2V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED1K.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED1K.GetMeasResult(i, MVRET);
		OS_LED1K->SetTestResult(i, 0, adresult[i]);
	}
	LED1K.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	LED1K.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(1);

	//////////////////LED1A//////////////////
	LED1A.Set(FI, -100e-6, FOVI_2V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED1A.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED1A.GetMeasResult(i, MVRET);
		OS_LED1A->SetTestResult(i, 0, adresult[i]);
	}
	LED1A.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	LED1A.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(1);

	//////////////////LED2//////////////////
	LED2.Set(FI, -100e-6, FOVI_2V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED2.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED2.GetMeasResult(i, MVRET);
		OS_LED2->SetTestResult(i, 0, adresult[i]);
	}
	LED2.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	LED2.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(1);

	//////////////////LED3//////////////////
	LED3.Set(FI, -100e-6, FOVI_2V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED3.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED3.GetMeasResult(i, MVRET);
		OS_LED3->SetTestResult(i, 0, adresult[i]);
	}
	LED3.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	LED3.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(1);

	//////////////////LED4//////////////////
	LED4.Set(FI, -100e-6, FOVI_2V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED4.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED4.GetMeasResult(i, MVRET);
		OS_LED4->SetTestResult(i, 0, adresult[i]);
	}
	LED4.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	LED4.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(1);

	//////////////////LED5K//////////////////
	LED5K.Set(FI, -100e-6, FOVI_2V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED5K.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED5K.GetMeasResult(i, MVRET);
		OS_LED5K->SetTestResult(i, 0, adresult[i]);
	}
	LED5K.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	LED5K.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(1);

	//////////////////LED5A//////////////////
	LED5A.Set(FI, -100e-6, FOVI_2V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED5A.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED5A.GetMeasResult(i, MVRET);
		OS_LED5A->SetTestResult(i, 0, adresult[i]);
	}
	LED5A.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	LED5A.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(1);

	//////////////////LED6//////////////////
	LED6.Set(FI, -100e-6, FOVI_2V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED6.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED6.GetMeasResult(i, MVRET);
		OS_LED6->SetTestResult(i, 0, adresult[i]);
	}
	LED6.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	LED6.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(1);

	//////////////////LED7//////////////////
	LED7.Set(FI, -100e-6, FOVI_2V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED7.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED7.GetMeasResult(i, MVRET);
		OS_LED7->SetTestResult(i, 0, adresult[i]);
	}
	LED7.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	LED7.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(1);

	//////////////////LED8//////////////////
	LED8.Set(FI, -100e-6, FOVI_2V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED8.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED8.GetMeasResult(i, MVRET);
		OS_LED8->SetTestResult(i, 0, adresult[i]);
	}
	LED8.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	LED8.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(1);

	//////////////////LED9K//////////////////
	LED9K.Set(FI, -100e-6, FOVI_2V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED9K.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED9K.GetMeasResult(i, MVRET);
		OS_LED9K->SetTestResult(i, 0, adresult[i]);
	}
	LED9K.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	LED9K.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(1);

	//////////////////LED9A//////////////////
	LED9A.Set(FI, -100e-6, FOVI_2V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED9A.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED9A.GetMeasResult(i, MVRET);
		OS_LED9A->SetTestResult(i, 0, adresult[i]);
	}
	LED9A.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	LED9A.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(1);

	//////////////////LED10//////////////////
	LED10.Set(FI, -100e-6, FOVI_2V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED10.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED10.GetMeasResult(i, MVRET);
		OS_LED10->SetTestResult(i, 0, adresult[i]);
	}
	LED10.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	LED10.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(1);

	//////////////////LED11//////////////////
	LED11.Set(FI, -100e-6, FOVI_2V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED11.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED11.GetMeasResult(i, MVRET);
		OS_LED11->SetTestResult(i, 0, adresult[i]);
	}
	LED11.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	LED11.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(1);

	//////////////////LED12//////////////////
	LED12.Set(FI, -100e-6, FOVI_2V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED12.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED12.GetMeasResult(i, MVRET);
		OS_LED12->SetTestResult(i, 0, adresult[i]);
	}
	LED12.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	LED12.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(1);

	//////////////////LED13K//////////////////
	LED13K.Set(FI, -100e-6, FOVI_2V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED13K.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED13K.GetMeasResult(i, MVRET);
		OS_LED13K->SetTestResult(i, 0, adresult[i]);
	}
	LED13K.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	LED13K.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(1);

	//////////////////LED13A//////////////////
	LED13A.Set(FI, -100e-6, FOVI_2V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED13A.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED13A.GetMeasResult(i, MVRET);
		OS_LED13A->SetTestResult(i, 0, adresult[i]);
	}
	LED13A.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	LED13A.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(1);

	//////////////////LED14//////////////////
	LED14.Set(FI, -100e-6, FOVI_2V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED14.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED14.GetMeasResult(i, MVRET);
		OS_LED14->SetTestResult(i, 0, adresult[i]);
	}
	LED14.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	LED14.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(1);

	//////////////////LED15//////////////////
	LED15.Set(FI, -100e-6, FOVI_2V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED15.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED15.GetMeasResult(i, MVRET);
		OS_LED15->SetTestResult(i, 0, adresult[i]);
	}
	LED15.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	LED15.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(1);

	//////////////////LED16//////////////////
	LED16.Set(FI, -100e-6, FOVI_2V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED16.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED16.GetMeasResult(i, MVRET);
		OS_LED16->SetTestResult(i, 0, adresult[i]);
	}
	LED16.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	LED16.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(1);

	//////////////////NC5//////////////////
	NC5.Set(FI, -100e-6, FOVI_2V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	NC5.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = NC5.GetMeasResult(i, MVRET);
		OS_NC5->SetTestResult(i, 0, adresult[i]);
	}
	NC5.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	NC5.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(1);

	//////////////////NC4//////////////////
	NC4.Set(FI, -100e-6, FOVI_2V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	NC4.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = NC4.GetMeasResult(i, MVRET);
		OS_NC4->SetTestResult(i, 0, adresult[i]);
	}
	NC4.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	NC4.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(1);

	//////////////////CS_NC3//////////////////
	CS_NC3.Set(FI, -100e-6, FOVI_2V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	CS_NC3.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = CS_NC3.GetMeasResult(i, MVRET);
		OS_CS_NC3->SetTestResult(i, 0, adresult[i]);
	}
	CS_NC3.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	CS_NC3.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(1);

	//////////////////CLK_L1//////////////////
	FOVI24.Set(FI, -100e-6, FOVI_2V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	FOVI24.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FOVI24.GetMeasResult(i, MVRET);
		OS_CLK_L1->SetTestResult(i, 0, adresult[i]);
	}
	FOVI24.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	FOVI24.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(1);

	//////////////////CLK_H1//////////////////
	FOVI25.Set(FI, -100e-6, FOVI_2V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	FOVI25.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FOVI25.GetMeasResult(i, MVRET);
		OS_CLK_H1->SetTestResult(i, 0, adresult[i]);
	}
	FOVI25.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	FOVI25.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(1);

	//////////////////RX//////////////////
	FOVI26.Set(FI, -100e-6, FOVI_2V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	FOVI26.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FOVI26.GetMeasResult(i, MVRET);
		OS_RX->SetTestResult(i, 0, adresult[i]);
	}
	FOVI26.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	FOVI26.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(1);

	//////////////////TX//////////////////
	FOVI27.Set(FI, -100e-6, FOVI_2V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	FOVI27.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FOVI27.GetMeasResult(i, MVRET);
		OS_TX->SetTestResult(i, 0, adresult[i]);
	}
	FOVI27.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	FOVI27.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(1);

	//////////////////ADDR3//////////////////
	FOVI28.Set(FI, -100e-6, FOVI_2V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	FOVI28.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FOVI28.GetMeasResult(i, MVRET);
		OS_ADDR3->SetTestResult(i, 0, adresult[i]);
	}
	FOVI28.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	FOVI28.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(1);

	//////////////////ADDR2//////////////////
	FOVI29.Set(FI, -100e-6, FOVI_2V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	FOVI29.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FOVI29.GetMeasResult(i, MVRET);
		OS_ADDR2->SetTestResult(i, 0, adresult[i]);
	}
	FOVI29.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	FOVI29.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(1);

	//////////////////ADDR1//////////////////
	FOVI30.Set(FI, -100e-6, FOVI_2V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	FOVI30.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FOVI30.GetMeasResult(i, MVRET);
		OS_ADDR1->SetTestResult(i, 0, adresult[i]);
	}
	FOVI30.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	FOVI30.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(1);

	//////////////////FS//////////////////
	FOVI31.Set(FI, -100e-6, FOVI_2V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	FOVI31.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FOVI31.GetMeasResult(i, MVRET);
		OS_FS->SetTestResult(i, 0, adresult[i]);
	}
	FOVI31.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	FOVI31.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(1);


	CBIT.SetOn(K106, K109, -1);
	delay_ms(2);

	//////////////////TM-NC1//////////////////
	FOVI28.Set(FI, -100e-6, FOVI_2V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	FOVI28.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FOVI28.GetMeasResult(i, MVRET);
		OS_TM_NC1->SetTestResult(i, 0, adresult[i]);
	}
	FOVI28.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	FOVI28.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(1);

	//////////////////TM-NC2//////////////////
	FOVI29.Set(FI, -100e-6, FOVI_2V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	FOVI29.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FOVI29.GetMeasResult(i, MVRET);
		OS_TM_NC2->SetTestResult(i, 0, adresult[i]);
	}
	FOVI29.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	FOVI29.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(1);

	//////////////////ADC2//////////////////
	FOVI30.Set(FI, -100e-6, FOVI_2V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	FOVI30.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FOVI30.GetMeasResult(i, MVRET);
		OS_ADC2->SetTestResult(i, 0, adresult[i]);
	}
	FOVI30.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	FOVI30.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(1);

	//////////////////ADC1//////////////////
	FOVI31.Set(FI, -100e-6, FOVI_2V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	FOVI31.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FOVI31.GetMeasResult(i, MVRET);
		OS_ADC1->SetTestResult(i, 0, adresult[i]);
	}
	FOVI31.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	FOVI31.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(1);


	//////////////////CP_TOP//////////////////
	CP_TOP.Set(FI, -100e-6, FPVI10_2V, FPVI10_1MA, RELAY_ON);
	delay_ms(2);
	CP_TOP.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = CP_TOP.GetMeasResult(i, MVRET);
		OS_CP_TOP->SetTestResult(i, 0, adresult[i]);
	}
	CP_TOP.Set(FV, 0, FPVI10_2V, FPVI10_1MA, RELAY_ON);
	CP_TOP.Set(FV, 0, FPVI10_2V, FPVI10_1MA, RELAY_OFF);
	delay_ms(1);

	//////////////////CP_BOT//////////////////
	FPVI1.Set(FI, -100e-6, FPVI10_2V, FPVI10_1MA, RELAY_ON);
	delay_ms(2);
	FPVI1.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FPVI1.GetMeasResult(i, MVRET);
		OS_CP_BOT->SetTestResult(i, 0, adresult[i]);
	}
	FPVI1.Set(FV, 0, FPVI10_2V, FPVI10_1MA, RELAY_ON);
	FPVI1.Set(FV, 0, FPVI10_2V, FPVI10_1MA, RELAY_OFF);
	delay_ms(1);

	//////////////////VDDK//////////////////
	VDDK.Set(FI, -300e-6, FPVI10_2V, FPVI10_1MA, RELAY_ON);
	delay_ms(15);
	VDDK.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = VDDK.GetMeasResult(i, MVRET);
		OS_VDDK->SetTestResult(i, 0, adresult[i]);
	}
	VDDK.Set(FV, 0, FPVI10_2V, FPVI10_1MA, RELAY_ON);
	VDDK.Set(FV, 0, FPVI10_2V, FPVI10_1MA, RELAY_OFF);
	delay_ms(1);

	//////////////////VDD//////////////////
	FPVI3.Set(FI, -300e-6, FPVI10_2V, FPVI10_1MA, RELAY_ON);
	delay_ms(15);
	FPVI3.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FPVI3.GetMeasResult(i, MVRET);
		OS_VDD->SetTestResult(i, 0, adresult[i]);
	}
	FPVI3.Set(FV, 0, FPVI10_2V, FPVI10_1MA, RELAY_ON);
	FPVI3.Set(FV, 0, FPVI10_2V, FPVI10_1MA, RELAY_OFF);
	delay_ms(1);

	////////////////////OSC//////////////////
	//OSC.Set(FI, -100e-6, FPVI10_2V, FPVI10_1MA, RELAY_ON);
	//delay_ms(2);
	//OSC.MeasureVI(test_sample, test_cycle);
	//for (i = 0; i<SITENUM; i++)
	//{
	//	adresult[i] = OSC.GetMeasResult(i, MVRET);
	//	OS_OSC->SetTestResult(i, 0, adresult[i]);
	//}
	//OSC.Set(FV, 0, FPVI10_2V, FPVI10_1MA, RELAY_ON);
	//OSC.Set(FV, 0, FPVI10_2V, FPVI10_1MA, RELAY_OFF);
	//delay_ms(1);

	////////////////////VDD_1D5V//////////////////
	//VDD_1D5V.Set(FI, -100e-6, FPVI10_2V, FPVI10_1MA, RELAY_ON);
	//delay_ms(2);
	//VDD_1D5V.MeasureVI(test_sample, test_cycle);
	//for (i = 0; i<SITENUM; i++)
	//{
	//	adresult[i] = VDD_1D5V.GetMeasResult(i, MVRET);
	//	OS_VDD_1D5V->SetTestResult(i, 0, adresult[i]);
	//}
	//VDD_1D5V.Set(FV, 0, FPVI10_2V, FPVI10_1MA, RELAY_ON);
	//VDD_1D5V.Set(FV, 0, FPVI10_2V, FPVI10_1MA, RELAY_OFF);
	//delay_ms(1);

	//////////////////SYNC1//////////////////
	SYNC1.Set(FI, -100e-6, FPVI10_2V, FPVI10_1MA, RELAY_ON);
	delay_ms(2);
	SYNC1.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = SYNC1.GetMeasResult(i, MVRET);
		OS_SYNC1->SetTestResult(i, 0, adresult[i]);
	}
	SYNC1.Set(FV, 0, FPVI10_2V, FPVI10_1MA, RELAY_ON);
	SYNC1.Set(FV, 0, FPVI10_2V, FPVI10_1MA, RELAY_OFF);
	delay_ms(1);

	CBIT.SetOn(-1);
	delay_ms(2);
    return 0;
}


DUT_API int IVDDQ(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *IVDDQ_LED_0V = StsGetParam(funcindex,"IVDDQ_LED_0V");
    CParam *IVDDQ_LED16_10V = StsGetParam(funcindex,"IVDDQ_LED16_10V");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here

	double test_sample = 50;
	double test_cycle = 20;//us

	////////////////////////////////////////////////////////////////////
	//FPVI3=5V��ALL LED=0V��MEAS I_FPVI3
	LED1K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED1A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED2.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED3.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED4.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED5K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED5A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED6.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED7.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED8.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED9K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED9A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED10.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED11.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED12.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED13K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED13A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED14.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED15.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED16.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);

	//FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	//delay_ms(1);
	FPVI3.Set(FV, 5, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(20);
	FPVI3.MeasureVI(200, 20);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FPVI3.GetMeasResult(i, MIRET);
		IVDDQ_LED_0V->SetTestResult(i, 0, adresult[i] * 1E3);
	}
	//FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	//delay_ms(2);

	/////////////////////////////////////////////////////////
	//VDD=5V��LED16=10V��OTHER LED=0V��MEAS I_VDD
	//FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	//delay_ms(2);
	//LED16.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(2);	
	//FPVI3.Set(FV, 5, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	//delay_ms(5);
	LED16.Set(FV, 10, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(20);


	FPVI3.MeasureVI(200, 20);
	LED16.MeasureVI(200, 20);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FPVI3.GetMeasResult(i, MIRET);
		IVDDQ_LED16_10V->SetTestResult(i, 0, adresult[i] * 1E3);
	}


	FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(2);
	LED16.Set(FV, 0, FOVI_50V, FOVI_1A, RELAY_ON);
	delay_ms(2);
	LED16.Set(FV, 0, FOVI_2V, FOVI_1A, RELAY_ON);
	delay_ms(2);

	FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_10MA, RELAY_OFF);
	delay_ms(2);
	LED1K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED1A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED2.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED3.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED4.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED5K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED5A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED6.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED7.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED8.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED9K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED9A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED10.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED11.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED12.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED13K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED13A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED14.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED15.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED16.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	delay_ms(2);

	CBIT.SetOn(-1);
	delay_ms(2);
    return 0;
}


DUT_API int URAT_TEST(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *CRC_L = StsGetParam(funcindex,"CRC_L");
    CParam *CRC_H = StsGetParam(funcindex,"CRC_H");
    CParam *Write_Reg_0x = StsGetParam(funcindex,"Write_Reg_0x");
    CParam *Read_Reg_0x = StsGetParam(funcindex,"Read_Reg_0x");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	CBIT.SetOn(K99,K100, -1);
	delay_ms(2);
	PULL_UP.Set(FV, 5, FOVI_10V, FOVI_100MA, RELAY_ON);
	FOVI30.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	FOVI29.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	FOVI28.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	FOVI31.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	delay_ms(3);

	FPVI3.Set(FV, 5.0, FPVI10_10V, FPVI10_100MA, RELAY_ON);

	delay_ms(5);

	DWORD DATA = 0x22;
	DWORD Reg_Address = 0x80;
	UART_CH.Connect();
	delay_ms(5);
	//UART_trans.UART16_Read_Data_Single_Mode(UART_CH, Read_Init, DevID_VOL, Reg_Address);
	//delay_ms(5);
	//for (i = 0; i<SITENUM; i++)
	//{
	//	Read_Reg_0x->SetTestResult(i, 0, UART_trans.Get16_Data_Single_Mode(UART_CH, SITE_1));
	//}

	//UART_trans.UART16_Write_Data_Single_Mode(UART_CH, Write_Init, DevID_VOL, Reg_Address, DATA);
	//delay_ms(2);
	UART_trans.UART16_Write_Data_Single_Mode(UART_CH, Write_Init, DevID_VOL, Reg_Address, DATA);
	delay_ms(2);
	UART_trans.UART16_Read_Data_Single_Mode(UART_CH, Read_Init, DevID_VOL, Reg_Address);
	delay_ms(5);

	//Reg_Address = 0xFB;
	//UART_trans.UART16_Write_Data_Single_Mode(UART_CH, 0xAA, DevID_VOL, Reg_Address, 0xCA, 0x23, 0x35, 0x24);
	//delay_ms(2);
	for (i = 0; i<SITENUM; i++)
	{

		CRC_L->SetTestResult(i, 0, UART_trans.Get_CRC_L());
		CRC_H->SetTestResult(i, 0, UART_trans.Get_CRC_H());
		Read_Reg_0x->SetTestResult(i, 0, UART_trans.Get16_Data_Single_Mode(UART_CH, SITE_1));
	}
	UART_CH.Disconnect();
	delay_ms(5);
	FPVI3.Set(FV, 0.0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	PULL_UP.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	CBIT.SetOn(-1);
	delay_ms(2);
	FPVI3.Set(FV, 0.0, FPVI10_10V, FPVI10_10MA, RELAY_OFF);
	PULL_UP.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);
	FOVI30.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	FOVI29.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	FOVI28.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	FOVI31.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	delay_ms(3);
    return 0;
}


DUT_API int IVDD_OP(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *IVDD_OP_LVDS_ON = StsGetParam(funcindex,"IVDD_OP_LVDS_ON");
    CParam *IVDD_OP_LVDS_OFF = StsGetParam(funcindex,"IVDD_OP_LVDS_OFF");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	/////////////////////////////////////////////
	//VDD=5V��VLDEx=0V�����üĴ���0x01=11h��LVDS_TX=1��������pin���գ���¼VDD�ϵĵ���ΪIVDD-OP_LVDS_ON
	CBIT.SetOn(K99,K100, -1);
	delay_ms(2);
	PULL_UP.Set(FV, 5, FOVI_10V, FOVI_100MA, RELAY_ON);
	FOVI30.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	FOVI29.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	FOVI28.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	FOVI31.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	delay_ms(3);

	LED1K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED1A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED2.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED3.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED4.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED5K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED5A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED6.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED7.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED8.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED9K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED9A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED10.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED11.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED12.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED13K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED13A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED14.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED15.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED16.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_ms(2);
	FPVI3.Set(FV, 5.0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(5);

	DWORD DATA = 0x11;
	DWORD Reg_Address = 0x01;
	UART_CH.Connect();
	delay_ms(5);
	UART_trans.UART16_Write_Data_Single_Mode(UART_CH, Write_Init, DevID_VOL, Reg_Address, DATA);
	delay_ms(2);
	//UART_trans.UART16_Write_Data_Single_Mode(UART_CH, Write_Init, DevID_VOL, Reg_Address, DATA);
	//delay_ms(2);
	UART_trans.UART16_Read_Data_Single_Mode(UART_CH, Read_Init, DevID_VOL, Reg_Address);
	delay_ms(5);

	FPVI3.MeasureVI(200, 20);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FPVI3.GetMeasResult(i, MIRET);
		//IVDD_OP_LVDS_ON->SetTestResult(i, 1, UART_trans.Get16_Data_Single_Mode(UART_CH, SITE_1));
		IVDD_OP_LVDS_ON->SetTestResult(i, 0, adresult[i] * 1E3);
	}

	///////////////////////////////////////////////
	//VDD = 5V��VLDEx = 0V�����üĴ���0x01 = 10h��LVDS_TX = 0��������pin���գ���¼VDD�ϵĵ���ΪIVDD-OP_LVDS_OFF

	DATA = 0x10;
	Reg_Address = 0x01;
	UART_CH.Connect();
	delay_ms(5);
	UART_trans.UART16_Write_Data_Single_Mode(UART_CH, Write_Init, DevID_VOL, Reg_Address, DATA);
	delay_ms(2);
	//UART_trans.UART16_Write_Data_Single_Mode(UART_CH, Write_Init, DevID_VOL, Reg_Address, DATA);
	//delay_ms(2);
	UART_trans.UART16_Read_Data_Single_Mode(UART_CH, Read_Init, DevID_VOL, Reg_Address);
	delay_ms(5);

	FPVI3.MeasureVI(200, 20);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FPVI3.GetMeasResult(i, MIRET);
		//IVDD_OP_LVDS_OFF->SetTestResult(i, 1, UART_trans.Get16_Data_Single_Mode(UART_CH, SITE_1));
		IVDD_OP_LVDS_OFF->SetTestResult(i, 0, adresult[i] * 1E3);
	}

	UART_CH.Disconnect();
	delay_ms(5);
	FPVI3.Set(FV, 0.0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	PULL_UP.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	CBIT.SetOn(-1);
	delay_ms(2);
	FPVI3.Set(FV, 0.0, FPVI10_10V, FPVI10_10MA, RELAY_OFF);
	LED1K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED1A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED2.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED3.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED4.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED5K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED5A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED6.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED7.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED8.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED9K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED9A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED10.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED11.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED12.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED13K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED13A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED14.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED15.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED16.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	delay_ms(2);
	PULL_UP.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);
	FOVI30.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	FOVI29.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	FOVI28.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	FOVI31.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	delay_ms(3);

    return 0;
}


DUT_API int VDD_UV(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *VDD_UV_RISE = StsGetParam(funcindex,"VDD_UV_RISE");
    CParam *VDD_UV_FALL = StsGetParam(funcindex,"VDD_UV_FALL");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	double test_sample = 30;
	double test_cycle = 20;//us
	/////////////////////////////////////////////////////
	//VDD��3.9V�ϵ���4.3V����1mV������pin���գ��۲�VDD�������䣨3.5mA���䵽6mA������¼VDD��������5mAʱ��Ӧ��VDDΪVDDUV-R
	////////////////////////////AWG_RISE/////////////////////////
	double TRIG_RISE = VDD_UV_RISE->GetConditionCurSelDouble("Trigger")*1e-3;
	double V_Rise_Start = VDD_UV_RISE->GetConditionCurSelDouble("Voltage_start") - 0.05;
	double V_Rise_Stop = VDD_UV_RISE->GetConditionCurSelDouble("Voltage_stop") + 0.05;
	int Step_Rise = 5;//1mV
	long data_temp_rise = ceil(fabs(V_Rise_Start - V_Rise_Stop)*1e3);
	int sam_rise = data_temp_rise / Step_Rise + data_temp_rise % Step_Rise;

	double Trig_Point[NUM_SITE] = { 0.0 };
	int T_Point[NUM_SITE] = { 0 };
	double VDD_RISE[NUM_SITE] = { 0 };
	double VDD_FALL[NUM_SITE] = { 0 };
	int interval = 100; //100us
	double delta[NUM_SITE] = { 0 };
	double UP_awg_pattern[2048] = { 0.0 };
	double DOWN_awg_pattern[2048] = { 0.0 };

	FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);
	FPVI3.Set(FV, V_Rise_Start, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);
	STSAWGCreateRampData(&UP_awg_pattern[0], sam_rise, 1, V_Rise_Start, V_Rise_Stop);
	FPVI3.AwgLoader("VDD_UVR", FV, FPVI10_10V, FPVI10_100MA, UP_awg_pattern, sam_rise);
	FPVI3.Set(FV, V_Rise_Start, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);
	FPVI3.AwgSelect("VDD_UVR", 0, sam_rise - 1, sam_rise - 1, interval);
	FPVI3.SetMeasITrig(TRIG_RISE, TRIG_RISING);
	FPVI3.MeasureVI(sam_rise, interval, MEAS_AWG);
	STSEnableAWG(&FPVI3);
	STSEnableMeas(&FPVI3);
	STSAWGRunTriggerStop(&FPVI3, &FPVI3);

	for (size_t i = 0; i < NUM_SITE; i++)
	{
		Trig_Point[i] = FPVI3.GetMeasResult(i, MIRET, TRIG_RESULT);
		VDD_RISE[i] = FPVI3.GetMeasResult(i, MVRET, Trig_Point[i] - 1) + 1E-3;
		VDD_UV_RISE->SetTestResult(i, 0, VDD_RISE[i] );
	}

	/////////////////////////////////////////////////////
	//VDD��4.3V�½���3.7V����1mV������pin���գ��۲�VDD�������䣨6mA���䵽3.5mA������¼VDD��������5mAʱ��Ӧ��VDDΪVDDUV-F
	////////////////////////////AWG_FALL/////////////////////////
	double TRIG_FALL = VDD_UV_FALL->GetConditionCurSelDouble("Trigger");
	double V_Fall_Start = VDD_UV_FALL->GetConditionCurSelDouble("Voltage_start") + 0.05;
	double V_Fall_Stop = VDD_UV_FALL->GetConditionCurSelDouble("Voltage_stop") - 0.05;
	int Step_Fall = 5;//1mV
	long data_temp_fall = ceil(fabs(V_Fall_Start - V_Fall_Stop)*1e3);
	int sam_fall = data_temp_fall / Step_Fall + data_temp_fall % Step_Fall;

	FPVI3.Set(FV, V_Fall_Start, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);
	STSAWGCreateRampData(&DOWN_awg_pattern[0], sam_fall, 1, V_Fall_Start, V_Fall_Stop);
	FPVI3.AwgLoader("VDD_UVF", FV, FPVI10_10V, FPVI10_100MA, DOWN_awg_pattern, sam_fall);
	FPVI3.Set(FV, V_Fall_Start, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);
	FPVI3.AwgSelect("VDD_UVF", 0, sam_fall - 1, sam_fall - 1, interval);
	FPVI3.SetMeasITrig(TRIG_FALL*1e-3, TRIG_FALLING);
	FPVI3.MeasureVI(sam_fall, interval, MEAS_AWG);
	STSEnableAWG(&FPVI3);
	STSEnableMeas(&FPVI3);
	STSAWGRunTriggerStop(&FPVI3, &FPVI3);

	for (size_t i = 0; i < NUM_SITE; i++)
	{
		Trig_Point[i] = FPVI3.GetMeasResult(i, MIRET, TRIG_RESULT);
		VDD_FALL[i] = FPVI3.GetMeasResult(i, MVRET, Trig_Point[i] - 2) - 2E-3;
		VDD_UV_FALL->SetTestResult(i, 0, VDD_FALL[i] );
	}

	FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);
	FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_100MA, RELAY_OFF);
	delay_ms(2);
    return 0;
}


DUT_API int VDD_OV(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *VDD_OV_RISE = StsGetParam(funcindex,"VDD_OV_RISE");
    CParam *VDD_OV_FALL = StsGetParam(funcindex,"VDD_OV_FALL");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here

	double test_sample = 30;
	double test_cycle = 20;//us
	LED1K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED1A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED2.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED3.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED4.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED5K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED5A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED6.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED7.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED8.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED9K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED9A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED10.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED11.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED12.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED13K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED13A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED14.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED15.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED16.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//////////////////////////////////////////////////////////////
	//VDD��5.5V�ϵ���6V����1mV��VLEDx=0V������pin���գ��۲�CP_TOP��ѹ�仯����14V���͵�5V������¼�õ�ѹ����10Vʱ��Ӧ��VDDΪVDDOV-R
	////////////////////////////AWG_RISE/////////////////////////
	double TRIG_RISE = VDD_OV_RISE->GetConditionCurSelDouble("Trigger");
	double V_Rise_Start = VDD_OV_RISE->GetConditionCurSelDouble("Voltage_start");
	double V_Rise_Stop = VDD_OV_RISE->GetConditionCurSelDouble("Voltage_stop");
	int Step_Rise = 5;//1mV
	long data_temp_rise = ceil(fabs(V_Rise_Start - V_Rise_Stop)*1e3);
	int sam_rise = data_temp_rise / Step_Rise + data_temp_rise % Step_Rise;

	double Trig_Point[NUM_SITE] = { 0.0 };
	int T_Point[NUM_SITE] = { 0 };
	double VDD_RISE[NUM_SITE] = { 0 };
	double VDD_FALL[NUM_SITE] = { 0 };
	int interval = 100; //100us
	double delta[NUM_SITE] = { 0 };
	double UP_awg_pattern_L[2048] = { 0.0 };
	double DOWN_awg_pattern_L[2048] = { 0.0 };
	double UP_awg_pattern_S[2048] = { 0.0 };
	double DOWN_awg_pattern_S[2048] = { 0.0 };

	CP_TOP.Set(FI, 0, FPVI10_20V, FPVI10_10MA, RELAY_SENSE_ON);
	FPVI3.Set(FV, V_Rise_Start, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);
	STSAWGCreateRampData(&UP_awg_pattern_L[0], sam_rise, 1, V_Rise_Start, V_Rise_Stop);
	FPVI3.AwgLoader("VDD_OVR", FV, FPVI10_10V, FPVI10_100MA, UP_awg_pattern_L, sam_rise);
	FPVI3.Set(FV, V_Rise_Start, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);
	FPVI3.AwgSelect("VDD_OVR", 0, sam_rise - 1, sam_rise - 1, interval);
	CP_TOP.SetMeasVTrig(TRIG_RISE, TRIG_FALLING);
	FPVI3.MeasureVI(sam_rise, interval, MEAS_AWG);
	CP_TOP.MeasureVI(sam_rise, interval, MEAS_AWG);
	STSEnableAWG(&FPVI3);
	STSEnableMeas(&FPVI3, &CP_TOP);
	STSAWGRunTriggerStop(&FPVI3, &CP_TOP, &FPVI3);

	for (size_t i = 0; i < NUM_SITE; i++)
	{
		//Trig_Point[i] = CP_TOP.GetMeasResult(i, MVRET, TRIG_RESULT);
		//VDD_RISE[i] = FPVI3.GetMeasResult(i, MVRET, Trig_Point[i]);

		//Step_Rise = 1;//1mV
		//sam_rise = 50;
		//STSAWGCreateRampData(&UP_awg_pattern_S[0], sam_rise, 1, VDD_RISE[i]-0.05, VDD_RISE[i]+0.05);
		//FPVI3.AwgLoader("VDD_OVR_S", FV, FPVI10_10V, FPVI10_100MA, UP_awg_pattern_S, sam_rise);
		//FPVI3.Set(FV, VDD_RISE[i], FPVI10_10V, FPVI10_100MA, RELAY_ON);
		//delay_ms(2);
		//FPVI3.AwgSelect("VDD_OVR_S", 0, sam_rise - 1, sam_rise - 1, interval);
		//CP_TOP.SetMeasVTrig(TRIG_RISE, TRIG_FALLING);
		//FPVI3.MeasureVI(sam_rise, interval, MEAS_AWG);
		//CP_TOP.MeasureVI(sam_rise, interval, MEAS_AWG);
		//STSEnableAWG(&FPVI3);
		//STSEnableMeas(&FPVI3, &CP_TOP);
		//STSAWGRun();

		Trig_Point[i] = CP_TOP.GetMeasResult(i, MVRET, TRIG_RESULT);
		VDD_RISE[i] = FPVI3.GetMeasResult(i, MVRET, Trig_Point[i]);
		VDD_OV_RISE->SetTestResult(i, 0, VDD_RISE[i]);
	}
	FPVI3.AwgClear();
	/////////////////////////////////////////////////////
	//VDD��5.6V�½���5.2V����1mV��VLEDx=0V������pin���գ��۲�CP_TOP��ѹ�仯����5V������14V������¼�õ�ѹ����10Vʱ��Ӧ��VDDΪVDDOV-F
	////////////////////////////AWG_FALL/////////////////////////
	double TRIG_FALL = VDD_OV_FALL->GetConditionCurSelDouble("Trigger");
	double V_Fall_Start = VDD_OV_FALL->GetConditionCurSelDouble("Voltage_start");
	double V_Fall_Stop = VDD_OV_FALL->GetConditionCurSelDouble("Voltage_stop");
	int Step_Fall = 5;//1mV
	long data_temp_fall = ceil(fabs(V_Fall_Start - V_Fall_Stop)*1e3);
	int sam_fall = data_temp_fall / Step_Fall + data_temp_fall % Step_Fall;

	STSAWGCreateRampData(&DOWN_awg_pattern_L[0], sam_fall, 1, V_Fall_Start, V_Fall_Stop);
	FPVI3.AwgLoader("VDD_OVF", FV, FPVI10_10V, FPVI10_100MA, DOWN_awg_pattern_L, sam_fall);
	FPVI3.Set(FV, V_Fall_Start, FPVI10_10V, FPVI10_100MA, RELAY_ON, 2);
	delay_ms(1);
	FPVI3.AwgSelect("VDD_OVF", 0, sam_fall - 1, sam_fall - 1, interval);
	CP_TOP.SetMeasVTrig(TRIG_FALL, TRIG_RISING);
	FPVI3.MeasureVI(sam_fall, interval, MEAS_AWG);
	CP_TOP.MeasureVI(sam_fall, interval, MEAS_AWG);
	STSEnableAWG(&FPVI3);
	STSEnableMeas(&FPVI3, &CP_TOP);
	//STSAWGRun();
	STSAWGRunTriggerStop(&FPVI3, &CP_TOP, &FPVI3);

	for (size_t i = 0; i < NUM_SITE; i++)
	{
		//Trig_Point[i] = CP_TOP.GetMeasResult(i, MVRET, TRIG_RESULT);
		//VDD_FALL[i] = FPVI3.GetMeasResult(i, MVRET, Trig_Point[i]);

		//Step_Fall = 1;//1mV
		//sam_fall = 50;
		//STSAWGCreateRampData(&DOWN_awg_pattern_S[0], sam_fall, 1, VDD_FALL[i] + 0.05, VDD_FALL[i]-0.05);
		//FPVI3.AwgLoader("VDD_OVF_S", FV, FPVI10_10V, FPVI10_100MA, DOWN_awg_pattern_S, sam_fall);
		//FPVI3.Set(FV, VDD_FALL[i], FPVI10_10V, FPVI10_100MA, RELAY_ON);
		//delay_ms(2);
		//FPVI3.AwgSelect("VDD_OVF_S", 0, sam_fall - 1, sam_fall - 1, interval);
		//CP_TOP.SetMeasVTrig(TRIG_RISE, TRIG_FALLING);
		//FPVI3.MeasureVI(sam_fall, interval, MEAS_AWG);
		//CP_TOP.MeasureVI(sam_fall, interval, MEAS_AWG);
		//STSEnableAWG(&FPVI3);
		//STSEnableMeas(&FPVI3, &CP_TOP);
		//STSAWGRun();

		Trig_Point[i] = CP_TOP.GetMeasResult(i, MVRET, TRIG_RESULT);
		VDD_FALL[i] = FPVI3.GetMeasResult(i, MVRET, Trig_Point[i]);
		VDD_OV_FALL->SetTestResult(i, 0, VDD_FALL[i]);
	}
	FPVI3.AwgClear();
	//CP_TOP.Set(FI, 0, FPVI10_20V, FPVI10_100MA, RELAY_SENSE_ON);
	FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);
	CP_TOP.Set(FI, 0, FPVI10_20V, FPVI10_10MA, RELAY_OFF);
	FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_10MA, RELAY_OFF);
	LED1K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED1A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED2.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED3.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED4.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED5K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED5A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED6.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED7.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED8.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED9K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED9A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED10.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED11.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED12.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED13K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED13A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED14.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED15.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED16.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	delay_ms(2);


    return 0;
}


DUT_API int VBG_TRIM(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *VBG_BEFORE = StsGetParam(funcindex,"VBG_BEFORE");
    CParam *VBG_TRIMCODE = StsGetParam(funcindex,"VBG_TRIMCODE");
    CParam *VBG_AFTER = StsGetParam(funcindex,"VBG_AFTER");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	////��Ʒ�ⲻ��
	////////////////////////////////////////////////////////////////////
	////���� VDD=5V������ vdd_1p5v �˿ڵ�ѹ������¼Ϊ V(vdd_1p5v),
	////���ݱ����޵�ֱ��V(vdd_1p5v)��ѹ���� 1517mV<V(vdd_1p5v)(1522.4mV) <1527.8mV
	//VDD_1D5V.Set(FI, 0, FPVI10_2V, FPVI10_1MA, RELAY_SENSE_ON);
	//delay_ms(2);
	//FPVI3.Set(FV, 5, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	//delay_ms(2);

	////FPVI3.MeasureVI(2000, 50);
	//VDD_1D5V.MeasureVI(200, 20);
	//for (i = 0; i<SITENUM; i++)
	//{
	//	adresult[i] = VDD_1D5V.GetMeasResult(i, MVRET);
	//	VBG_BEFORE->SetTestResult(i, 0, adresult[i] * 1E3);
	//}

	//FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	//delay_ms(2);
	//FPVI3.Set(FV, 0.0, FPVI10_10V, FPVI10_100MA, RELAY_OFF);
	//VDD_1D5V.Set(FI, 0, FPVI10_2V, FPVI10_1MA, RELAY_OFF);
	//delay_ms(2);
    return 0;
}


DUT_API int f_OSC_TRIM(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *f_OSC_128_BEFORE = StsGetParam(funcindex,"f_OSC_128_BEFORE");
    CParam *f_OSC_128_TRIMCODE = StsGetParam(funcindex,"f_OSC_128_TRIMCODE");
    CParam *f_OSC_128_AFTER = StsGetParam(funcindex,"f_OSC_128_AFTER");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	//��Ʒ�ⲻ��
	//////////////////////////////////////////////////////////////////
	//���� VDD=5V������ pin test_osc������ f Ƶ�ʣ�����¼Ϊ f(osc/128)��
	//���ݱ����޵�ֱ��f(osc / 128)Ƶ������ 123.3kHz<f(osc / 128)(124.8kHz) <125.9kHz
//	CBIT.SetOn(K7, -1);  //OSC��TMU��������˷žͰ�R4�̵ĵط�����
//	delay_ms(2);
////	OSC.Set(FI, 0, FPVI10_20V, FPVI10_1MA, RELAY_SENSE_ON);
////	delay_ms(2);
//
//	FPVI3.Set(FV, 5, FPVI10_10V, FPVI10_100MA, RELAY_ON);
//	delay_ms(2);
//	qtmu1.Init();
//	qtmu1.SetStartInput(QTMU_PLUS_IMPEDANCE_1M, QTMU_PLUS_VRNG_25V, QTMU_PLUS_FILTER_PASS);
//	qtmu1.SetStopInput(QTMU_PLUS_IMPEDANCE_1M, QTMU_PLUS_VRNG_25V, QTMU_PLUS_FILTER_PASS);
//	qtmu1.SetStartTrigger(1, QTMU_PLUS_POS_SLOPE);//trigger=1V, Rising edge
//	qtmu1.SetStopTrigger(1, QTMU_PLUS_POS_SLOPE);//trigger=1V, Rising edge
//	qtmu1.SetInSource(QTMU_PLUS_SINGLE_SOURCE); //SINGLE_SOURCE
//	qtmu1.Connect();
//
//	qtmu1.MeasFreq(QTMU_PLUS_COARSE, QTMU_PLUS_TIME_US, 5, 100);
//	delay_ms(2);
////	FPVI3.MeasureVI(200, 20);
////	OSC.MeasureVI(2000, 1);
//	for (i = 0; i<SITENUM; i++)
//	{
//		adresult[i] = qtmu1.GetMeasureResult(i);
//		f_OSC_128_BEFORE->SetTestResult(i, 0, adresult[i]);
//	}
//	delay_ms(1);
//	qtmu1.Disconnect();
//	FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
//	delay_ms(2);
//	FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_100MA, RELAY_OFF);
//	delay_ms(2);
//
//	CBIT.SetOn(-1);
//	delay_ms(2);

    return 0;
}


DUT_API int VCP(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *DELTA_VCP_LED_0V = StsGetParam(funcindex,"DELTA_VCP_LED_0V");
    CParam *DELTA_VCP_LED16_10V = StsGetParam(funcindex,"DELTA_VCP_LED16_10V");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here


	CBIT.SetOn(K9, K8, -1);
	delay_ms(2);

	double test_sample = 100;
	double test_cycle = 20;//us
	////////////////////////////////////////////////////////////
	//VDD=5V��VLDEx=0V������pin����      CP_TOP��CP_BOT��Ӳ�ѹ��
	/////////////////////////LED=0V/////////////////////////////
	LED1K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED1A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED2.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED3.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED4.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED5K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED5A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED6.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED7.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED8.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED9K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED9A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED10.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED11.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED12.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED13K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED13A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED14.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED15.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED16.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	CP_TOP.Set(FI, 0, FPVI10_20V, FPVI10_10MA, RELAY_SENSE_ON);
	//FPVI1.Set(FI, 0, FPVI10_20V, FPVI10_10MA, RELAY_SENSE_ON);
	FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);
	FPVI3.Set(FV, 5, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);

	CP_TOP.MeasureVI(test_sample, test_cycle);
	//FPVI1.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult1[i] = CP_TOP.GetMeasResult(i, MVRET);
		//VCP_TOP_LED_0V->SetTestResult(i, 0, adresult1[i]);
		//adresult2[i] = FPVI1.GetMeasResult(i, MVRET);
		//VCP_BOT_LED_0V->SetTestResult(i, 0, adresult2[i]);
		//DELTA_VCP_LED_0V->SetTestResult(i, 0, adresult1[i] - adresult2[i]);
		DELTA_VCP_LED_0V->SetTestResult(i, 0, adresult1[i]);
	}

	////////////////////////////////////////////////////////////
	//VDD=5V��VLDE16=10V������pin����      CP_TOP��CP_BOT��Ӳ�ѹ��
	/////////////////////////LED=0V/////////////////////////////
	CP_TOP.Set(FI, 0, FPVI10_100V, FPVI10_100MA, RELAY_SENSE_ON);
	//FPVI1.Set(FI, 0, FPVI10_100V, FPVI10_100MA, RELAY_SENSE_ON);
	LED16.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(2);
	LED16.Set(FV, 10, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(2);
	CP_TOP.MeasureVI(test_sample, test_cycle);
	//FPVI1.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult1[i] = CP_TOP.GetMeasResult(i, MVRET);
		//VCP_TOP_LED16_10V->SetTestResult(i, 0, adresult1[i]);
		//adresult2[i] = FPVI1.GetMeasResult(i, MVRET);
		//VCP_BOT_LED16_10V->SetTestResult(i, 0, adresult2[i]);
		//DELTA_VCP_LED16_10V->SetTestResult(i, 0, adresult1[i] - adresult2[i]);
		DELTA_VCP_LED16_10V->SetTestResult(i, 0, adresult1[i]);
	}


	LED16.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(2);
	FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);
	CP_TOP.Set(FI, 0, FPVI10_20V, FPVI10_100MA, RELAY_SENSE_ON);
	//FPVI1.Set(FI, 0, FPVI10_20V, FPVI10_100MA, RELAY_SENSE_ON);
	LED16.Set(FV, 0, FOVI_2V, FOVI_100MA, RELAY_ON);
	delay_ms(2);
	CP_TOP.Set(FI, 0, FPVI10_20V, FPVI10_10MA, RELAY_OFF);
	//FPVI1.Set(FI, 0, FPVI10_20V, FPVI10_10MA, RELAY_OFF);
	FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_10MA, RELAY_OFF);
	LED1K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED1A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED2.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED3.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED4.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED5K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED5A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED6.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED7.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED8.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED9K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED9A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED10.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED11.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED12.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED13K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED13A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED14.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED15.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED16.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	delay_ms(2);

	CBIT.SetOn(-1);
	delay_ms(2);

    return 0;
}


DUT_API int VCP_ERR(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *DELTA_VCP_RISE = StsGetParam(funcindex,"DELTA_VCP_RISE");
    CParam *DELTA_VCP_FALL = StsGetParam(funcindex,"DELTA_VCP_FALL");
    //}}AFX_STS_PARAM_PROTOTYPES

 //   // TODO: Add your function code here
	/////////////////////////////////////////////////////////////////////////////////////////////////
	//VDD=5V��VLDE15=0V��VCP_BOT=5V��VCP_TOP��10.3V������12V����1mV��
	//�Ĵ���0x00=60��0x82=00��0x38=10��LED15��LED16֮������1k�����裬��LED16�˿ڹ����10mA����Դ20V����
	//����pin���� ����LED��0V����������ȸ�CP_BOT 5V���ٸ���CP_TOP��CP_BOT��ӣ���CP_TOP 5.3V-7V
	//��VLED16��10V���䵽С��8Vʱ����¼VCP_TOP - VCP_BOT�ĵ�ѹΪVCP_ERR_R
	CBIT.SetOn(K8, K5, K99, K100,  -1);
	delay_ms(2);

	double test_sample = 30;
	double test_cycle = 20;//us
	FPVI3.Set(FV, 5, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);
	//LED1K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//LED1A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//LED2.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//LED3.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//LED4.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//LED5K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//LED5A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//LED6.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//LED7.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//LED8.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//LED9K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//LED9A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//LED10.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//LED11.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//LED12.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//LED13K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//LED13A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//LED14.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//FPVI6.Set(FV, 7, FPVI10_50V, FPVI10_100MA, RELAY_ON);
	//delay_ms(3);
	LED15.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_ON);
	delay_ms(20);
	LED16.Set(FI, 0, FOVI_20V, FOVI_100MA, RELAY_SENSE_ON);
	delay_ms(2);



	DWORD DATA = 0x60;
	DWORD Reg_Address = 0x00;
	UART_CH.Connect();
	delay_ms(5);
	UART_trans.UART16_Write_Data_Single_Mode(UART_CH, Write_Init, DevID_VOL, Reg_Address, DATA);
	delay_ms(5);
	DATA = 0x00;
	Reg_Address = 0x82;
	UART_trans.UART16_Write_Data_Single_Mode(UART_CH, Write_Init, DevID_VOL, Reg_Address, DATA);
	delay_ms(5);
	DATA = 0x10;
	Reg_Address = 0x38;
	UART_trans.UART16_Write_Data_Single_Mode(UART_CH, Write_Init, DevID_VOL, Reg_Address, DATA);
	delay_ms(5);

	LED16.Set(FI, 10e-3, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(2);
	//LED16.MeasureVI(1000, 20);

	FPVI1.Set(FV, 5, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);
	////////////////////////////AWG_RISE/////////////////////////
	double TRIG_RISE = DELTA_VCP_RISE->GetConditionCurSelDouble("Trigger");
	double V_Rise_Start = DELTA_VCP_RISE->GetConditionCurSelDouble("Voltage_start");
	double V_Rise_Stop = DELTA_VCP_RISE->GetConditionCurSelDouble("Voltage_stop");
	int Step_Rise = 5;//1mV
	long data_temp_rise = ceil(fabs(V_Rise_Start - V_Rise_Stop)*1e3);
	int sam_rise = data_temp_rise / Step_Rise + data_temp_rise % Step_Rise;

	double Trig_Point[NUM_SITE] = { 0.0 };
	int T_Point[NUM_SITE] = { 0 };
	double CP_RISE[NUM_SITE] = { 0 };
	double CP_FALL[NUM_SITE] = { 0 };
	int interval = 100; //100us
	double delta[NUM_SITE] = { 0 };
	double UP_awg_pattern_L[2048] = { 0.0 };
	double DOWN_awg_pattern_L[2048] = { 0.0 };
	double UP_awg_pattern_S[2048] = { 0.0 };
	double DOWN_awg_pattern_S[2048] = { 0.0 };

	CP_TOP.Set(FV, V_Rise_Start, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);
	STSAWGCreateRampData(&UP_awg_pattern_L[0], sam_rise, 1, V_Rise_Start, V_Rise_Stop);
	CP_TOP.AwgLoader("CP_RISE", FV, FPVI10_10V, FPVI10_100MA, UP_awg_pattern_L, sam_rise);
	CP_TOP.Set(FV, V_Rise_Start, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);
	CP_TOP.AwgSelect("CP_RISE", 0, sam_rise - 1, sam_rise - 1, interval);
	LED16.SetMeasVTrig(TRIG_RISE, TRIG_FALLING);
	CP_TOP.MeasureVI(sam_rise, interval, MEAS_AWG);
	LED16.MeasureVI(sam_rise, interval, MEAS_AWG);
	STSEnableAWG(&CP_TOP);
	STSEnableMeas(&CP_TOP, &LED16);
	STSAWGRunTriggerStop(&LED16, &LED16, &CP_TOP);
	//STSAWGRun();
	for (size_t i = 0; i < NUM_SITE; i++)
	{
		Trig_Point[i] = LED16.GetMeasResult(i, MVRET, TRIG_RESULT);
		CP_RISE[i] = CP_TOP.GetMeasResult(i, MVRET, Trig_Point[i]);
		DELTA_VCP_RISE->SetTestResult(i, 0, CP_RISE[i]);
	}
	CP_TOP.AwgClear();
	/////////////////////////////////////////////////////////////////////////////////////////////////
	//VDD=5V��VLDE15=0V��VCP_BOT=5V��VCP_TOP��10.3V�½���9.2V����1mV��
	//�Ĵ���0x00=60��0x82=00��0x38=10��LED15��LED16֮������1k�����裬��LED16�˿ڹ����10mA����Դ20V����
	//����pin����     �ȸ�����״̬����falling��
	//��VLED16���䵽10Vʱ����¼VCP_TOP - VCP_BOT�ĵ�ѹΪVCP_ERR_F
	double TRIG_FALL = DELTA_VCP_FALL->GetConditionCurSelDouble("Trigger");
	double V_Fall_Start = DELTA_VCP_FALL->GetConditionCurSelDouble("Voltage_start");
	double V_Fall_Stop = DELTA_VCP_FALL->GetConditionCurSelDouble("Voltage_stop");
	int Step_Fall = 5;//1mV
	long data_temp_fall = ceil(fabs(V_Fall_Start - V_Fall_Stop)*1e3);
	int sam_fall = data_temp_fall / Step_Fall + data_temp_fall % Step_Fall;

	STSAWGCreateRampData(&DOWN_awg_pattern_L[0], sam_fall, 1, V_Fall_Start, V_Fall_Stop);
	CP_TOP.AwgLoader("CP_FALL", FV, FPVI10_10V, FPVI10_100MA, DOWN_awg_pattern_L, sam_fall);
	CP_TOP.Set(FV, V_Fall_Start, FPVI10_10V, FPVI10_100MA, RELAY_ON, 2);
	delay_ms(1);
	CP_TOP.AwgSelect("CP_FALL", 0, sam_fall - 1, sam_fall - 1, interval);
	LED16.SetMeasVTrig(TRIG_FALL, TRIG_RISING);
	CP_TOP.MeasureVI(sam_fall, interval, MEAS_AWG);
	LED16.MeasureVI(sam_fall, interval, MEAS_AWG);
	STSEnableAWG(&CP_TOP);
	STSEnableMeas(&CP_TOP, &LED16);
	STSAWGRunTriggerStop(&LED16, &LED16, &CP_TOP);

	for (size_t i = 0; i < NUM_SITE; i++)
	{
		Trig_Point[i] = LED16.GetMeasResult(i, MVRET, TRIG_RESULT);
		CP_FALL[i] = CP_TOP.GetMeasResult(i, MVRET, Trig_Point[i]);
		DELTA_VCP_FALL->SetTestResult(i, 0, CP_FALL[i]);
	}

	CP_TOP.AwgClear();
	UART_CH.Disconnect();
	delay_ms(5);
	FPVI1.Set(FV, 0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);
	LED16.Set(FI, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(2);
	FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);
	CP_TOP.Set(FV, 0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);
	FPVI6.Set(FV, 0, FPVI10_50V, FPVI10_100MA, RELAY_ON);
	delay_ms(5);
	//LED16.Set(FI, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(2);
	LED15.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(2);

	CBIT.SetOn(-1);
	delay_ms(2);
	//LED16.Set(FI, 0, FOVI_20V, FOVI_100MA, RELAY_OFF);
	//delay_ms(2);
	LED15.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_OFF);
	delay_ms(2);
	FPVI6.Set(FV, 0, FPVI10_50V, FPVI10_100MA, RELAY_OFF);
	delay_ms(5);
	LED16.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	//LED16.Set(FV, 0, FOVI_2V, FOVI_100MA, RELAY_ON);
	//delay_ms(2);
	FPVI1.Set(FV, 0, FPVI10_10V, FPVI10_100MA, RELAY_OFF);
	CP_TOP.Set(FI, 0, FPVI10_10V, FPVI10_10MA, RELAY_OFF);
	FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_10MA, RELAY_OFF);

	delay_ms(2);
	/*LED1K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED1A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED2.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED3.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED4.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED5K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED5A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED6.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED7.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED8.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED9K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED9A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED10.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED11.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED12.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED13K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED13A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED14.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);*/
	//LED15.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);




    return 0;
}


DUT_API int ICP_LIM(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *I_CP_BOT_LIM = StsGetParam(funcindex,"I_CP_BOT_LIM");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	double test_sample = 100;
	double test_cycle = 20;//us
	/////////////////////////////////////////////////////////////
	//VDD=5V��VLDEx=0V��VCP_BOT=0V������pin���գ���¼CP_BOT����������ΪICP_LIM
	LED1K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED1A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED2.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED3.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED4.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED5K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED5A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED6.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED7.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED8.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED9K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED9A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED10.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED11.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED12.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED13K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED13A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED14.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED15.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED16.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//CP_TOP.Set(FV, 0, FPVI10_2V, FPVI10_100MA, RELAY_ON);
	FPVI1.Set(FV, 0, FPVI10_100MV, FPVI10_100MA, RELAY_ON);
	FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);
	FPVI3.Set(FV, 5, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);

	FPVI1.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FPVI1.GetMeasResult(i, MIRET);
		I_CP_BOT_LIM->SetTestResult(i, 0, -adresult[i] * 1E3);
	}

	FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);
	//CP_TOP.Set(FV, 0, FPVI10_20V, FPVI10_10MA, RELAY_ON);
	FPVI1.Set(FV, 0, FPVI10_100MV, FPVI10_10MA, RELAY_ON);
	delay_ms(2);

	//CP_TOP.Set(FV, 0, FPVI10_20V, FPVI10_10MA, RELAY_OFF);
	FPVI1.Set(FV, 0, FPVI10_100MV, FPVI10_10MA, RELAY_OFF);
	FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_10MA, RELAY_OFF);
	LED1K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED1A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED2.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED3.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED4.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED5K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED5A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED6.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED7.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED8.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED9K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED9A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED10.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED11.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED12.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED13K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED13A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED14.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED15.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED16.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	delay_ms(2);

    return 0;
}


DUT_API int f_CP(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *f_CP_TOP = StsGetParam(funcindex,"f_CP_TOP");
    //}}AFX_STS_PARAM_PROTOTYPES

 ////   // TODO: Add your function code here
	//////VDD = 5V��VLDEx = 0V��C(CP) = 1pF��С���ݣ������üĴ��� 0x80 = 00h���رն�Ƶ��������pin ����
	//////��¼ CP_TOP ��Ƶ��Ϊ fCP  7.92M< fCP(8M)<8.08M
	//CBIT.SetOn(K15, K99, K100,  K107, -1);
	//delay_ms(2);
	//LED1K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//LED1A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//LED2.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//LED3.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//LED4.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//LED5K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//LED5A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//LED6.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//LED7.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//LED8.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//LED9K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//LED9A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//LED10.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//LED11.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//LED12.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//LED13K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//LED13A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//LED14.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//LED15.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//LED16.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	//delay_ms(2);
	//FPVI3.Set(FV, 5, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	//delay_ms(2);
	//PULL_UP.Set(FV, 5, FOVI_10V, FOVI_100MA, RELAY_ON);
	//FOVI30.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	//FOVI29.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	//FOVI28.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	//FOVI31.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	//delay_ms(3);

	//FPVI3.Set(FV, 5.0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	//delay_ms(5);

	//DWORD DATA = 0x00;
	//DWORD Reg_Address = 0x80;
	//UART_CH.Connect();
	//delay_ms(5);
	//UART_trans.UART16_Write_Data_Single_Mode(UART_CH, Write_Init, DevID_VOL, Reg_Address, DATA);
	//delay_ms(2);
	////UART_trans.UART16_Write_Data_Single_Mode(UART_CH, Write_Init, DevID_VOL, Reg_Address, DATA);
	////delay_ms(2);
	////UART_trans.UART16_Read_Data_Single_Mode(UART_CH, Read_Init, DevID_VOL, Reg_Address);
	////delay_ms(5);
	//qtmu2.Init();
	//qtmu2.SetStartInput(QTMU_PLUS_IMPEDANCE_1M, QTMU_PLUS_VRNG_25V, QTMU_PLUS_FILTER_PASS);
	//qtmu2.SetStopInput(QTMU_PLUS_IMPEDANCE_1M, QTMU_PLUS_VRNG_25V, QTMU_PLUS_FILTER_PASS);
	//qtmu2.SetStartTrigger(1, QTMU_PLUS_POS_SLOPE);//trigger=1V, Rising edge
	//qtmu2.SetStopTrigger(1, QTMU_PLUS_POS_SLOPE);//trigger=1V, Rising edge
	//qtmu2.SetInSource(QTMU_PLUS_SINGLE_SOURCE); //SINGLE_SOURCE
	//qtmu2.Connect();

	//qtmu2.MeasFreq(QTMU_PLUS_COARSE, QTMU_PLUS_TIME_NS, 5, 100);
	//delay_ms(2);
	//for (i = 0; i<SITENUM; i++)
	//{
	//	adresult[i] = qtmu2.GetMeasureResult(i);
	//	f_CP_TOP->SetTestResult(i, 0, adresult[i] / 1e6);
	//}
	//delay_ms(1);
	//qtmu2.Disconnect();
	//UART_CH.Disconnect();
	//delay_ms(5);

	//FPVI3.Set(FV, 0.0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	//PULL_UP.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_ON);
	//delay_ms(3);
	//FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	//delay_ms(2);
	//CBIT.SetOn(-1);
	//delay_ms(2);

	//FPVI3.Set(FV, 0.0, FPVI10_10V, FPVI10_10MA, RELAY_OFF);
	//PULL_UP.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);
	//FOVI30.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	//FOVI29.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	//FOVI28.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	//FOVI31.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	//delay_ms(3);
	//FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_10MA, RELAY_OFF);
	//LED1K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	//LED1A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	//LED2.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	//LED3.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	//LED4.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	//LED5K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	//LED5A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	//LED6.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	//LED7.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	//LED8.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	//LED9K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	//LED9A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	//LED10.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	//LED11.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	//LED12.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	//LED13K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	//LED13A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	//LED14.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	//LED15.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	//LED16.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	//delay_ms(2);

    return 0;
}


DUT_API int ICP_SRC(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *ICP_SRC_LED16 = StsGetParam(funcindex,"ICP_SRC_LED16");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	//////////////////////////////////////////////////////////////
	//VDD=5V��VLDE16=20V������pin���գ���¼VLED16����������ΪICP - SRC
	double test_sample = 30;
	double test_cycle = 20;//us

	//LED1K.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	//LED1A.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	//LED2.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	//LED3.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	//LED4.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	//LED5K.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	//LED5A.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	//LED6.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	//LED7.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	//LED8.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	//LED9K.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	//LED9A.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	//LED10.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	//LED11.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	//LED12.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	//LED13K.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	//LED13A.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	//LED14.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	//LED15.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	LED16.Set(FV, 17, FOVI_50V, FOVI_10MA, RELAY_ON);
	delay_ms(2);
	FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);
	FPVI3.Set(FV, 5, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);

	LED16.MeasureVI(test_sample, test_cycle);
	//LED16.MeasureVI(2000, 100);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED16.GetMeasResult(i, MIRET);
		ICP_SRC_LED16->SetTestResult(i, 0, adresult[i] * 1E3);
	}

	FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	LED16.Set(FV, 0, FOVI_50V, FOVI_10MA, RELAY_ON);
	delay_ms(2);
	LED16.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_ms(2);

	FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_100MA, RELAY_OFF);
	//LED1K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	//LED1A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	//LED2.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	//LED3.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	//LED4.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	//LED5K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	//LED5A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	//LED6.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	//LED7.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	//LED8.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	//LED9K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	//LED9A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	//LED10.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	//LED11.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	//LED12.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	//LED13K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	//LED13A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	//LED14.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	//LED15.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	LED16.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_OFF);
	delay_ms(5);


    return 0;
}


DUT_API int ICP_LOAD(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *VCS_MODE1 = StsGetParam(funcindex,"VCS_MODE1");
    CParam *DELTA_VCP_LOAD = StsGetParam(funcindex,"DELTA_VCP_LOAD");
    CParam *ICP_TOP_LOAD = StsGetParam(funcindex,"ICP_TOP_LOAD");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	//VDD = 5V���������ģʽsts14������pin����
	//��¼CP_TOP - CP_BOT�ĵ�ѹΪV1��CP_TOP�Եس������
	//��V1��Ϊԭ��ֵ��95%ʱ����¼CP_TOP����������ΪICP - LOAD    464uA< ICP_LOAD(480uA)<600uA

	//FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	//delay_ms(2);
	//FPVI3.Set(FV, 5.3, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	//delay_ms(2);
	FPVI3.Set(FV, 5.0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);
	//NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//NC4.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	NC4.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);

	//NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	////NC4.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//NC4.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_OFF);
	//delay_ms(2);
	////////////////////MODE1/////////////////////////////
	//NC4.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	//NC5.MeasureVI(200, 10);
	//NC4.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	//NC5.MeasureVI(200, 10);
	CS_NC3.Set(FI, 0, FOVI_2V, FOVI_1MA, RELAY_SENSE_ON);
	delay_ms(2);
	//����ģʽ1���룬��CS��ѹ��û��1.5V
	CS_NC3.MeasureVI(200, 10);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = CS_NC3.GetMeasResult(i, MVRET);
		VCS_MODE1->SetTestResult(i, 0, adresult[i]);
	}
	CS_NC3.Set(FI, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(2);
	//NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	////////////////////MODE2/////////////////////////////
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	////////////////////MODE3/////////////////////////////
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	//CS_NC3.Set(FI, 0, FOVI_2V, FOVI_1MA, RELAY_SENSE_ON);
	//delay_ms(2);
	////����ģʽ2���룬��CS��ѹ��û��464mV
	//CS_NC3.MeasureVI(200, 100);
	//for (i = 0; i<SITENUM; i++)
	//{
	//	adresult[i] = CS_NC3.GetMeasResult(i, MVRET);
	//	VCS_MODE1->SetTestResult(i, 1, adresult[i]);
	//}
	//CS_NC3.Set(FI, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	//delay_ms(2);
	////////////////////MODE4/////////////////////////////
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	////����ģʽ4���룬��CS��ѹ��û��0.352V
	//CS_NC3.Set(FI, 0, FOVI_1V, FOVI_1MA, RELAY_SENSE_ON);
	//delay_ms(2);
	//CS_NC3.MeasureVI(200, 100);
	//for (i = 0; i<SITENUM; i++)
	//{
	//	adresult[i] = CS_NC3.GetMeasResult(i, MVRET);
	//	VCS_MODE1->SetTestResult(i, 2, adresult[i]);
	//}
	//CS_NC3.Set(FI, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	//delay_ms(2);
	////////////////////MODE5/////////////////////////////
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	////////////////////MODE6/////////////////////////////
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	////////////////////MODE7/////////////////////////////
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	////////////////////MODE8/////////////////////////////
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	////////////////////MODE9/////////////////////////////
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	////////////////////MODE10/////////////////////////////
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	//CBIT.SetOn(K106, -1);
	//delay_ms(2);
	////����ģʽ10���룬��nc1 5v����nc2��vdd1p5v��
	////�ٸ�nc1 floating����nc2��vdd1p5v��
	//FOVI29.Set(FI, 0, FOVI_10V, FOVI_1MA, RELAY_SENSE_ON);
	//delay_ms(2);
	////VDD_1D5V.Set(FI, 0, FPVI10_10V, FPVI10_1MA, RELAY_SENSE_ON);
	////delay_ms(2);
	//FOVI28.Set(FV, 5, FOVI_10V, FOVI_100MA, RELAY_ON);
	//delay_ms(2);
	//FOVI29.MeasureVI(200, 100);
	////VDD_1D5V.MeasureVI(200, 100);
	//for (i = 0; i<SITENUM; i++)
	//{
	//	adresult[i] = FOVI29.GetMeasResult(i, MVRET);
	//	VCS_MODE1->SetTestResult(i, 3, adresult[i]);
	//	//adresult[i] = VDD_1D5V.GetMeasResult(i, MVRET);
	//	//VCS_MODE1->SetTestResult(i, 4, adresult[i]);
	//}

	//FOVI28.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_ON);
	//delay_ms(2);
	//FOVI28.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);
	//delay_ms(2);
	//FOVI29.MeasureVI(200, 100);
	////VDD_1D5V.MeasureVI(200, 100);
	//for (i = 0; i<SITENUM; i++)
	//{
	//	adresult[i] = FOVI29.GetMeasResult(i, MVRET);
	//	VCS_MODE1->SetTestResult(i, 5, adresult[i]);
	//	//adresult[i] = VDD_1D5V.GetMeasResult(i, MVRET);
	//	//VCS_MODE1->SetTestResult(i, 6, adresult[i]);
	//}


	//CBIT.SetOn(-1);
	//delay_ms(2);

	////////////////////MODE11/////////////////////////////
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	////////////////////MODE12/////////////////////////////
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	////////////////////MODE13/////////////////////////////
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	////////////////////MODE14/////////////////////////////
	NC4.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	//CP_TOP.Set(FI, 0, FPVI10_20V, FPVI10_10MA, RELAY_ON);
	//delay_ms(1);
	//CP_TOP.MeasureVI(100, 20);
	//����MODE14
	//CP���
	LED1K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED1A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED2.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED3.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED4.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED5K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED5A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED6.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED7.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED8.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED9K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED9A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED10.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED11.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED12.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED13K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED13A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED14.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED15.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED16.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	//CBIT.SetOn(K9, -1);
	//delay_ms(2);
	CBIT.SetOn(K9, K8, -1);
	delay_ms(2);
	CP_TOP.Set(FI, 0, FPVI10_20V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);
	CP_TOP.MeasureVI(100, 20);
	for (i = 0; i<SITENUM; i++)
	{
		adresult1[i] = CP_TOP.GetMeasResult(i, MVRET);
		DELTA_VCP_LOAD->SetTestResult(i, 0, adresult1[i]);
	}

	//FPVI1.Set(FI, -0, FPVI10_20V, FPVI10_1MA, RELAY_SENSE_ON);
	//delay_ms(1);
	//CP_TOP.Set(FI, -0, FPVI10_20V, FPVI10_1MA, RELAY_ON);
	//delay_ms(1);
	//CP_TOP.MeasureVI(100, 10);
	//FPVI1.MeasureVI(100, 10);
	//for (i = 0; i<SITENUM; i++)
	//{

	//	adresult1[i] = CP_TOP.GetMeasResult(i, MVRET)-FPVI1.GetMeasResult(i, MVRET);
	//	//adresult2[i] = CP_TOP.GetMeasResult(i, MVRET);
	//	DELTA_VCP_LOAD->SetTestResult(i, 0, adresult1[i]);
	//}
	int flag[SITENUM] = { 0 };
	BYTE sitesta[SITENUM] = { 0 };
	for (i = 0; i<SITENUM; i++)
	{
		flag[i] = 1;
	}

	StsGetSiteStatus(sitesta, SITENUM);
	for (i = 0; i<SITENUM; i++)
	{
		if (sitesta[i])
			flag[i] = 0;
	}
	//CBIT.SetOn(-1);
	//delay_ms(2);

	double j = 0;
	for (j = 450 * 1e-6; j < 620 * 1e-6; j = j + 10 * 1E-6)
	{
		//FPVI1.Set(FI, -0, FPVI10_20V, FPVI10_1MA, RELAY_SENSE_ON);
		//delay_ms(1);
		CP_TOP.Set(FI, -j, FPVI10_20V, FPVI10_10MA, RELAY_ON);
		delay_ms(1);
		CP_TOP.MeasureVI(100, 10);
		//FPVI1.MeasureVI(100, 10);
		for (i = 0; i<SITENUM; i++)
		{

			//adresult3[i] = FPVI1.GetMeasResult(i, MVRET);
			adresult2[i] = CP_TOP.GetMeasResult(i, MVRET);
			//adresult4[i] = adresult2[i] - adresult3[i];
			if ((flag[i] == 0) && ((adresult2[i] ) <0.95*adresult1[i]))
				{
					flag[i] = 1;
					adresult[0] = j;
				}			

			}

			if ((flag[0] == 1) && (flag[1] == 1) && (flag[2] == 1) && (flag[3] == 1))
				break;
	}
	for (i = 0; i < SITENUM; i++)
	{
		ICP_TOP_LOAD->SetTestResult(i, 0, adresult[i]*1E6);
	}

	//FPVI1.Set(FI, -0, FPVI10_20V, FPVI10_1MA, RELAY_OFF);
	//delay_ms(1);
	CP_TOP.Set(FI, -0, FPVI10_20V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);
	CP_TOP.Set(FI, -0, FPVI10_20V, FPVI10_10MA, RELAY_OFF);
	delay_ms(2);
	CBIT.SetOn(-1);
	delay_ms(2);
	//////////////////////MODE15/////////////////////////////
	//NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//////////////////////MODE16/////////////////////////////
	//NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//////////////////////MODE17/////////////////////////////
	//NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//////////////////////MODE18/////////////////////////////
	//NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	NC4.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(10);
	FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_OFF);
	NC4.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_OFF);
	delay_ms(10);
	FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_100MA, RELAY_OFF);
	delay_ms(5);

	return 0;
}


DUT_API int RDS_ON(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *DELTA_VLED1 = StsGetParam(funcindex,"DELTA_VLED1");
    CParam *DELTA_VLED2 = StsGetParam(funcindex,"DELTA_VLED2");
    CParam *DELTA_VLED3 = StsGetParam(funcindex,"DELTA_VLED3");
    CParam *DELTA_VLED4 = StsGetParam(funcindex,"DELTA_VLED4");
    CParam *DELTA_VLED5 = StsGetParam(funcindex,"DELTA_VLED5");
    CParam *DELTA_VLED6 = StsGetParam(funcindex,"DELTA_VLED6");
    CParam *DELTA_VLED7 = StsGetParam(funcindex,"DELTA_VLED7");
    CParam *DELTA_VLED8 = StsGetParam(funcindex,"DELTA_VLED8");
    CParam *DELTA_VLED9 = StsGetParam(funcindex,"DELTA_VLED9");
    CParam *DELTA_VLED10 = StsGetParam(funcindex,"DELTA_VLED10");
    CParam *DELTA_VLED11 = StsGetParam(funcindex,"DELTA_VLED11");
    CParam *DELTA_VLED12 = StsGetParam(funcindex,"DELTA_VLED12");
    CParam *DELTA_VLED13 = StsGetParam(funcindex,"DELTA_VLED13");
    CParam *DELTA_VLED14 = StsGetParam(funcindex,"DELTA_VLED14");
    CParam *DELTA_VLED15 = StsGetParam(funcindex,"DELTA_VLED15");
    CParam *DELTA_VLED16 = StsGetParam(funcindex,"DELTA_VLED16");
    CParam *RDS_ON_LED1 = StsGetParam(funcindex,"RDS_ON_LED1");
    CParam *RDS_ON_LED2 = StsGetParam(funcindex,"RDS_ON_LED2");
    CParam *RDS_ON_LED3 = StsGetParam(funcindex,"RDS_ON_LED3");
    CParam *RDS_ON_LED4 = StsGetParam(funcindex,"RDS_ON_LED4");
    CParam *RDS_ON_LED5 = StsGetParam(funcindex,"RDS_ON_LED5");
    CParam *RDS_ON_LED6 = StsGetParam(funcindex,"RDS_ON_LED6");
    CParam *RDS_ON_LED7 = StsGetParam(funcindex,"RDS_ON_LED7");
    CParam *RDS_ON_LED8 = StsGetParam(funcindex,"RDS_ON_LED8");
    CParam *RDS_ON_LED9 = StsGetParam(funcindex,"RDS_ON_LED9");
    CParam *RDS_ON_LED10 = StsGetParam(funcindex,"RDS_ON_LED10");
    CParam *RDS_ON_LED11 = StsGetParam(funcindex,"RDS_ON_LED11");
    CParam *RDS_ON_LED12 = StsGetParam(funcindex,"RDS_ON_LED12");
    CParam *RDS_ON_LED13 = StsGetParam(funcindex,"RDS_ON_LED13");
    CParam *RDS_ON_LED14 = StsGetParam(funcindex,"RDS_ON_LED14");
    CParam *RDS_ON_LED15 = StsGetParam(funcindex,"RDS_ON_LED15");
    CParam *RDS_ON_LED16 = StsGetParam(funcindex,"RDS_ON_LED16");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	//VDD=5V��VLDE16�˿ڹ������1A������pin���գ�
	//��¼VLDE16 - VLDE15��������RDS(ON) = VLDE16 - VLDE15 / 1A      RDS(ON) (140m��)
	double test_sample = 200;
	double test_cycle = 20;//us
	///////////////////LED16///////////////////////////////////////////////////////////

	//FPVI3.Set(FV, 5, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	//delay_ms(2);
	//LED15.Set(FI, 0.0, FOVI_1V, FOVI_1MA, RELAY_SENSE_ON);
	//delay_ms(2);
	//LED15.MeasureVI(test_sample, test_cycle);
	//LED16.Set(FI, 50E-3, FOVI_1V, FOVI_1A, RELAY_ON,10);
	//delay_ms(2);
	//LED16.MeasureVI(test_sample, test_cycle);


	//LED16.MeasureVI(test_sample, test_cycle);
	//LED15.MeasureVI(test_sample, test_cycle);
	//for (i = 0; i<SITENUM; i++)
	//{
	//	adresult1[i] = LED16.GetMeasResult(i, MVRET);
	//	adresult2[i] = LED15.GetMeasResult(i, MVRET);
	//	adresult[i] = LED16.GetMeasResult(i, MVRET) - LED15.GetMeasResult(i, MVRET);
	//	DELTA_VLED16->SetTestResult(i, 0, adresult[i] * 1E3);
	//	RDS_ON_LED16->SetTestResult(i, 0, adresult[i] / 50E-3 * 1E3);
	//}
	//LED16.Set(FI, 0.0, FOVI_1V, FOVI_1A, RELAY_ON);
	//delay_ms(2);
	//LED16.Set(FI, 0.0, FOVI_1V, FOVI_1A, RELAY_OFF);
	//delay_ms(2);
	//FPVI3.Set(FV, 0, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	//delay_ms(2);

	/////////////////////////////////////////////////////////////////////////////////
	/////////////////LED16///////////////////////////////////////////////////////////
	CBIT.SetOn(K32, -1);
	delay_ms(2);

	FPVI3.Set(FV, 5, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);
	FPVI4.Set(FI, 0.1, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(2);

	FPVI4.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FPVI4.GetMeasResult(i, MVRET);
		DELTA_VLED16->SetTestResult(i, 0, adresult[i] * 1E3);
		//RDS_ON_LED16->SetTestResult(i, 0, adresult[i] / 0.1 * 1E3);
	}
	FPVI4.Set(FI, 0, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(2);
	FPVI3.Set(FV, 0, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);

	///////////////////LED15///////////////////////////////////////////////////////////
	CBIT.SetOn(K47, -1);
	delay_ms(2);

	FPVI3.Set(FV, 5, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);
	FPVI4.Set(FI, 0.1, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(2);

	FPVI4.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FPVI4.GetMeasResult(i, MVRET);
		DELTA_VLED15->SetTestResult(i, 0, adresult[i] * 1E3);
		RDS_ON_LED15->SetTestResult(i, 0, adresult[i] / 0.1 * 1E3);
	}
	FPVI4.Set(FI, 0, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(2);
	FPVI4.Set(FI, 0, FPVI10_1V, FPVI10_1A, RELAY_OFF);
	delay_ms(5);
	//FPVI3.Set(FV, 0, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	//delay_ms(2);

	///////////////////LED14///////////////////////////////////////////////////////////
	CBIT.SetOn(K46, -1);
	delay_ms(2);

	FPVI3.Set(FV, 5, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);
	FPVI4.Set(FI, 0.1, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(2);

	FPVI4.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FPVI4.GetMeasResult(i, MVRET);
		DELTA_VLED14->SetTestResult(i, 0, adresult[i] * 1E3);
		RDS_ON_LED14->SetTestResult(i, 0, adresult[i] / 0.1 * 1E3);
	}
	FPVI4.Set(FI, 0, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(2);
	FPVI3.Set(FV, 0, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);

	///////////////////LED13///////////////////////////////////////////////////////////
	CBIT.SetOn(K45, -1);
	delay_ms(2);

	FPVI3.Set(FV, 5, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);
	FPVI4.Set(FI, 0.1, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(2);

	FPVI4.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FPVI4.GetMeasResult(i, MVRET);
		DELTA_VLED13->SetTestResult(i, 0, adresult[i] * 1E3);
		RDS_ON_LED13->SetTestResult(i, 0, adresult[i] / 0.1 * 1E3);
	}
	FPVI4.Set(FI, 0, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(2);
	FPVI3.Set(FV, 0, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);

	/////////////////LED12///////////////////////////////////////////////////////////
	CBIT.SetOn(K44, -1);
	delay_ms(2);

	FPVI3.Set(FV, 5, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);
	FPVI4.Set(FI, 0.1, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(2);

	FPVI4.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FPVI4.GetMeasResult(i, MVRET);
		DELTA_VLED12->SetTestResult(i, 0, adresult[i] * 1E3);
		RDS_ON_LED12->SetTestResult(i, 0, adresult[i] / 0.1 * 1E3);
	}
	FPVI4.Set(FI, 0, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(2);
	FPVI3.Set(FV, 0, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);

	/////////////////LED11///////////////////////////////////////////////////////////
	CBIT.SetOn(K43, -1);
	delay_ms(2);

	FPVI3.Set(FV, 5, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);
	FPVI4.Set(FI, 0.1, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(2);

	FPVI4.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FPVI4.GetMeasResult(i, MVRET);
		DELTA_VLED11->SetTestResult(i, 0, adresult[i] * 1E3);
		RDS_ON_LED11->SetTestResult(i, 0, adresult[i] / 0.1 * 1E3);
	}
	FPVI4.Set(FI, 0, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(2);
	FPVI3.Set(FV, 0, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);

	/////////////////LED10///////////////////////////////////////////////////////////
	CBIT.SetOn(K42, -1);
	delay_ms(2);

	FPVI3.Set(FV, 5, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);
	FPVI4.Set(FI, 0.1, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(2);

	FPVI4.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FPVI4.GetMeasResult(i, MVRET);
		DELTA_VLED10->SetTestResult(i, 0, adresult[i] * 1E3);
		RDS_ON_LED10->SetTestResult(i, 0, adresult[i] / 0.1 * 1E3);
	}
	FPVI4.Set(FI, 0, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(2);
	FPVI3.Set(FV, 0, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);

	/////////////////LED9///////////////////////////////////////////////////////////
	CBIT.SetOn(K41, -1);
	delay_ms(2);

	FPVI3.Set(FV, 5, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);
	FPVI4.Set(FI, 0.1, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(2);

	FPVI4.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FPVI4.GetMeasResult(i, MVRET);
		DELTA_VLED9->SetTestResult(i, 0, adresult[i] * 1E3);
		RDS_ON_LED9->SetTestResult(i, 0, adresult[i] / 0.1 * 1E3);
	}
	FPVI4.Set(FI, 0, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(2);
	FPVI3.Set(FV, 0, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);

	/////////////////LED8///////////////////////////////////////////////////////////
	CBIT.SetOn(K40, -1);
	delay_ms(2);

	FPVI3.Set(FV, 5, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);
	FPVI4.Set(FI, 0.1, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(2);

	FPVI4.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FPVI4.GetMeasResult(i, MVRET);
		DELTA_VLED8->SetTestResult(i, 0, adresult[i] * 1E3);
		RDS_ON_LED8->SetTestResult(i, 0, adresult[i] / 0.1 * 1E3);
	}
	FPVI4.Set(FI, 0, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(2);
	FPVI3.Set(FV, 0, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);

	/////////////////LED7///////////////////////////////////////////////////////////
	CBIT.SetOn(K39, -1);
	delay_ms(2);

	FPVI3.Set(FV, 5, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);
	FPVI4.Set(FI, 0.1, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(2);

	FPVI4.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FPVI4.GetMeasResult(i, MVRET);
		DELTA_VLED7->SetTestResult(i, 0, adresult[i] * 1E3);
		RDS_ON_LED7->SetTestResult(i, 0, adresult[i] / 0.1 * 1E3);
	}
	FPVI4.Set(FI, 0, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(2);
	FPVI3.Set(FV, 0, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);

	/////////////////LED6///////////////////////////////////////////////////////////
	CBIT.SetOn(K38, -1);
	delay_ms(2);

	FPVI3.Set(FV, 5, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);
	FPVI4.Set(FI, 0.1, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(2);

	FPVI4.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FPVI4.GetMeasResult(i, MVRET);
		DELTA_VLED6->SetTestResult(i, 0, adresult[i] * 1E3);
		RDS_ON_LED6->SetTestResult(i, 0, adresult[i] / 0.1 * 1E3);
	}
	FPVI4.Set(FI, 0, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(2);
	FPVI3.Set(FV, 0, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);

	///////////////////LED5///////////////////////////////////////////////////////////
	CBIT.SetOn(K37, -1);
	delay_ms(2);

	FPVI3.Set(FV, 5, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);
	FPVI4.Set(FI, 0.1, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(2);

	FPVI4.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FPVI4.GetMeasResult(i, MVRET);
		DELTA_VLED5->SetTestResult(i, 0, adresult[i] * 1E3);
		RDS_ON_LED5->SetTestResult(i, 0, adresult[i] / 0.1 * 1E3);
	}
	FPVI4.Set(FI, 0, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(2);
	FPVI3.Set(FV, 0, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);

	///////////////////LED4///////////////////////////////////////////////////////////
	CBIT.SetOn(K36, -1);
	delay_ms(2);

	FPVI3.Set(FV, 5, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);
	FPVI4.Set(FI, 0.1, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(2);

	FPVI4.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FPVI4.GetMeasResult(i, MVRET);
		DELTA_VLED4->SetTestResult(i, 0, adresult[i] * 1E3);
		RDS_ON_LED4->SetTestResult(i, 0, adresult[i] / 0.1 * 1E3);
	}
	FPVI4.Set(FI, 0, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(2);
	FPVI3.Set(FV, 0, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);

	/////////////////LED3///////////////////////////////////////////////////////////
	CBIT.SetOn(K35, -1);
	delay_ms(2);

	FPVI3.Set(FV, 5, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);
	FPVI4.Set(FI, 0.1, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(2);

	FPVI4.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FPVI4.GetMeasResult(i, MVRET);
		DELTA_VLED3->SetTestResult(i, 0, adresult[i] * 1E3);
		RDS_ON_LED3->SetTestResult(i, 0, adresult[i] / 0.1 * 1E3);
	}
	FPVI4.Set(FI, 0, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(2);
	FPVI3.Set(FV, 0, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);

	/////////////////LED2///////////////////////////////////////////////////////////
	CBIT.SetOn(K34, -1);
	delay_ms(2);

	FPVI3.Set(FV, 5, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);
	FPVI4.Set(FI, 0.1, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(2);

	FPVI4.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FPVI4.GetMeasResult(i, MVRET);
		DELTA_VLED2->SetTestResult(i, 0, adresult[i] * 1E3);
		RDS_ON_LED2->SetTestResult(i, 0, adresult[i] / 0.1 * 1E3);
	}
	FPVI4.Set(FI, 0, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(2);
	FPVI3.Set(FV, 0, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);

	///////////////////LED1///////////////////////////////////////////////////////////
	CBIT.SetOn(K33, -1);
	delay_ms(2);

	FPVI3.Set(FV, 5, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);
	FPVI4.Set(FI, 0.1, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(2);

	FPVI4.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FPVI4.GetMeasResult(i, MVRET);
		DELTA_VLED1->SetTestResult(i, 0, adresult[i] * 1E3);
		RDS_ON_LED1->SetTestResult(i, 0, adresult[i] / 0.1 * 1E3);
	}



	FPVI4.Set(FI, 0, FPVI10_2V, FPVI10_1A, RELAY_ON);
	delay_ms(2);
	FPVI3.Set(FV, 0, FPVI10_2V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);
	FPVI3.Set(FV, 0, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);
	CBIT.SetOn(-1);
	delay_ms(20);
	FPVI4.Set(FI, 0, FPVI10_2V, FPVI10_1A, RELAY_OFF);
	FPVI3.Set(FV, 0, FPVI10_2V, FPVI10_10MA, RELAY_OFF);
	delay_ms(2);



    return 0;
}


DUT_API int RDS_OFF(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *IOFF_LED1 = StsGetParam(funcindex,"IOFF_LED1");
    CParam *IOFF_LED2 = StsGetParam(funcindex,"IOFF_LED2");
    CParam *IOFF_LED3 = StsGetParam(funcindex,"IOFF_LED3");
    CParam *IOFF_LED4 = StsGetParam(funcindex,"IOFF_LED4");
    CParam *IOFF_LED5 = StsGetParam(funcindex,"IOFF_LED5");
    CParam *IOFF_LED6 = StsGetParam(funcindex,"IOFF_LED6");
    CParam *IOFF_LED7 = StsGetParam(funcindex,"IOFF_LED7");
    CParam *IOFF_LED8 = StsGetParam(funcindex,"IOFF_LED8");
    CParam *IOFF_LED9 = StsGetParam(funcindex,"IOFF_LED9");
    CParam *IOFF_LED10 = StsGetParam(funcindex,"IOFF_LED10");
    CParam *IOFF_LED11 = StsGetParam(funcindex,"IOFF_LED11");
    CParam *IOFF_LED12 = StsGetParam(funcindex,"IOFF_LED12");
    CParam *IOFF_LED13 = StsGetParam(funcindex,"IOFF_LED13");
    CParam *IOFF_LED14 = StsGetParam(funcindex,"IOFF_LED14");
    CParam *IOFF_LED15 = StsGetParam(funcindex,"IOFF_LED15");
    CParam *IOFF_LED16 = StsGetParam(funcindex,"IOFF_LED16");
    CParam *RDS_OFF_LED1 = StsGetParam(funcindex,"RDS_OFF_LED1");
    CParam *RDS_OFF_LED2 = StsGetParam(funcindex,"RDS_OFF_LED2");
    CParam *RDS_OFF_LED3 = StsGetParam(funcindex,"RDS_OFF_LED3");
    CParam *RDS_OFF_LED4 = StsGetParam(funcindex,"RDS_OFF_LED4");
    CParam *RDS_OFF_LED5 = StsGetParam(funcindex,"RDS_OFF_LED5");
    CParam *RDS_OFF_LED6 = StsGetParam(funcindex,"RDS_OFF_LED6");
    CParam *RDS_OFF_LED7 = StsGetParam(funcindex,"RDS_OFF_LED7");
    CParam *RDS_OFF_LED8 = StsGetParam(funcindex,"RDS_OFF_LED8");
    CParam *RDS_OFF_LED9 = StsGetParam(funcindex,"RDS_OFF_LED9");
    CParam *RDS_OFF_LED10 = StsGetParam(funcindex,"RDS_OFF_LED10");
    CParam *RDS_OFF_LED11 = StsGetParam(funcindex,"RDS_OFF_LED11");
    CParam *RDS_OFF_LED12 = StsGetParam(funcindex,"RDS_OFF_LED12");
    CParam *RDS_OFF_LED13 = StsGetParam(funcindex,"RDS_OFF_LED13");
    CParam *RDS_OFF_LED14 = StsGetParam(funcindex,"RDS_OFF_LED14");
    CParam *RDS_OFF_LED15 = StsGetParam(funcindex,"RDS_OFF_LED15");
    CParam *RDS_OFF_LED16 = StsGetParam(funcindex,"RDS_OFF_LED16");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	//VDD=0V��VLDE15=20V��VLDE14=20V��VLDE13=0V������pin����
	//VLDE16=20V��VLDE13K=0V��VLDE13A=0V����ÿ��ʱ������Ҳ��Ҫ�����ڹܽ�״̬������������ܽŲ���Ӱ�죻
	//��¼VLDE14�˿ڵ��������ΪILDE14��������RDS(off) - LEDx = 20 / ILDE14
	double test_sample = 200;
	double test_cycle = 20;//us

	FPVI3.Set(FV, 0, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);
	//////////////////////////////////////////LED1///////////////////////////////////////////
	LED1K.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED1A.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED2.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED3.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED4.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED5K.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);

	LED1A.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED1A.GetMeasResult(i, MIRET);
		IOFF_LED1->SetTestResult(i, 0, adresult[i] * 1E6);
		RDS_OFF_LED1->SetTestResult(i, 0, 20 / adresult[i] * 1E-3);

	}

	//CBIT.SetOn(K33, -1);
	//delay_ms(2);

	//FPVI4.Set(FV, 20, FPVI10_50V, FPVI10_1MA, RELAY_ON);
	//delay_ms(100);

	//FPVI4.MeasureVI(test_sample, test_cycle);

	//for (i = 0; i<SITENUM; i++)
	//{
	//	adresult[i] = FPVI4.GetMeasResult(i, MIRET);
	//	IOFF_LED1->SetTestResult(i, 0, adresult[i] * 1E6);
	//	RDS_OFF_LED1->SetTestResult(i, 0, 20 / adresult[i] * 1E-3);

	//}
	//FPVI4.Set(FV, 0.0, FPVI10_50V, FPVI10_1MA, RELAY_ON);
	//delay_ms(2);
	//CBIT.SetOn(-1);
	//delay_ms(2);
	//FPVI4.Set(FV, 0.0, FPVI10_50V, FPVI10_1MA, RELAY_OFF);
	//////////////////////////////////////////LED2///////////////////////////////////////////
	LED1K.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED1A.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED2.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED3.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED4.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED5K.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);

	LED2.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED2.GetMeasResult(i, MIRET);
		IOFF_LED2->SetTestResult(i, 0, adresult[i] * 1E6);
		RDS_OFF_LED2->SetTestResult(i, 0, 20 / adresult[i] * 1E-3);
	}

	//////////////////////////////////////////LED3///////////////////////////////////////////
	LED1K.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED1A.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED2.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED3.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED4.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED5K.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);

	LED3.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED3.GetMeasResult(i, MIRET);
		IOFF_LED3->SetTestResult(i, 0, adresult[i] * 1E6);
		RDS_OFF_LED3->SetTestResult(i, 0, 20 / adresult[i] * 1E-3);
	}

	//////////////////////////////////////////LED4///////////////////////////////////////////
	CP_TOP.Set(FV, 20.5, FPVI10_50V, FPVI10_1MA, RELAY_ON);
	delay_ms(5);
	FPVI1.Set(FV, 20.5, FPVI10_50V, FPVI10_1MA, RELAY_ON);
	delay_ms(5);
	//CP_TOP.MeasureVI(test_sample, test_cycle);
	//FPVI1.MeasureVI(test_sample, test_cycle);
	LED1K.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED1A.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED2.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED3.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED4.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED5K.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);

	LED4.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED4.GetMeasResult(i, MIRET);
		IOFF_LED4->SetTestResult(i, 0, adresult[i] * 1E6);
		RDS_OFF_LED4->SetTestResult(i, 0, 20 / adresult[i] * 1E-3);
	}

	LED1K.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	LED1A.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	LED2.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_OFF);
	LED3.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_OFF);
	delay_ms(2);
	CP_TOP.Set(FV, 0, FPVI10_50V, FPVI10_1MA, RELAY_ON);
	FPVI1.Set(FV, 0, FPVI10_50V, FPVI10_1MA, RELAY_ON);
	delay_ms(5);
	CP_TOP.Set(FV, 0, FPVI10_50V, FPVI10_1MA, RELAY_OFF);
	FPVI1.Set(FV, 0, FPVI10_50V, FPVI10_1MA, RELAY_OFF);
	delay_ms(2);

	//////////////////////////////////////////LED5///////////////////////////////////////////
	LED4.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED5K.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED5A.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED6.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED7.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED8.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED9K.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);

	LED5A.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED5A.GetMeasResult(i, MIRET);
		IOFF_LED5->SetTestResult(i, 0, adresult[i] * 1E6);
		RDS_OFF_LED5->SetTestResult(i, 0, 20 / adresult[i] * 1E-3);
	}

	//////////////////////////////////////////LED6///////////////////////////////////////////
	LED4.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED5K.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED5A.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED6.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED7.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED8.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED9K.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);

	LED6.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED6.GetMeasResult(i, MIRET);
		IOFF_LED6->SetTestResult(i, 0, adresult[i] * 1E6);
		RDS_OFF_LED6->SetTestResult(i, 0, 20 / adresult[i] * 1E-3);
	}

	//////////////////////////////////////////LED7///////////////////////////////////////////
	LED4.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED5K.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED5A.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED6.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED7.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED8.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED9K.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);

	LED7.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED7.GetMeasResult(i, MIRET);
		IOFF_LED7->SetTestResult(i, 0, adresult[i] * 1E6);
		RDS_OFF_LED7->SetTestResult(i, 0, 20 / adresult[i] * 1E-3);
	}

	//////////////////////////////////////////LED8///////////////////////////////////////////
	CP_TOP.Set(FV, 20.5, FPVI10_50V, FPVI10_1MA, RELAY_ON);
	delay_ms(5);
	FPVI1.Set(FV, 20.5, FPVI10_50V, FPVI10_1MA, RELAY_ON);
	delay_ms(5);
	LED4.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED5K.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED5A.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED6.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED7.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED8.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED9K.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);

	LED8.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED8.GetMeasResult(i, MIRET);
		IOFF_LED8->SetTestResult(i, 0, adresult[i] * 1E6);
		RDS_OFF_LED8->SetTestResult(i, 0, 20 / adresult[i] * 1E-3);
	}

	LED4.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_OFF);
	LED5K.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_OFF);
	LED5A.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_OFF);
	LED6.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_OFF);
	LED7.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_OFF);
	delay_ms(2);
	CP_TOP.Set(FV, 0, FPVI10_50V, FPVI10_1MA, RELAY_ON);
	FPVI1.Set(FV, 0, FPVI10_50V, FPVI10_1MA, RELAY_ON);
	delay_ms(5);
	CP_TOP.Set(FV, 0, FPVI10_50V, FPVI10_1MA, RELAY_OFF);
	FPVI1.Set(FV, 0, FPVI10_50V, FPVI10_1MA, RELAY_OFF);
	delay_ms(2);

	//////////////////////////////////////////LED9///////////////////////////////////////////
	LED8.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED9K.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED9A.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED10.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED11.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED12.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED13K.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);

	LED9A.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED9A.GetMeasResult(i, MIRET);
		IOFF_LED9->SetTestResult(i, 0, adresult[i] * 1E6);
		RDS_OFF_LED9->SetTestResult(i, 0, 20 / adresult[i] * 1E-3);
	}

	//////////////////////////////////////////LED10///////////////////////////////////////////
	LED8.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED9K.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED9A.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED10.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED11.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED12.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED13K.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);

	LED10.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED10.GetMeasResult(i, MIRET);
		IOFF_LED10->SetTestResult(i, 0, adresult[i] * 1E6);
		RDS_OFF_LED10->SetTestResult(i, 0, 20 / adresult[i] * 1E-3);
	}

	//////////////////////////////////////////LED11///////////////////////////////////////////
	LED8.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED9K.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED9A.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED10.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED11.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED12.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED13K.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);

	LED11.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED11.GetMeasResult(i, MIRET);
		IOFF_LED11->SetTestResult(i, 0, adresult[i] * 1E6);
		RDS_OFF_LED11->SetTestResult(i, 0, 20 / adresult[i] * 1E-3);
	}

	//////////////////////////////////////////LED12///////////////////////////////////////////
	CP_TOP.Set(FV, 20.5, FPVI10_50V, FPVI10_1MA, RELAY_ON);
	delay_ms(5);
	FPVI1.Set(FV, 20.5, FPVI10_50V, FPVI10_1MA, RELAY_ON);
	delay_ms(5);
	LED8.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED9K.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED9A.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED10.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED11.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED12.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED13K.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);

	LED12.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED12.GetMeasResult(i, MIRET);
		IOFF_LED12->SetTestResult(i, 0, adresult[i] * 1E6);
		RDS_OFF_LED12->SetTestResult(i, 0, 20 / adresult[i] * 1E-3);
	}

	LED8.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_OFF);
	LED9K.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_OFF);
	LED9A.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_OFF);
	LED10.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_OFF);
	LED11.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_OFF);
	delay_ms(2);
	CP_TOP.Set(FV, 0, FPVI10_50V, FPVI10_1MA, RELAY_ON);
	FPVI1.Set(FV, 0, FPVI10_50V, FPVI10_1MA, RELAY_ON);
	delay_ms(5);
	CP_TOP.Set(FV, 0, FPVI10_50V, FPVI10_1MA, RELAY_OFF);
	FPVI1.Set(FV, 0, FPVI10_50V, FPVI10_1MA, RELAY_OFF);
	delay_ms(2);

	//////////////////////////////////////////LED13///////////////////////////////////////////
	LED12.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED13K.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED13A.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED14.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED15.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED16.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);

	LED13A.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED13A.GetMeasResult(i, MIRET);
		IOFF_LED13->SetTestResult(i, 0, adresult[i] * 1E6);
		RDS_OFF_LED13->SetTestResult(i, 0, 20 / adresult[i] * 1E-3);
	}

	//////////////////////////////////////////LED14///////////////////////////////////////////
	//GPFOVI GP_LED_14("GP_LED_NO4", LED14, LED15, LED16);
	LED12.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	LED13K.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	LED13A.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	//GP_LED_14.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	LED14.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED15.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED16.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);

	LED14.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED14.GetMeasResult(i, MIRET);
		IOFF_LED14->SetTestResult(i, 0, adresult[i] * 1E6);
		RDS_OFF_LED14->SetTestResult(i, 0, 20 / adresult[i] * 1E-3);
	}

	//////////////////////////////////////////LED15///////////////////////////////////////////
	LED12.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED13K.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED13A.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED14.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED15.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED16.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);

	LED15.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED15.GetMeasResult(i, MIRET);
		IOFF_LED15->SetTestResult(i, 0, adresult[i] * 1E6);
		RDS_OFF_LED15->SetTestResult(i, 0, 20 / adresult[i] * 1E-3);
	}

	//////////////////////////////////////////LED16///////////////////////////////////////////
	CP_TOP.Set(FV, 20.5, FPVI10_50V, FPVI10_1MA, RELAY_ON);
	delay_ms(5);
	FPVI1.Set(FV, 20.5, FPVI10_50V, FPVI10_1MA, RELAY_ON);
	delay_ms(5);
	LED12.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED13K.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED13A.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED14.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED15.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED16.Set(FV, 20, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);

	LED16.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED16.GetMeasResult(i, MIRET);
		IOFF_LED16->SetTestResult(i, 0, adresult[i] * 1E6);
		RDS_OFF_LED16->SetTestResult(i, 0, 20 / adresult[i] * 1E-3);
	}

	//LED14.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	//delay_ms(2);
	//LED15.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	//delay_ms(2);
	LED16.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	//GP_LED_14.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	LED16.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_ON);
	//LED15.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	//LED14.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	//GP_LED_14.Set(FV, 0, FOVI_2V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	CP_TOP.Set(FV, 0, FPVI10_50V, FPVI10_1MA, RELAY_ON);
	FPVI1.Set(FV, 0, FPVI10_50V, FPVI10_1MA, RELAY_ON);
	delay_ms(5);
	CP_TOP.Set(FV, 0, FPVI10_50V, FPVI10_1MA, RELAY_OFF);
	FPVI1.Set(FV, 0, FPVI10_50V, FPVI10_1MA, RELAY_OFF);
	delay_ms(2);
	LED12.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_OFF);
	LED13K.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_OFF);
	LED13A.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_OFF);
	LED14.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_OFF);
	LED15.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_OFF);
	LED16.Set(FV, 0, FOVI_50V, FOVI_1MA, RELAY_OFF);
	FPVI3.Set(FV, 0, FPVI10_2V, FPVI10_10MA, RELAY_OFF);
	delay_ms(2);


	CBIT.SetOn(-1);
	delay_ms(2);

    return 0;
}


DUT_API int VLED_hiZ(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *VLED1K = StsGetParam(funcindex,"VLED1K");
    CParam *VLED1A = StsGetParam(funcindex,"VLED1A");
    CParam *VLED2 = StsGetParam(funcindex,"VLED2");
    CParam *VLED3 = StsGetParam(funcindex,"VLED3");
    CParam *VLED4 = StsGetParam(funcindex,"VLED4");
    CParam *VLED5K = StsGetParam(funcindex,"VLED5K");
    CParam *VLED5A = StsGetParam(funcindex,"VLED5A");
    CParam *VLED6 = StsGetParam(funcindex,"VLED6");
    CParam *VLED7 = StsGetParam(funcindex,"VLED7");
    CParam *VLED8 = StsGetParam(funcindex,"VLED8");
    CParam *VLED9K = StsGetParam(funcindex,"VLED9K");
    CParam *VLED9A = StsGetParam(funcindex,"VLED9A");
    CParam *VLED10 = StsGetParam(funcindex,"VLED10");
    CParam *VLED11 = StsGetParam(funcindex,"VLED11");
    CParam *VLED12 = StsGetParam(funcindex,"VLED12");
    CParam *VLED13K = StsGetParam(funcindex,"VLED13K");
    CParam *VLED13A = StsGetParam(funcindex,"VLED13A");
    CParam *VLED14 = StsGetParam(funcindex,"VLED14");
    CParam *VLED15 = StsGetParam(funcindex,"VLED15");
    CParam *VLED16 = StsGetParam(funcindex,"VLED16");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	/////////////////////////////////////////////////////////
	//VDD=5V������pin���գ���¼VLDEx�˿ڵĵ�ѹΪVLEDx - hiZ
	double test_sample = 200;
	double test_cycle = 20;//us


	FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);
	FPVI3.Set(FV, 5, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);
	LED1K.Set(FI, 0, FOVI_1V, FOVI_10MA, RELAY_SENSE_ON);
	LED1A.Set(FI, 0, FOVI_1V, FOVI_10MA, RELAY_SENSE_ON);
	LED2.Set(FI, 0, FOVI_1V, FOVI_10MA, RELAY_SENSE_ON);
	LED3.Set(FI, 0, FOVI_1V, FOVI_10MA, RELAY_SENSE_ON);
	LED4.Set(FI, 0, FOVI_1V, FOVI_10MA, RELAY_SENSE_ON);
	LED5K.Set(FI, 0, FOVI_1V, FOVI_10MA, RELAY_SENSE_ON);
	LED5A.Set(FI, 0, FOVI_1V, FOVI_10MA, RELAY_SENSE_ON);
	LED6.Set(FI, 0, FOVI_1V, FOVI_10MA, RELAY_SENSE_ON);
	LED7.Set(FI, 0, FOVI_1V, FOVI_10MA, RELAY_SENSE_ON);
	LED8.Set(FI, 0, FOVI_1V, FOVI_10MA, RELAY_SENSE_ON);
	LED9K.Set(FI, 0, FOVI_1V, FOVI_10MA, RELAY_SENSE_ON);
	LED9A.Set(FI, 0, FOVI_1V, FOVI_10MA, RELAY_SENSE_ON);
	LED10.Set(FI, 0, FOVI_1V, FOVI_10MA, RELAY_SENSE_ON);
	LED11.Set(FI, 0, FOVI_1V, FOVI_10MA, RELAY_SENSE_ON);
	LED12.Set(FI, 0, FOVI_1V, FOVI_10MA, RELAY_SENSE_ON);
	LED13K.Set(FI, 0, FOVI_1V, FOVI_10MA, RELAY_SENSE_ON);
	LED13A.Set(FI, 0, FOVI_1V, FOVI_10MA, RELAY_SENSE_ON);
	LED14.Set(FI, 0, FOVI_1V, FOVI_10MA, RELAY_SENSE_ON);
	LED15.Set(FI, 0, FOVI_1V, FOVI_10MA, RELAY_SENSE_ON);
	LED16.Set(FI, 0, FOVI_1V, FOVI_10MA, RELAY_SENSE_ON);
	delay_ms(2);

	LED1K.MeasureVI(test_sample, test_cycle);
	LED1A.MeasureVI(test_sample, test_cycle);
	LED2.MeasureVI(test_sample, test_cycle);
	LED3.MeasureVI(test_sample, test_cycle);
	LED4.MeasureVI(test_sample, test_cycle);
	LED5K.MeasureVI(test_sample, test_cycle);
	LED5A.MeasureVI(test_sample, test_cycle);
	LED6.MeasureVI(test_sample, test_cycle);
	LED7.MeasureVI(test_sample, test_cycle);
	LED8.MeasureVI(test_sample, test_cycle);
	LED9K.MeasureVI(test_sample, test_cycle);
	LED9A.MeasureVI(test_sample, test_cycle);
	LED10.MeasureVI(test_sample, test_cycle);
	LED11.MeasureVI(test_sample, test_cycle);
	LED12.MeasureVI(test_sample, test_cycle);
	LED13K.MeasureVI(test_sample, test_cycle);
	LED13A.MeasureVI(test_sample, test_cycle);
	LED14.MeasureVI(test_sample, test_cycle);
	LED15.MeasureVI(test_sample, test_cycle);
	LED16.MeasureVI(test_sample, test_cycle);

	////////////////////////////////////LED1K/////////////////////////////////
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED1K.GetMeasResult(i, MVRET);
		VLED1K->SetTestResult(i, 0, adresult[i] * 1E3);
	}
	////////////////////////////////////LED1A/////////////////////////////////
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED1A.GetMeasResult(i, MVRET);
		VLED1A->SetTestResult(i, 0, adresult[i] * 1E3);
	}
	////////////////////////////////////LED2/////////////////////////////////
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED2.GetMeasResult(i, MVRET);
		VLED2->SetTestResult(i, 0, adresult[i] * 1E3);
	}
	////////////////////////////////////LED3/////////////////////////////////
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED3.GetMeasResult(i, MVRET);
		VLED3->SetTestResult(i, 0, adresult[i] * 1E3);
	}
	////////////////////////////////////LED4/////////////////////////////////
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED4.GetMeasResult(i, MVRET);
		VLED4->SetTestResult(i, 0, adresult[i] * 1E3);
	}
	////////////////////////////////////LED5K/////////////////////////////////
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED5K.GetMeasResult(i, MVRET);
		VLED5K->SetTestResult(i, 0, adresult[i] * 1E3);
	}
	////////////////////////////////////LED5A/////////////////////////////////
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED5A.GetMeasResult(i, MVRET);
		VLED5A->SetTestResult(i, 0, adresult[i] * 1E3);
	}
	////////////////////////////////////LED6/////////////////////////////////
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED6.GetMeasResult(i, MVRET);
		VLED6->SetTestResult(i, 0, adresult[i] * 1E3);
	}
	////////////////////////////////////LED7/////////////////////////////////
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED7.GetMeasResult(i, MVRET);
		VLED7->SetTestResult(i, 0, adresult[i] * 1E3);
	}
	////////////////////////////////////LED8/////////////////////////////////
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED8.GetMeasResult(i, MVRET);
		VLED8->SetTestResult(i, 0, adresult[i] * 1E3);
	}
	////////////////////////////////////LED9K/////////////////////////////////
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED9K.GetMeasResult(i, MVRET);
		VLED9K->SetTestResult(i, 0, adresult[i] * 1E3);
	}
	////////////////////////////////////LED9A/////////////////////////////////
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED9A.GetMeasResult(i, MVRET);
		VLED9A->SetTestResult(i, 0, adresult[i] * 1E3);
	}
	////////////////////////////////////LED10/////////////////////////////////
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED10.GetMeasResult(i, MVRET);
		VLED10->SetTestResult(i, 0, adresult[i] * 1E3);
	}
	////////////////////////////////////LED11/////////////////////////////////
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED11.GetMeasResult(i, MVRET);
		VLED11->SetTestResult(i, 0, adresult[i] * 1E3);
	}
	////////////////////////////////////LED12/////////////////////////////////
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED12.GetMeasResult(i, MVRET);
		VLED12->SetTestResult(i, 0, adresult[i] * 1E3);
	}
	////////////////////////////////////LED13K/////////////////////////////////
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED13K.GetMeasResult(i, MVRET);
		VLED13K->SetTestResult(i, 0, adresult[i] * 1E3);
	}
	////////////////////////////////////LED13A/////////////////////////////////
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED13A.GetMeasResult(i, MVRET);
		VLED13A->SetTestResult(i, 0, adresult[i] * 1E3);
	}
	////////////////////////////////////LED14/////////////////////////////////
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED14.GetMeasResult(i, MVRET);
		VLED14->SetTestResult(i, 0, adresult[i] * 1E3);
	}
	////////////////////////////////////LED15/////////////////////////////////
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED15.GetMeasResult(i, MVRET);
		VLED15->SetTestResult(i, 0, adresult[i] * 1E3);
	}
	////////////////////////////////////LED16/////////////////////////////////
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = LED16.GetMeasResult(i, MVRET);
		VLED16->SetTestResult(i, 0, adresult[i] * 1E3);
	}

	FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);
	FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_100MA, RELAY_OFF);
	LED1K.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED1A.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED2.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED3.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED4.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED5K.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED5A.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED6.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED7.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED8.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED9K.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED9A.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED10.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED11.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED12.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED13K.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED13A.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED14.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED15.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED16.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	delay_ms(2);


    return 0;
}


DUT_API int VTH_SHORT_ERROR(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *VTH_SHORT_ERROR = StsGetParam(funcindex,"VTH_SHORT_ERROR");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	/////////////////////////////////////////////////////////
	//VDD=5V��VLDE15=0V��VLDE16��1.2V�½���0.4V����10mV������pin���գ�
	//��ȡ�Ĵ���0x89��LED short error flag����ֵ�Ƿ�仯
	CBIT.SetOn(K99, K100,  -1);
	delay_ms(2);
	PULL_UP.Set(FV, 5, FOVI_10V, FOVI_100MA, RELAY_ON);
	FOVI30.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	FOVI29.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	FOVI28.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	FOVI31.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	delay_ms(3);

	double test_sample = 50;
	double test_cycle = 20;//us

	FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);
	FPVI3.Set(FV, 5, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);
	LED1K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED1A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED2.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED3.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED4.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED5K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED5A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED6.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED7.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED8.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED9K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED9A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED10.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED11.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED12.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED13K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED13A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED14.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED15.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED16.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_ms(2);
	LED16.Set(FV, 1.2, FOVI_2V, FOVI_100MA, RELAY_ON);
	delay_ms(2);
	DWORD Reg_Address = 0x89;
	UART_CH.Connect();
	delay_ms(5);
	UART_trans.UART16_Write_Data_Single_Mode(UART_CH, Write_Init, DevID_VOL, 0x14, 0xFF);
	delay_ms(2);
	UART_trans.UART16_Read_Data_Single_Mode(UART_CH, Read_Init, DevID_VOL, Reg_Address);
	delay_ms(5);
	DWORD DATA1 = UART_trans.Get16_Data_Single_Mode(UART_CH, SITE_1);
	//for (i = 0; i < SITENUM; i++)
	//{
	//	VTH_SHORT_ERROR->SetTestResult(i, 1, DATA1);
	//}



		double j = 0;
		for (j = 1.2; j > 0.4; j = j - 10 * 1E-3)
		{
			LED16.Set(FV, j, FOVI_2V, FOVI_10MA, RELAY_ON);
			delay_ms(3);
			UART_trans.UART16_Read_Data_Single_Mode(UART_CH, Read_Init, DevID_VOL, Reg_Address);
			delay_ms(3);
			DWORD DATA2 = UART_trans.Get16_Data_Single_Mode(UART_CH, SITE_1);
			if (DATA2 != 0)
			{
				for (i = 0; i < SITENUM; i++)
				{
				//adresult1[i] = j;
				VTH_SHORT_ERROR->SetTestResult(i, 0, j);
				//VTH_SHORT_ERROR->SetTestResult(i, 2, DATA2);
				}
				break;

			
		}
	}

	//LED16.Set(FV, 0.5, FOVI_2V, FOVI_100MA, RELAY_ON);
	//delay_ms(1);
	//for (i = 0; i < SITENUM; i++)
	//{
	//	DWORD Reg_Address = 0x89;
	//	UART_trans.UART16_Read_Data_Single_Mode(UART_CH, Read_Init, DevID_VOL, Reg_Address);
	//	delay_ms(5);
	//	DWORD DATA2 = UART_trans.Get16_Data_Single_Mode(UART_CH, SITE_1);
	//	for (i = 0; i < SITENUM; i++)
	//	{
	//		VTH_SHORT_ERROR->SetTestResult(i, 2, DATA2);

	//	}
	//}

	UART_CH.Disconnect();
	delay_ms(5);
	PULL_UP.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	CBIT.SetOn(-1);
	delay_ms(2);
	LED16.Set(FV, 0, FOVI_2V, FOVI_100MA, RELAY_ON);
	delay_ms(2);
	FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);
	FPVI3.Set(FV, 0.0, FPVI10_10V, FPVI10_10MA, RELAY_OFF);
	PULL_UP.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);
	FOVI30.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	FOVI29.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	FOVI28.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	FOVI31.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	LED1K.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED1A.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED2.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED3.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED4.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED5K.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED5A.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED6.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED7.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED8.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED9K.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED9A.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED10.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED11.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED12.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED13K.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED13A.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED14.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED15.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED16.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	delay_ms(2);

	CBIT.SetOn(-1);
	delay_ms(2);

    return 0;
}


DUT_API int VTH_OPEN_ERROR(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *VTH_OPEN_ERROR = StsGetParam(funcindex,"VTH_OPEN_ERROR");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	/////////////////////////////////////////////////////////
	//VDD=5V��VLDE15=0V��VLDE16��17.5V������19V����10mV������pin���գ�
	//��ȡ�Ĵ���0x87��LED open error flag����ֵ�Ƿ�仯
	CBIT.SetOn(K99, K100,  -1);
	delay_ms(2);
	PULL_UP.Set(FV, 5, FOVI_10V, FOVI_100MA, RELAY_ON);
	FOVI30.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	FOVI29.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	FOVI28.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	FOVI31.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	delay_ms(3);

	double test_sample = 50;
	double test_cycle = 20;//us

	FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);
	FPVI3.Set(FV, 5, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);
	LED1K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED1A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED2.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED3.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED4.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED5K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED5A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED6.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED7.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED8.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED9K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED9A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED10.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED11.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED12.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED13K.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED13A.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED14.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED15.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	LED16.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_ms(2);
	LED16.Set(FV, 16.5, FOVI_20V, FOVI_10MA, RELAY_ON);
	delay_ms(2);
	DWORD Reg_Address = 0x87;
	UART_CH.Connect();
	delay_ms(5);
	UART_trans.UART16_Write_Data_Single_Mode(UART_CH, Write_Init, DevID_VOL, 0x14, 0xFF);
	delay_ms(2);
	UART_trans.UART16_Read_Data_Single_Mode(UART_CH, Read_Init, DevID_VOL, Reg_Address);
	delay_ms(5);
	//adresult[0] = UART_trans.Get16_Data_Single_Mode(UART_CH, SITE_1);

	/*LED16.Set(FV, 17.5, FOVI_50V, FOVI_10MA, RELAY_ON);
	delay_ms(1);*/
	//UART_trans.UART16_Read_Data_Single_Mode(UART_CH, Read_Init, DevID_VOL, Reg_Address);
	//delay_ms(5);
	//VTH_OPEN_ERROR->SetTestResult(0, 1, UART_trans.Get16_Data_Single_Mode(UART_CH, SITE_1));

	//LED16.Set(FV, 19, FOVI_50V, FOVI_10MA, RELAY_ON);
	//delay_ms(1);
	//UART_trans.UART16_Read_Data_Single_Mode(UART_CH, Read_Init, DevID_VOL, Reg_Address);
	//delay_ms(5);
	//VTH_OPEN_ERROR->SetTestResult(0, 2, UART_trans.Get16_Data_Single_Mode(UART_CH, SITE_1));
	DWORD DATA1 = UART_trans.Get16_Data_Single_Mode(UART_CH, SITE_1);
	//for (i = 0; i < SITENUM; i++)
	//{
	//	VTH_SHORT_ERROR->SetTestResult(i, 1, DATA1);
	//}



	double j = 0;
	for (j = 16.5; j < 19; j = j + 10 * 1E-3)
	{
		LED16.Set(FV, j, FOVI_50V, FOVI_10MA, RELAY_ON);
		delay_ms(2);
		UART_trans.UART16_Read_Data_Single_Mode(UART_CH, Read_Init, DevID_VOL, Reg_Address);
		delay_ms(5);
		DWORD DATA2 = UART_trans.Get16_Data_Single_Mode(UART_CH, SITE_1);
		if (DATA2 != 0)
		{
			for (i = 0; i < SITENUM; i++)
			{
				//adresult1[i] = j;
				VTH_OPEN_ERROR->SetTestResult(i, 0, j);
				//VTH_OPEN_ERROR->SetTestResult(i, 2, DATA2);
			}
			break;


		}
	}
	UART_CH.Disconnect();
	delay_ms(5);
	PULL_UP.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	CBIT.SetOn(-1);
	delay_ms(2);
	LED16.Set(FV, 0, FOVI_50V, FOVI_10MA, RELAY_ON);
	delay_ms(2);
	LED16.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_ms(2);
	FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);

	FPVI3.Set(FV, 0.0, FPVI10_10V, FPVI10_100MA, RELAY_OFF);
	PULL_UP.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);
	FOVI30.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	FOVI29.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	FOVI28.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	FOVI31.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	LED1K.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED1A.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED2.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED3.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED4.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED5K.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED5A.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED6.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED7.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED8.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED9K.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED9A.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED10.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED11.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED12.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED13K.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED13A.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED14.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED15.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	LED16.Set(FV, 0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	delay_ms(5);

    return 0;
}


DUT_API int SR_TRIM(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *VCS_MODE1 = StsGetParam(funcindex,"VCS_MODE1");
    CParam *DELTA_t_LED16_BEFORE = StsGetParam(funcindex,"DELTA_t_LED16_BEFORE");
    CParam *DELTA_t_LED16_TRIMCODE = StsGetParam(funcindex,"DELTA_t_LED16_TRIMCODE");
    CParam *DELTA_t_LED16_AFTER = StsGetParam(funcindex,"DELTA_t_LED16_AFTER");
    CParam *SR = StsGetParam(funcindex,"SR");
    CParam *t_f_SR = StsGetParam(funcindex,"t_f_SR");
    CParam *f_OSC = StsGetParam(funcindex,"f_OSC");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	/////////////////////////////////////////////////////////////////////////////////////////
	//����VDD = 5V���������ģʽsts16��VLDE15 = 6V��
	//LED15��LED16֮������1k�����裬��LED16�˿ڹ����10mA����Դ20V��
	//����LED16�˿ڵ�ѹΪ10Vʱ��¼��ʱ��ʱ��Ϊt1������LED16�˿ڵ�ѹΪ13.5Vʱ��¼��ʱ��ʱ��Ϊt2��
	CBIT.SetOn(K99, K100, -1);
	delay_ms(2);
	PULL_UP.Set(FV, 5, FOVI_10V, FOVI_100MA, RELAY_ON);
	FOVI30.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	FOVI29.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	FOVI28.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	FOVI31.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	delay_ms(3);

	FPVI3.Set(FV, 5.3, FPVI10_10V, FPVI10_100MA, RELAY_ON);

	delay_ms(5);

	DWORD DATA = 0x00;
	DWORD Reg_Address = 0x03;
	UART_CH.Connect();
	delay_ms(5);

	UART_trans.UART16_Write_Data_Single_Mode(UART_CH, Write_Init, DevID_VOL, Reg_Address, DATA);
	delay_ms(2);
	Reg_Address = 0x04;
	UART_trans.UART16_Write_Data_Single_Mode(UART_CH, Write_Init, DevID_VOL, Reg_Address, DATA);
	delay_ms(2);


	//t2 - t1�õ�����ֵ��t=3.5/SR
	double test_sample = 50;
	double test_cycle = 20;//us

	FPVI3.Set(FV, 5.3, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);
	//FPVI3.Set(FV, 5.0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	//delay_ms(2);
	//FPVI3.MeasureVI(200, 10);
	//NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//NC4.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	NC4.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	//NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	////NC4.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//NC4.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_OFF);
	//delay_ms(2);
	////////////////////MODE1/////////////////////////////
	//NC4.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	//NC5.MeasureVI(200, 10);
	//NC4.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	//NC5.MeasureVI(200, 10);
	CS_NC3.Set(FI, 0, FOVI_2V, FOVI_1MA, RELAY_SENSE_ON);
	delay_ms(2);
	//����ģʽ1���룬��CS��ѹ��û��1.5V
	CS_NC3.MeasureVI(200, 10);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = CS_NC3.GetMeasResult(i, MVRET);
		VCS_MODE1->SetTestResult(i, 0, adresult[i]);
	}
	CS_NC3.Set(FI, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(2);
	//NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	////////////////////MODE2/////////////////////////////
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	////////////////////MODE3/////////////////////////////
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	//
	////����ģʽ2���룬��CS��ѹ��û��464mV
	//CS_NC3.MeasureVI(200, 100);
	//for (i = 0; i<SITENUM; i++)
	//{
	//	adresult[i] = CS_NC3.GetMeasResult(i, MVRET);
	//	VCS_MODE1->SetTestResult(i, 1, adresult[i]);
	//}
	//CS_NC3.Set(FI, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	//delay_ms(2);
	////////////////////MODE4/////////////////////////////
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	////����ģʽ4���룬��CS��ѹ��û��0.352V
	//CS_NC3.Set(FI, 0, FOVI_1V, FOVI_1MA, RELAY_SENSE_ON);
	//delay_ms(2);
	//CS_NC3.MeasureVI(200, 100);
	//for (i = 0; i<SITENUM; i++)
	//{
	//	adresult[i] = CS_NC3.GetMeasResult(i, MVRET);
	//	VCS_MODE1->SetTestResult(i, 2, adresult[i]);
	//}
	//CS_NC3.Set(FI, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	//delay_ms(2);
	////////////////////MODE5/////////////////////////////
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	////////////////////MODE6/////////////////////////////
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	////////////////////MODE7/////////////////////////////
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	////////////////////MODE8/////////////////////////////
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	////////////////////MODE9/////////////////////////////
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	////////////////////MODE10/////////////////////////////
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	////////////////////MODE11/////////////////////////////
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	////////////////////MODE12/////////////////////////////
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	////////////////////MODE13/////////////////////////////
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	////////////////////MODE14/////////////////////////////
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	////////////////////MODE15/////////////////////////////
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	////////////////////MODE16/////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////
	//����VDD = 5V���������ģʽsts16��VLDE15 = 6V��
	//LED15��LED16֮������1k�����裬��LED16�˿ڹ����10mA����Դ20V��
	//����LED16�˿ڵ�ѹΪ10Vʱ��¼��ʱ��ʱ��Ϊt1������LED16�˿ڵ�ѹΪ13.5Vʱ��¼��ʱ��ʱ��Ϊt2��
	//t2 - t1�õ�����ֵ��t=3.5/SR
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);

	//����sts16
	CBIT.SetOn(K5, K6, K99, K100, -1);
	delay_ms(2);

	FPVI6.Set(FV, 10, FPVI10_50V, FPVI10_100MA, RELAY_ON);
	delay_ms(3);
	//LED15.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_ON);
	//delay_ms(2);
	//LED16.Set(FI, 0E-3, FOVI_20V, FOVI_100MA, RELAY_SENSE_ON);
	//delay_ms(5);
	//LED16.MeasureVI(500, 10);

	double val[SITENUM] = { 0.0 };
	qtmu0.SetStartInput(QTMU_PLUS_IMPEDANCE_1M, QTMU_PLUS_VRNG_5V, QTMU_PLUS_FILTER_PASS);
	qtmu0.SetStopInput(QTMU_PLUS_IMPEDANCE_1M, QTMU_PLUS_VRNG_5V, QTMU_PLUS_FILTER_PASS);
	qtmu0.SetStartTrigger(1, QTMU_PLUS_POS_SLOPE);//trigger=7.7V,risingedge 
	qtmu0.SetStopTrigger(2, QTMU_PLUS_POS_SLOPE);//trigger=7.7V,fallingedge
	qtmu0.SetInSource(QTMU_PLUS_SINGLE_SOURCE);//SINGLE_SOURCE
	qtmu0.Connect();
	delay_ms(1);
	qtmu0.Meas(QTMU_PLUS_COARSE, QTMU_PLUS_TRNG_NS, 10);
	//qtmu0.SetTimeOut(100);//timeout=10ms
	
	//setthe triggersignal here
	//qtmu0.SinglePlsMeas(0);


	for (i = 0; i<SITENUM; i++) 
	{ 
		val[i] += qtmu0.GetMeasureResult(i); 
		//DELTA_t_LED16_BEFORE->SetTestResult(i, 0, val[i]);
		//SR->SetTestResult(i, 0, 1/val[i]);
	} 
	//////////////////////////////////////////////////////////////////////
	delay_ms(1);
	qtmu0.Meas(QTMU_PLUS_COARSE, QTMU_PLUS_TRNG_NS, 10);
	//qtmu0.SetTimeOut(100);//timeout=10ms

	//setthe triggersignal here
	//qtmu0.SinglePlsMeas(0);

	
	for (i = 0; i<SITENUM; i++)
	{
		val[i] +=  qtmu0.GetMeasureResult(i);
		//DELTA_t_LED16_BEFORE->SetTestResult(i, 1, val[i]);
		//SR->SetTestResult(i, 0, 1 / val[i]);
	}
	//////////////////////////////////////////////////////////////////////
	delay_ms(1);
	qtmu0.Meas(QTMU_PLUS_COARSE, QTMU_PLUS_TRNG_NS, 10);
	//qtmu0.SetTimeOut(100);//timeout=10ms

	//setthe triggersignal here
	//qtmu0.SinglePlsMeas(0);


	for (i = 0; i<SITENUM; i++)
	{
		val[i] +=  qtmu0.GetMeasureResult(i);
		//DELTA_t_LED16_BEFORE->SetTestResult(i, 2, val[i]);
		//SR->SetTestResult(i, 0, 1 / val[i]);
	}
	//////////////////////////////////////////////////////////////////////
	delay_ms(1);
	qtmu0.Meas(QTMU_PLUS_COARSE, QTMU_PLUS_TRNG_NS, 10);
	//qtmu0.SetTimeOut(100);//timeout=10ms

	//setthe triggersignal here
	//qtmu0.SinglePlsMeas(0);


	for (i = 0; i<SITENUM; i++)
	{
		val[i] +=  qtmu0.GetMeasureResult(i);
		//DELTA_t_LED16_BEFORE->SetTestResult(i, 3, val[i]);
		//SR->SetTestResult(i, 0, 1 / val[i]);
	}
	//////////////////////////////////////////////////////////////////////
	delay_ms(1);
	qtmu0.Meas(QTMU_PLUS_COARSE, QTMU_PLUS_TRNG_NS, 10);
	//qtmu0.SetTimeOut(100);//timeout=10ms

	//setthe triggersignal here
	//qtmu0.SinglePlsMeas(0);


	for (i = 0; i<SITENUM; i++)
	{
		val[i] += qtmu0.GetMeasureResult(i);
	//	DELTA_t_LED16_BEFORE->SetTestResult(i, 4, val[i]);
		//SR->SetTestResult(i, 0, 1 / val[i]);
	}
	//////////////////////////////////////////////////////////////////////
	delay_ms(1);
	qtmu0.Meas(QTMU_PLUS_COARSE, QTMU_PLUS_TRNG_NS, 10);
	//qtmu0.SetTimeOut(100);//timeout=10ms

	//setthe triggersignal here
	//qtmu0.SinglePlsMeas(0);


	for (i = 0; i<SITENUM; i++)
	{
		val[i] += qtmu0.GetMeasureResult(i);
		DELTA_t_LED16_BEFORE->SetTestResult(i, 0, val[i]/6);
		SR->SetTestResult(i, 0, 1 / (val[i]/6));
	}

	////////////////////////////////FOSC//////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////
	double val1[SITENUM] = { 0.0 };
	qtmu0.SetStartTrigger(2, QTMU_PLUS_POS_SLOPE);//trigger=7.7V,risingedge 
	qtmu0.SetStopTrigger(2, QTMU_PLUS_POS_SLOPE);//trigger=7.7V,fallingedge
	qtmu0.SetInSource(QTMU_PLUS_SINGLE_SOURCE);//SINGLE_SOURCE
	///////////////////////////////////////////////////////////
	qtmu0.Meas(QTMU_PLUS_COARSE, QTMU_PLUS_TRNG_NS, 10);

	for (i = 0; i<SITENUM; i++)
	{
		val1[i] += qtmu0.GetMeasureResult(i);
		//f_SR->SetTestResult(i, 0, 1 / (val[i] / 6));
	}
	delay_ms(1);
	///////////////////////////////////////////////////////////
	qtmu0.Meas(QTMU_PLUS_COARSE, QTMU_PLUS_TRNG_NS, 10);

	for (i = 0; i<SITENUM; i++)
	{
		val1[i] += qtmu0.GetMeasureResult(i);
		//f_SR->SetTestResult(i, 0, 1 / (val[i] / 6));
	}
	delay_ms(1);
	///////////////////////////////////////////////////////////
	qtmu0.Meas(QTMU_PLUS_COARSE, QTMU_PLUS_TRNG_NS, 10);

	for (i = 0; i<SITENUM; i++)
	{
		val1[i] += qtmu0.GetMeasureResult(i);
		//f_SR->SetTestResult(i, 0, 1 / (val[i] / 6));
	}
	delay_ms(1);
	///////////////////////////////////////////////////////////
	qtmu0.Meas(QTMU_PLUS_COARSE, QTMU_PLUS_TRNG_NS, 10);

	for (i = 0; i<SITENUM; i++)
	{
		val1[i] += qtmu0.GetMeasureResult(i);
		//f_SR->SetTestResult(i, 0, 1 / (val[i] / 6));
	}
	delay_ms(1);
	///////////////////////////////////////////////////////////
	qtmu0.Meas(QTMU_PLUS_COARSE, QTMU_PLUS_TRNG_NS, 10);

	for (i = 0; i<SITENUM; i++)
	{
		val1[i] += qtmu0.GetMeasureResult(i);
		//f_SR->SetTestResult(i, 0, 1 / (val[i] / 6));
	}
	delay_ms(1);
	///////////////////////////////////////////////////////////
	qtmu0.Meas(QTMU_PLUS_COARSE, QTMU_PLUS_TRNG_NS, 10);

	for (i = 0; i<SITENUM; i++)
	{
		val1[i] += qtmu0.GetMeasureResult(i);
		t_f_SR->SetTestResult(i, 0, val1[i] / 6);
		f_OSC->SetTestResult(i, 0, 1 / (val1[i] / 6) * 8192);
	}
	delay_ms(1);

	qtmu0.Disconnect();
	delay_ms(2);


	FPVI6.Set(FV, 0, FPVI10_50V, FPVI10_100MA, RELAY_ON);
	delay_ms(5);
	//LED16.Set(FI, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(2);
	//LED15.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_ON);
	//delay_ms(2);

	UART_CH.Disconnect();
	delay_ms(5);
	//FPVI3.Set(FV, 0.0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	PULL_UP.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	CBIT.SetOn(-1);
	delay_ms(5);
	//FPVI3.Set(FV, 0.0, FPVI10_10V, FPVI10_10MA, RELAY_OFF);
	PULL_UP.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);
	FOVI30.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	FOVI29.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	FOVI28.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	FOVI31.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	delay_ms(3);
	//LED16.Set(FI, 0, FOVI_20V, FOVI_100MA, RELAY_OFF);
	//delay_ms(2);
	//LED15.Set(FV, 0, FOVI_10V, FOVI_10MA, RELAY_OFF);
	//delay_ms(2);
	FPVI6.Set(FV, 0, FPVI10_50V, FPVI10_100MA, RELAY_OFF);
	delay_ms(5);

	//////////////////////MODE17/////////////////////////////
	//NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//////////////////////MODE18/////////////////////////////
	//NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	NC4.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_OFF);
	NC4.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_OFF);
	delay_ms(10);
	FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_100MA, RELAY_OFF);
	delay_ms(2);


    return 0;
}


DUT_API int V_RX(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *RX_H_BEF = StsGetParam(funcindex,"RX_H_BEF");
    CParam *RX_H_AFT = StsGetParam(funcindex,"RX_H_AFT");
    CParam *RX_L_BEF = StsGetParam(funcindex,"RX_L_BEF");
    CParam *RX_L_AFT = StsGetParam(funcindex,"RX_L_AFT");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	///////////////////////////////////////////////////////////////
	//VDD=5V��RX�ĸߵ�ƽΪ1.45V����ȡ�Ĵ���0x01��Ϊ00����
	//����RX�ĸߵ�ƽΪ2.06V����ȡ�Ĵ���0x01�Ƿ�Ϊ10��
	//��¼��ʱ��Ӧ��RX�ĸߵ�ƽΪVIH  2.06V< VIH
	CBIT.SetOn(K99, K100,  -1);
	delay_ms(2);
	PULL_UP.Set(FV, 5, FOVI_10V, FOVI_100MA, RELAY_ON);
	FOVI30.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	FOVI29.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	FOVI28.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	FOVI31.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	delay_ms(3);

	FPVI3.Set(FV, 5.0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(5);

	double test_sample = 50;
	double test_cycle = 20;//us
	DWORD Reg_Address = 0x01;
	UART_CH.Connect();
	delay_ms(5);

	//double j = 0;
	//for (j = 1.45; j < 2.06; j = j + 10 * 1E3)
	//{
	UART_CH.SetVIH(1.45);
	//UART_CH.SetVIH(j);
	UART_CH.SetVIL(0.0);
	delay_ms(5);
	for (i = 0; i < SITENUM; i++)
	{
		UART_trans.UART16_Read_Data_Single_Mode(UART_CH, Read_Init, DevID_VOL, Reg_Address);
		delay_ms(5);
		//adresult[i] = UART_trans.Get16_Data_Single_Mode(UART_CH, SITE_1);

		//if (adresult[i] == 0x10)
		//{
		//	adresult2[i] = j;
		RX_H_BEF->SetTestResult(i, 0, UART_trans.Get16_Data_Single_Mode(UART_CH, SITE_1));
		//break;

		//}
	}
	//}

	UART_CH.SetVIH(2.06);
	delay_ms(5);
	for (i = 0; i < SITENUM; i++)
	{
		UART_trans.UART16_Read_Data_Single_Mode(UART_CH, Read_Init, DevID_VOL, Reg_Address);
		delay_ms(5);
		//adresult[i] = UART_trans.Get16_Data_Single_Mode(UART_CH, SITE_1);

		//if (adresult[i] == 0x10)
		//{
		//	adresult2[i] = j;
		RX_H_AFT->SetTestResult(i, 0, UART_trans.Get16_Data_Single_Mode(UART_CH, SITE_1));
		//break;

		//}
	}


	UART_CH.Disconnect();
	delay_ms(5);


	UART_CH.SetVIH(3.3);
	UART_CH.SetVIL(0.0);


	/////////////////////////////////////////////////////////////////
	//VDD=5V��RX�ĵ͵�ƽΪ1.35V����ȡ�Ĵ���0x01��Ϊ00����
	//����RX�ĵ͵�ƽΪ0.65V����ȡ�Ĵ���0x01�Ƿ�Ϊ10��
	//��¼��ʱ��Ӧ��RX�ĵ͵�ƽΪVIL  VIL<0.65V
	Reg_Address = 0x01;
	UART_CH.Connect();
	delay_ms(5);

	//double j = 0;
	//for (j = 1.45; j < 2.06; j = j + 10 * 1E3)
	//{
	UART_CH.SetVIH(5);
	UART_CH.SetVIL(1.7);
	//UART_CH.SetVIH(j);
	//UART_CH.SetVIL(0.0);
	delay_ms(10);
	for (i = 0; i < SITENUM; i++)
	{
		UART_trans.UART16_Read_Data_Single_Mode(UART_CH, Read_Init, DevID_VOL, Reg_Address);
		delay_ms(5);
		//adresult[i] = UART_trans.Get16_Data_Single_Mode(UART_CH, SITE_1);

		//if (adresult[i] == 0x10)
		//{
		//	adresult2[i] = j;
		RX_L_BEF->SetTestResult(i, 0, UART_trans.Get16_Data_Single_Mode(UART_CH, SITE_1));
		//break;

		//}
	}
	//}

	UART_CH.SetVIH(5);
	UART_CH.SetVIL(0.65);
	delay_ms(50);
	for (i = 0; i < SITENUM; i++)
	{
		UART_trans.UART16_Read_Data_Single_Mode(UART_CH, Read_Init, DevID_VOL, Reg_Address);
		delay_ms(5);
		//adresult[i] = UART_trans.Get16_Data_Single_Mode(UART_CH, SITE_1);

		//if (adresult[i] == 0x10)
		//{
		//	adresult2[i] = j;
		RX_L_AFT->SetTestResult(i, 0, UART_trans.Get16_Data_Single_Mode(UART_CH, SITE_1));
		//break;

		//}
	}


	UART_CH.Disconnect();
	delay_ms(5);


	UART_CH.SetVIH(3.3);
	UART_CH.SetVIL(0.0);
	delay_ms(2);
	FPVI3.Set(FV, 0.0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	PULL_UP.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	CBIT.SetOn(-1);
	delay_ms(2);
	FPVI3.Set(FV, 0.0, FPVI10_10V, FPVI10_10MA, RELAY_OFF);
	PULL_UP.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);
	FOVI30.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	FOVI29.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	FOVI28.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	FOVI31.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	delay_ms(3);

    return 0;
}


DUT_API int R_SYNC(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *VSYNC_OH_HS = StsGetParam(funcindex,"VSYNC_OH_HS");
    CParam *VSYNC_OL_HS = StsGetParam(funcindex,"VSYNC_OL_HS");
    CParam *VSYNC_OH_LS = StsGetParam(funcindex,"VSYNC_OH_LS");
    CParam *VSYNC_OL_LS = StsGetParam(funcindex,"VSYNC_OL_LS");
    CParam *R_OH_HS = StsGetParam(funcindex,"R_OH_HS");
    CParam *R_OL_HS = StsGetParam(funcindex,"R_OL_HS");
    CParam *R_OH_LS = StsGetParam(funcindex,"R_OH_LS");
    CParam *R_OL_LS = StsGetParam(funcindex,"R_OL_LS");
    //}}AFX_STS_PARAM_PROTOTYPES

 //   // TODO: Add your function code here
	//�������ΪOSC�����޵�֮��
	/////////////////////////////////////////////////////////////////////////////////
	//VDD=5V�����üĴ���0x01=0C��SYNC strength=1��SYNC output en=1��SYNC pulse en=0����
	//��SYNC�˿ڹ����2mA����Դ5V��������pin����
	//��¼SYNC�˿ڵ�ѹΪV2��ROH-HS=V2/2mA       75��<ROH - HS<119��
	CBIT.SetOn(K99, K100,  -1);
	delay_ms(2);
	PULL_UP.Set(FV, 5, FOVI_10V, FOVI_100MA, RELAY_ON);
	FOVI30.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	FOVI29.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	FOVI28.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	FOVI31.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	delay_ms(3);

	FPVI3.Set(FV, 5.0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(5);

	double test_sample = 50;
	double test_cycle = 20;//us
	DWORD Reg_Address = 0x01;
	DWORD DATA = 0x0E;
	UART_CH.Connect();
	delay_ms(5);
	UART_trans.UART16_Write_Data_Single_Mode(UART_CH, Write_Init, DevID_VOL, Reg_Address, DATA);
	//delay_ms(2);
	//UART_trans.UART16_Write_Data_Single_Mode(UART_CH, Write_Init, DevID_VOL, Reg_Address, DATA);
	//delay_ms(2);
	//UART_trans.UART16_Read_Data_Single_Mode(UART_CH, Read_Init, DevID_VOL, Reg_Address);
	delay_ms(5);
	SYNC1.Set(FI, -2E-3, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	delay_ms(20);

	SYNC1.MeasureVI(2000, 10);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = 5-SYNC1.GetMeasResult(i, MVRET, MAX_RESULT);
		VSYNC_OH_HS->SetTestResult(i, 0, adresult[i]);
		R_OH_HS->SetTestResult(i, 0, adresult[i]/2E-3);
	}
	SYNC1.Set(FI, 0E-3, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);

	/////////////////////////////////////////////////////////////////////////////////
	//VDD=5V�����üĴ���0x01=04��SYNC strength=0��SYNC output en=1��SYNC pulse en=0����
	//��SYNC�˿ڹ����2mA����Դ5V��������pin���գ�
	//��¼SYNC�˿ڵ�ѹΪV1��ROH-LS=V1/2mA      452��<ROH - LS<714��
	Reg_Address = 0x01;
	DATA = 0x06;
	UART_trans.UART16_Write_Data_Single_Mode(UART_CH, Write_Init, DevID_VOL, Reg_Address, DATA);
	//delay_ms(2);
	//UART_trans.UART16_Write_Data_Single_Mode(UART_CH, Write_Init, DevID_VOL, Reg_Address, DATA);
	//delay_ms(2);
	//UART_trans.UART16_Read_Data_Single_Mode(UART_CH, Read_Init, DevID_VOL, Reg_Address);
	delay_ms(5);
	SYNC1.Set(FI, -2E-3, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);

	SYNC1.MeasureVI(200, 20);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = 5 - SYNC1.GetMeasResult(i, MVRET, MAX_RESULT);
		VSYNC_OH_LS->SetTestResult(i, 0, adresult[i]);
		R_OH_LS->SetTestResult(i, 0, adresult[i] / 2E-3);
	}

	SYNC1.Set(FI, 0E-3, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);


	/////////////////////////////////////////////////////////////////////////////////
	//VDD=5V�����üĴ���0x01=0e��SYNC strength=1��SYNC output en=1��SYNC pulse en=1����
	//��SYNC�˿ڳ����2mA������pin���գ�
	//��¼SYNC�˿ڵ�ѹΪV4��ROL-HS=2*V4/2mA      71��<ROL - HS<109��
	Reg_Address = 0x01;
	DATA = 0x0E;
	//UART_trans.UART16_Write_Data_Single_Mode(UART_CH, Write_Init, DevID_VOL, 0x82, 0xFF);
	//delay_ms(2);
	UART_trans.UART16_Write_Data_Single_Mode(UART_CH, Write_Init, DevID_VOL, Reg_Address, DATA);
	delay_ms(2);
	//UART_trans.UART16_Write_Data_Single_Mode(UART_CH, Write_Init, DevID_VOL, Reg_Address, DATA);
	//delay_ms(2);
	//UART_trans.UART16_Read_Data_Single_Mode(UART_CH, Read_Init, DevID_VOL, Reg_Address);
	//delay_ms(5);
	SYNC1.Set(FI, 2E-3, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);

	SYNC1.MeasureVI(200, 20);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = SYNC1.GetMeasResult(i, MVRET, MIN_RESULT);
		VSYNC_OL_HS->SetTestResult(i, 0, adresult[i]);
		R_OL_HS->SetTestResult(i, 0, adresult[i] / 2E-3);
	}

	SYNC1.Set(FI, 0E-3, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);




	/////////////////////////////////////////////////////////////////////////////////
	//VDD=5V�����üĴ���0x01=06��SYNC strength=0��SYNC output en=1��SYNC pulse en=1����
	//��SYNC�˿ڳ����2mA������pin���գ�
	//��¼SYNC�˿ڵ�ѹΪV3��ROL-LS=2*V3/2mA   423��<ROL - LS<654��
	Reg_Address = 0x01;
	DATA = 0x06;
	UART_trans.UART16_Write_Data_Single_Mode(UART_CH, Write_Init, DevID_VOL, Reg_Address, DATA);
	delay_ms(2);
	//UART_trans.UART16_Write_Data_Single_Mode(UART_CH, Write_Init, DevID_VOL, Reg_Address, DATA);
	//delay_ms(2);
	//UART_trans.UART16_Read_Data_Single_Mode(UART_CH, Read_Init, DevID_VOL, Reg_Address);
	//delay_ms(5);
	SYNC1.Set(FI, 2E-3, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);

	SYNC1.MeasureVI(200, 20);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = SYNC1.GetMeasResult(i, MVRET, MIN_RESULT);
		VSYNC_OL_LS->SetTestResult(i, 0, adresult[i]);
		R_OL_LS->SetTestResult(i, 0, adresult[i] / 2E-3);
	}

	SYNC1.Set(FI, 0E-3, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);

	UART_CH.Disconnect();
	delay_ms(5);
	FPVI3.Set(FV, 0.0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	PULL_UP.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	CBIT.SetOn(-1);
	delay_ms(2);

	SYNC1.Set(FI, 0E-3, FPVI10_5V, FPVI10_100MA, RELAY_OFF);
	delay_ms(2);
	FPVI3.Set(FV, 0.0, FPVI10_10V, FPVI10_10MA, RELAY_OFF);
	PULL_UP.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);
	FOVI30.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	FOVI29.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	FOVI28.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	FOVI31.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	delay_ms(3);

    return 0;
}


DUT_API int ITX_SC_SRC(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *ITX_SC_SRC_HS = StsGetParam(funcindex,"ITX_SC_SRC_HS");
    CParam *ITX_SC_SRC_LS = StsGetParam(funcindex,"ITX_SC_SRC_LS");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	/////////////////////////////////////////////////////////////////////////////////
	//VDD=5V��TX=0������pin���գ�
	//��¼TX�˿ڵ���ΪISC-SRC-HS		50mA<ISC - SRC - HS(62mA)<78.3mA

	double test_sample = 200;
	double test_cycle = 20;//us
	//	FPVI3.Set(FV, 5.0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	//delay_ms(5);
	CBIT.SetOn(K99,K100, -1);
	delay_ms(2);
	PULL_UP.Set(FV, 5, FOVI_10V, FOVI_100MA, RELAY_ON);
	FOVI30.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	FOVI29.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	FOVI28.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	FOVI31.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	delay_ms(3);

	FPVI3.Set(FV, 5.0, FPVI10_10V, FPVI10_100MA, RELAY_ON);

	delay_ms(5);

	DWORD DATA = 0x00;
	DWORD Reg_Address = 0x01;
	UART_CH.Connect();
	delay_ms(5);
	//UART_trans.UART16_Read_Data_Single_Mode(UART_CH, Read_Init, DevID_VOL, Reg_Address);
	//delay_ms(5);
	//for (i = 0; i<SITENUM; i++)
	//{
	//	Read_Reg_0x->SetTestResult(i, 0, UART_trans.Get16_Data_Single_Mode(UART_CH, SITE_1));
	//}

	//UART_trans.UART16_Write_Data_Single_Mode(UART_CH, Write_Init, DevID_VOL, Reg_Address, DATA);
	//delay_ms(2);
	UART_trans.UART16_Write_Data_Single_Mode(UART_CH, Write_Init, DevID_VOL, Reg_Address, DATA);
	delay_ms(2);
	UART_trans.UART16_Read_Data_Single_Mode(UART_CH, Read_Init, DevID_VOL, Reg_Address);
	delay_ms(5);

	/////////////////////////////////////////////////////////////////////////////////
	//VDD = 5V��TX = 0�����üĴ���0x01 = 00��TX strength = 0��������pin���գ�
	//��¼TX�˿ڵ���ΪISC - SRC - LS		7.65mA<ISC - SRC - LS(9.62mA)<12.2mA
	//CBIT.SetOn(K99, K100, -1);
	//delay_ms(2);
	//PULL_UP.Set(FV, 5, FOVI_10V, FOVI_100MA, RELAY_ON);
	//FOVI30.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	//FOVI29.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	//FOVI28.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	//FOVI31.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	//delay_ms(3);

	//DWORD Reg_Address = 0x01;
	//DWORD DATA = 0x01;
	//UART_CH.Connect();
	//delay_ms(5);
	//UART_trans.UART16_Write_Data_Single_Mode(UART_CH, Write_Init, DevID_VOL, Reg_Address, DATA);
	//delay_ms(2);
	//UART_trans.UART16_Read_Data_Single_Mode(UART_CH, Read_Init, DevID_VOL, Reg_Address);
	//delay_ms(5);
	for (i = 0; i<SITENUM; i++)
	{

		ITX_SC_SRC_LS->SetTestResult(i, 1, UART_trans.Get16_Data_Single_Mode(UART_CH, SITE_1));
	}
	CBIT.SetOn( -1);
	delay_ms(2);
	FOVI27.Set(FV, 0, FOVI_1V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	FOVI27.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FOVI27.GetMeasResult(i, MIRET);
		ITX_SC_SRC_LS->SetTestResult(i, 0, -adresult[i] * 1E3);
		//ITX_SC_SRC_LS->SetTestResult(i, 1, adresult[i] * 1E3);
	}
	UART_CH.Disconnect();
	delay_ms(5);


	FPVI3.Set(FV, 0.0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(5);
	FPVI3.Set(FV, 5.0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(5);
	FOVI27.Set(FV, 0, FOVI_1V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	FOVI27.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FOVI27.GetMeasResult(i, MIRET);
		ITX_SC_SRC_HS->SetTestResult(i, 0, -adresult[i] * 1E3);
	}
	FOVI27.Set(FV, 0, FOVI_1V, FOVI_100MA, RELAY_OFF);
	delay_ms(5);


	FPVI3.Set(FV, 0.0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	PULL_UP.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	CBIT.SetOn(-1);
	delay_ms(2);

	FOVI27.Set(FV, 0, FOVI_1V, FOVI_100MA, RELAY_OFF);
	FPVI3.Set(FV, 0.0, FPVI10_10V, FPVI10_10MA, RELAY_OFF);
	PULL_UP.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);
	FOVI30.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	FOVI29.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	FOVI28.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	FOVI31.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	delay_ms(3);

    return 0;
}


DUT_API int RES_10A(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *V_SYNC = StsGetParam(funcindex,"V_SYNC");
    CParam *R_SYNC = StsGetParam(funcindex,"R_SYNC");
    CParam *V_RX = StsGetParam(funcindex,"V_RX");
    CParam *R_RX = StsGetParam(funcindex,"R_RX");
    CParam *V_TX = StsGetParam(funcindex,"V_TX");
    CParam *R_TX = StsGetParam(funcindex,"R_TX");
    CParam *V_CLK_L = StsGetParam(funcindex,"V_CLK_L");
    CParam *R_CLK_L = StsGetParam(funcindex,"R_CLK_L");
    CParam *V_CLK_H = StsGetParam(funcindex,"V_CLK_H");
    CParam *R_CLK_H = StsGetParam(funcindex,"R_CLK_H");
    CParam *V_VDDK = StsGetParam(funcindex,"V_VDDK");
    CParam *R_VDDK = StsGetParam(funcindex,"R_VDDK");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	double test_sample = 200;
	double test_cycle = 20;//us

	//��-������ѹ///////////////////////////////////////////////////////////////////////////////////
	//SYNC1=0��SYNC2=5V������pin���գ���¼SYNC2���������I1��RSYNC12=5/I1           2��<RSYNC12(6��)<20��
	CBIT.SetOn(K105, -1);
	delay_ms(2);

	SYNC1.Set(FI, -100E-3, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(2);

	SYNC1.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = SYNC1.GetMeasResult(i, MVRET);
		V_SYNC->SetTestResult(i, 0, adresult[i]);
		R_SYNC->SetTestResult(i, 0, adresult[i]/-100E-3);
	}

	SYNC1.Set(FI, 0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(2);
	SYNC1.Set(FI, 0, FPVI10_10V, FPVI10_1A, RELAY_OFF);
	delay_ms(2);

	//RX1 = 0��RX2 = 5V������pin���գ���¼RX2���������I2           2��<RRX12(6��)<20��
	CBIT.SetOn(K101, K102, K103, K104, -1);
	delay_ms(2);

	FOVI26.Set(FI, -50E-3, FOVI_2V, FOVI_100MA, RELAY_ON);
	delay_ms(2);

	FOVI26.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FOVI26.GetMeasResult(i, MVRET);
		V_RX->SetTestResult(i, 0, adresult[i]);
		R_RX->SetTestResult(i, 0, adresult[i] / -50E-3);
	}

	FOVI26.Set(FI, 0, FOVI_2V, FOVI_100MA, RELAY_ON);
	delay_ms(2);
	FOVI26.Set(FI, 0, FOVI_2V, FOVI_100MA, RELAY_OFF);
	delay_ms(2);
		
	//TX1 = 0��TX2 = 5V������pin���գ���¼TX2���������I3			2��<RTX12(6��)<20��
	//CBIT.SetOn(K101, K102, K103, K104, -1);
	//delay_ms(2);

	FOVI27.Set(FI, -50E-3, FOVI_2V, FOVI_100MA, RELAY_ON);
	delay_ms(2);

	FOVI27.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FOVI27.GetMeasResult(i, MVRET);
		V_TX->SetTestResult(i, 0, adresult[i]);
		R_TX->SetTestResult(i, 0, adresult[i] / -50E-3);
	}

	FOVI27.Set(FI, 0, FOVI_2V, FOVI_100MA, RELAY_ON);
	delay_ms(2);
	FOVI27.Set(FI, 0, FOVI_2V, FOVI_100MA, RELAY_OFF);
	delay_ms(2);

	//CLK_L1 = 0��CLK_L2 = 5V������pin���գ���¼CLK_L2���������I4    0.5��<RCLK_L12(1.5��)<4��
	//CBIT.SetOn(K101, K102, K103, K104, -1);
	//delay_ms(2);

	FOVI24.Set(FI, -50E-3, FOVI_1V, FOVI_100MA, RELAY_ON);
	delay_ms(2);

	FOVI24.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FOVI24.GetMeasResult(i, MVRET);
		V_CLK_L->SetTestResult(i, 0, adresult[i]);
		R_CLK_L->SetTestResult(i, 0, adresult[i] / -50E-3);
	}

	FOVI24.Set(FI, 0, FOVI_2V, FOVI_100MA, RELAY_ON);
	delay_ms(2);
	FOVI24.Set(FI, 0, FOVI_2V, FOVI_100MA, RELAY_OFF);
	delay_ms(2);

	//CLK_H1 = 0��CLK_H2 = 5V������pin���գ���¼CLK_H2���������I5       0.5��<RCLK_H12(1.5��)<4��
	//CBIT.SetOn(K101,K102,K103,K104, -1);
	//delay_ms(2);

	FOVI25.Set(FI, -50E-3, FOVI_1V, FOVI_100MA, RELAY_ON);
	delay_ms(2);

	FOVI25.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FOVI25.GetMeasResult(i, MVRET);
		V_CLK_H->SetTestResult(i, 0, adresult[i]);
		R_CLK_H->SetTestResult(i, 0, adresult[i] / -50E-3);
	}

	FOVI25.Set(FI, 0, FOVI_2V, FOVI_100MA, RELAY_ON);
	delay_ms(2);
	FOVI25.Set(FI, 0, FOVI_2V, FOVI_100MA, RELAY_OFF);
	delay_ms(2);

	//VDD = 0��VDDK = 5V������pin���գ���¼VDDK���������I6    0.05��<RVDDK(0.2��)<0.5��
	CBIT.SetOn(K10,K11, -1);
	delay_ms(2);

	VDDK.Set(FI, -500E-3, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(10);

	VDDK.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = VDDK.GetMeasResult(i, MVRET);
		V_VDDK->SetTestResult(i, 0, adresult[i]);
		R_VDDK->SetTestResult(i, 0, adresult[i] / -500E-3);
	}

	VDDK.Set(FI, 0, FPVI10_1V, FPVI10_1A, RELAY_ON);
	delay_ms(5);
	VDDK.Set(FI, 0, FPVI10_1V, FPVI10_1A, RELAY_OFF);
	delay_ms(2);

	CBIT.SetOn(-1);
	delay_ms(2);

    return 0;
}


DUT_API int RES_100uA(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *I_ADDR2 = StsGetParam(funcindex,"I_ADDR2");
    CParam *R_ADDR2 = StsGetParam(funcindex,"R_ADDR2");
    CParam *I_ADDR3 = StsGetParam(funcindex,"I_ADDR3");
    CParam *R_ADDR3 = StsGetParam(funcindex,"R_ADDR3");
    CParam *I_FS = StsGetParam(funcindex,"I_FS");
    CParam *R_FS = StsGetParam(funcindex,"R_FS");
    CParam *I_SYNC_5V = StsGetParam(funcindex,"I_SYNC_5V");
    CParam *R_SYNC_5V = StsGetParam(funcindex,"R_SYNC_5V");
    CParam *I_CLK_L_5V = StsGetParam(funcindex,"I_CLK_L_5V");
    CParam *R_CLK_L_5V = StsGetParam(funcindex,"R_CLK_L_5V");
    CParam *I_CLK_H_5V = StsGetParam(funcindex,"I_CLK_H_5V");
    CParam *R_CLK_H_5V = StsGetParam(funcindex,"R_CLK_H_5V");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	double test_sample = 200;
	double test_cycle = 20;//us

	//ADDR2=0��VDD=5V������pin���գ���¼ADDR2����������I7     160k��<RADDR2(200k��)<240k��
	//CBIT.SetOn(K12,-1);
	//delay_ms(2);
	FPVI3.Set(FV, 5, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);
	FOVI29.Set(FV, 0, FOVI_10V, FOVI_100UA, RELAY_ON);
	delay_ms(2);

	FOVI29.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = -FOVI29.GetMeasResult(i, MIRET);
		I_ADDR2->SetTestResult(i, 0, adresult[i]*1E6);
		R_ADDR2->SetTestResult(i, 0, 5/adresult[i]/1E3  );
	}

	//FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	//delay_ms(2);
	FOVI29.Set(FV, 0, FOVI_10V, FOVI_100UA, RELAY_OFF);
	delay_ms(2);

	//ADDR3 = 0��VDD = 5V������pin���գ���¼ADDR3����������I8      160k��<RADDR2(200k��)<240k��
	//CBIT.SetOn(K12, K14, -1);
	//delay_ms(2);
	//FPVI3.Set(FV, -5, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	//delay_ms(2);
	FOVI28.Set(FV, 0, FOVI_10V, FOVI_100UA, RELAY_ON);
	delay_ms(2);

	FOVI28.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = -FOVI28.GetMeasResult(i, MIRET);
		I_ADDR3->SetTestResult(i, 0, adresult[i] * 1E6);
		R_ADDR3->SetTestResult(i, 0, 5/adresult[i]/ 1E3);
	}

	FOVI28.Set(FV, 0, FOVI_10V, FOVI_100UA, RELAY_OFF);
	delay_ms(2);
	//FPVI3.Set(FI, 0, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	//delay_ms(2);
	CBIT.SetOn(-1);
	delay_ms(5);

	//RCLK_L = 0��VDD = 5V������pin���գ���¼RCLK_L����������I9   280k��<RCLK_L(350k��)<420k��
	//CBIT.SetOn(K12, K13, -1);
	//delay_ms(2);
	//FPVI3.Set(FV, 5, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	//delay_ms(2);
	FOVI24.Set(FV, 0, FOVI_10V, FOVI_100UA, RELAY_ON);
	delay_ms(2);

	FOVI24.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = -FOVI24.GetMeasResult(i, MIRET);
		I_CLK_L_5V->SetTestResult(i, 0, adresult[i]*1E6);
		R_CLK_L_5V->SetTestResult(i, 0, 5/adresult[i]/ 1E3);
	}

	FOVI24.Set(FV, 0, FOVI_10V, FOVI_100UA, RELAY_OFF);
	delay_ms(2);
	//FPVI3.Set(FI, 0, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	//delay_ms(2);
	//FPVI3.Set(FI, 0, FPVI10_10V, FPVI10_10MA, RELAY_OFF);
	//delay_ms(2);

	//CBIT.SetOn( -1);
	//delay_ms(2);
	//RFS = 5V������pin���գ���¼RFS����������I11    160k��<RFS(200k��)<240k��
	FOVI31.Set(FV, 5, FOVI_10V, FOVI_100UA, RELAY_ON);
	delay_ms(2);

	FOVI31.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FOVI31.GetMeasResult(i, MIRET);
		I_FS->SetTestResult(i, 0, adresult[i]*1E6);
		R_FS->SetTestResult(i, 0, 5 / adresult[i] / 1E3);
	}

	FOVI31.Set(FV, 0, FOVI_10V, FOVI_100UA, RELAY_ON);
	delay_ms(2);
	FOVI31.Set(FV, 0, FOVI_10V, FOVI_100UA, RELAY_OFF);
	delay_ms(2);

	//RSYNC = 5V������pin���գ���¼RSYNC����������I12   400k��<RSYNC(500k��)<600k��
	//FPVI3.Set(FV, 5, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	//delay_ms(2);
	SYNC1.Set(FV, 5, FPVI10_10V, FPVI10_1MA, RELAY_ON);
	delay_ms(20);

	SYNC1.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = SYNC1.GetMeasResult(i, MIRET);
		I_SYNC_5V->SetTestResult(i, 0, adresult[i]*1E6);
		R_SYNC_5V->SetTestResult(i, 0, 5 / adresult[i] / 1E3);
	}

	SYNC1.Set(FV, 0, FPVI10_10V, FPVI10_1MA, RELAY_ON);
	delay_ms(2);
	SYNC1.Set(FV, 0, FPVI10_10V, FPVI10_1MA, RELAY_OFF);
	delay_ms(2);

	//RCLK_H = 5V������pin���գ���¼RCLK_H����������I10   88k��<RCLK_H(110k��)<132k��
	FOVI25.Set(FV, 5, FOVI_10V, FOVI_1MA, RELAY_ON);
	delay_ms(20);

	FOVI25.MeasureVI(test_sample, test_cycle);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = FOVI25.GetMeasResult(i, MIRET);
		I_CLK_H_5V->SetTestResult(i, 0, adresult[i]*1E6);
		R_CLK_H_5V->SetTestResult(i, 0, 5 / adresult[i] / 1E3);
	}

	FOVI25.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	delay_ms(2);
	FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	delay_ms(2);
	FOVI25.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	delay_ms(2);
	FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_10MA, RELAY_OFF);
	delay_ms(2);


    return 0;
}


DUT_API int EEP2(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *READ_0x00 = StsGetParam(funcindex,"READ_0x00");
    CParam *WRITE_NORMAL = StsGetParam(funcindex,"WRITE_NORMAL");
    CParam *WRITE_MTP_4F = StsGetParam(funcindex,"WRITE_MTP_4F");
    CParam *WRITE1_0xFB = StsGetParam(funcindex,"WRITE1_0xFB");
    CParam *READ_VM_4F = StsGetParam(funcindex,"READ_VM_4F");
    CParam *WRITE_MTP_00 = StsGetParam(funcindex,"WRITE_MTP_00");
    CParam *WRITE2_0xFB = StsGetParam(funcindex,"WRITE2_0xFB");
    CParam *READ_VM_00 = StsGetParam(funcindex,"READ_VM_00");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	CBIT.SetOn(K99, K100, K110, -1);
	delay_ms(2);
	PULL_UP.Set(FV, 5, FOVI_10V, FOVI_100MA, RELAY_ON);
	FOVI30.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	FOVI29.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	FOVI28.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	FOVI31.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	delay_ms(3);

	FPVI3.Set(FV, 5.0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(5);

	DWORD DATA = 0x60;
	DWORD Reg_Address = 0x00;
	UART_CH.Connect();
	delay_ms(5);
	UART_trans.UART16_Read_Data_Single_Mode(UART_CH, Read_Init, DevID_VOL, Reg_Address);
	delay_ms(5);
	for (i = 0; i<SITENUM; i++)
	{
		READ_0x00->SetTestResult(i, 0, UART_trans.Get16_Data_Single_Mode(UART_CH, SITE_1));
	}

	DATA = 0x60;
	Reg_Address = 0x00;
	UART_trans.UART16_Write_Data_Single_Mode(UART_CH, Write_Init, DevID_VOL, Reg_Address, DATA);
	delay_ms(2);
//	UART_trans.UART16_Write_Data_Single_Mode(UART_CH, Write_Init, DevID_VOL, Reg_Address, DATA);
	delay_ms(2);
	UART_trans.UART16_Read_Data_Single_Mode(UART_CH, Read_Init, DevID_VOL, Reg_Address);
	delay_ms(2);
	for (i = 0; i<SITENUM; i++)
	{
		READ_0x00->SetTestResult(i, 1, UART_trans.Get16_Data_Single_Mode(UART_CH, SITE_1));
	}

	DATA = 0x4F;
	Reg_Address = 0x00;
	UART_trans.UART16_Write_Data_Single_Mode(UART_CH, Write_Init, DevID_MTP, Reg_Address, DATA);
	delay_ms(2);

	Reg_Address = 0xFB;
	UART_trans.UART16_Write_Data_Single_Mode(UART_CH, 0xAA, DevID_VOL, Reg_Address, 0xCA, 0x23, 0x35, 0x24);
	delay_ms(2);
	delay_ms(500);

	FPVI3.Set(FV, 0.0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(5);
	//////////////////////////////////////////////////////////////////////////////////
	FPVI3.Set(FV, 5.0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(5);

	Reg_Address = 0x00;
	UART_trans.UART16_Read_Data_Single_Mode(UART_CH, Read_Init, DevID_VOL, Reg_Address);
	delay_ms(5);
	for (i = 0; i<SITENUM; i++)
	{
		READ_VM_4F->SetTestResult(i, 0, UART_trans.Get16_Data_Single_Mode(UART_CH, SITE_1));
	}

	DATA = 0x40;
	Reg_Address = 0x00;
	UART_trans.UART16_Write_Data_Single_Mode(UART_CH, Write_Init, DevID_MTP, Reg_Address, DATA);
	delay_ms(2);

	Reg_Address = 0xFB;
	UART_trans.UART16_Write_Data_Single_Mode(UART_CH, 0xAA, DevID_VOL, Reg_Address, 0xCA, 0x23, 0x35, 0x24);
	delay_ms(2);
	delay_ms(500);

	FPVI3.Set(FV, 0.0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(5);
	//////////////////////////////////////////////////////////////////////////////////
	FPVI3.Set(FV, 5.0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(5);

	Reg_Address = 0x00;
	UART_trans.UART16_Read_Data_Single_Mode(UART_CH, Read_Init, DevID_VOL, Reg_Address);
	delay_ms(5);
	for (i = 0; i<SITENUM; i++)
	{
		READ_VM_00->SetTestResult(i, 0, UART_trans.Get16_Data_Single_Mode(UART_CH, SITE_1));
	}

	UART_CH.Disconnect();
	delay_ms(5);
	FPVI3.Set(FV, 0.0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	PULL_UP.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	CBIT.SetOn(-1);
	delay_ms(2);
	FPVI3.Set(FV, 0.0, FPVI10_10V, FPVI10_10MA, RELAY_OFF);
	PULL_UP.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);
	FOVI30.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	FOVI29.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	FOVI28.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	FOVI31.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	delay_ms(3);
    return 0;
}


DUT_API int I_fgwdb(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *V_fgwd_0 = StsGetParam(funcindex,"V_fgwd_0");
    CParam *V_fgwdb_0 = StsGetParam(funcindex,"V_fgwdb_0");
    CParam *I_fgwd_0 = StsGetParam(funcindex,"I_fgwd_0");
    CParam *I_fgwdb_0 = StsGetParam(funcindex,"I_fgwdb_0");
    CParam *V_fgwd_1 = StsGetParam(funcindex,"V_fgwd_1");
    CParam *V_fgwdb_1 = StsGetParam(funcindex,"V_fgwdb_1");
    CParam *I_fgwd_1 = StsGetParam(funcindex,"I_fgwd_1");
    CParam *I_fgwdb_1 = StsGetParam(funcindex,"I_fgwdb_1");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	//VDD=5V��cs pin ��10k���赽�أ�TMNC4��gnd��
	//д��AA 20 FB CA 23 35 24 31 E7������EEP��¼״̬����200ms����¼����������TM6��TM7�ֱ��¼CS�ϵĵ�ѹ
	double test_sample = 50;
	double test_cycle = 20;//us

	CBIT.SetOn(K3, K99, K100,  -1);
	delay_ms(2);
	PULL_UP.Set(FV, 5, FOVI_10V, FOVI_100MA, RELAY_ON);
	FOVI30.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	FOVI29.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	FOVI28.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	FOVI31.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_ON);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	FPVI3.Set(FV, 5.3, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(5);
	NC4.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	DWORD DATA = 0x60;
	DWORD Reg_Address = 0x00;
	UART_CH.Connect();
	delay_ms(5);
	Reg_Address = 0xFB;
	UART_trans.UART16_Write_Data_Single_Mode(UART_CH, 0xAA, DevID_VOL, Reg_Address, 0xCA, 0x23, 0x35, 0x24);
	delay_ms(2);
	delay_ms(300);
	//����TM
	NC4.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	////////////////////MODE1/////////////////////////////
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	//NC5.MeasureVI(200, 10);
	//CS_NC3.Set(FI, 0, FOVI_2V, FOVI_1MA, RELAY_SENSE_ON);
	//delay_ms(2);
	////����ģʽ1���룬��CS��ѹ��û��1.5V
	//CS_NC3.MeasureVI(200, 10);
	//for (i = 0; i<SITENUM; i++)
	//{
	//	adresult[i] = CS_NC3.GetMeasResult(i, MVRET);
	//	V_fgwd_0->SetTestResult(i, 1, adresult[i]);
	//}
	//CS_NC3.Set(FI, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	//delay_ms(2);
	//NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	////////////////////MODE2/////////////////////////////
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	////////////////////MODE3/////////////////////////////
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	//
	////����ģʽ2���룬��CS��ѹ��û��464mV
	//CS_NC3.MeasureVI(200, 100);
	//for (i = 0; i<SITENUM; i++)
	//{
	//	adresult[i] = CS_NC3.GetMeasResult(i, MVRET);
	//	VCS_MODE1->SetTestResult(i, 1, adresult[i]);
	//}
	//CS_NC3.Set(FI, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	//delay_ms(2);
	////////////////////MODE4/////////////////////////////
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	////����ģʽ4���룬��CS��ѹ��û��0.352V
	//CS_NC3.Set(FI, 0, FOVI_1V, FOVI_1MA, RELAY_SENSE_ON);
	//delay_ms(2);
	//CS_NC3.MeasureVI(200, 100);
	//for (i = 0; i<SITENUM; i++)
	//{
	//	adresult[i] = CS_NC3.GetMeasResult(i, MVRET);
	//	VCS_MODE1->SetTestResult(i, 2, adresult[i]);
	//}
	//CS_NC3.Set(FI, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	//delay_ms(2);
	////////////////////MODE5/////////////////////////////
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	////////////////////MODE6/////////////////////////////
	//��¼CS�ϵĵ�ѹ
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	CS_NC3.Set(FI, 0, FOVI_1V, FOVI_1MA, RELAY_SENSE_ON);
	delay_ms(2);
	CS_NC3.MeasureVI(200, 100);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = CS_NC3.GetMeasResult(i, MVRET);
		V_fgwd_0->SetTestResult(i, 0, adresult[i]);
		I_fgwd_0->SetTestResult(i, 0, adresult[i]/10e3*1e6);
	}
	CS_NC3.Set(FI, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(2);
	////////////////////MODE7/////////////////////////////
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	CS_NC3.Set(FI, 0, FOVI_1V, FOVI_1MA, RELAY_SENSE_ON);
	delay_ms(2);
	CS_NC3.MeasureVI(200, 100);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = CS_NC3.GetMeasResult(i, MVRET);
		V_fgwdb_0->SetTestResult(i, 0, adresult[i]);
		I_fgwdb_0->SetTestResult(i, 0, adresult[i] / 10e3*1e6);
	}
	CS_NC3.Set(FI, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(2);
	//////////////////////MODE8/////////////////////////////
	//NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//////////////////////MODE9/////////////////////////////
	//NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//////////////////////MODE10/////////////////////////////
	//NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//////////////////////MODE11/////////////////////////////
	//NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//////////////////////MODE12/////////////////////////////
	//NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//////////////////////MODE13/////////////////////////////
	//NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//////////////////////MODE14/////////////////////////////
	//NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//////////////////////MODE15/////////////////////////////
	//NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//////////////////////MODE16/////////////////////////////
	//NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);

	//////////////////////MODE17/////////////////////////////
	//NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//////////////////////MODE18/////////////////////////////
	//NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	////NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	////delay_ms(5);
	////NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	////delay_ms(5);
	NC4.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	UART_CH.Disconnect();
	delay_ms(5);
	FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	NC4.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_OFF);
	delay_ms(10);
	FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_100MA, RELAY_OFF);
	delay_ms(10);

	////////////////////////////////////////////////////////////////////////////////////////////////
	//�����µ���ϵ磬TMNC4�Ӵ���12V�ĵ�ѹ��д��AA 20 FB CA 23 35 24 31 E7������EEP��¼״̬��
	//��200ms����¼����������TM6��TM7�ֱ��¼CS�ϵĵ�ѹ
	FPVI3.Set(FV, 5.3, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(5);
	NC4.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	UART_CH.Connect();
	delay_ms(5);
	//NC4.MeasureVI(200, 100);
	Reg_Address = 0xFB;
	UART_trans.UART16_Write_Data_Single_Mode(UART_CH, 0xAA, DevID_VOL, Reg_Address, 0xCA, 0x23, 0x35, 0x24);
	delay_ms(2);
	delay_ms(300);
	//����TM
	//NC4.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	////////////////////MODE1/////////////////////////////
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	//NC5.MeasureVI(200, 10);
	//CS_NC3.Set(FI, 0, FOVI_2V, FOVI_1MA, RELAY_SENSE_ON);
	//delay_ms(2);
	////����ģʽ1���룬��CS��ѹ��û��1.5V
	//CS_NC3.MeasureVI(200, 10);
	//for (i = 0; i<SITENUM; i++)
	//{
	//	adresult[i] = CS_NC3.GetMeasResult(i, MVRET);
	//	VCS_MODE1->SetTestResult(i, 0, adresult[i]);
	//}
	//CS_NC3.Set(FI, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	//delay_ms(2);
	//NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	////////////////////MODE2/////////////////////////////
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	////////////////////MODE3/////////////////////////////
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	//
	////����ģʽ2���룬��CS��ѹ��û��464mV
	//CS_NC3.MeasureVI(200, 100);
	//for (i = 0; i<SITENUM; i++)
	//{
	//	adresult[i] = CS_NC3.GetMeasResult(i, MVRET);
	//	VCS_MODE1->SetTestResult(i, 1, adresult[i]);
	//}
	//CS_NC3.Set(FI, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	//delay_ms(2);
	////////////////////MODE4/////////////////////////////
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	////����ģʽ4���룬��CS��ѹ��û��0.352V
	//CS_NC3.Set(FI, 0, FOVI_1V, FOVI_1MA, RELAY_SENSE_ON);
	//delay_ms(2);
	//CS_NC3.MeasureVI(200, 100);
	//for (i = 0; i<SITENUM; i++)
	//{
	//	adresult[i] = CS_NC3.GetMeasResult(i, MVRET);
	//	VCS_MODE1->SetTestResult(i, 2, adresult[i]);
	//}
	//CS_NC3.Set(FI, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	//delay_ms(2);
	////////////////////MODE5/////////////////////////////
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	////////////////////MODE6/////////////////////////////
	//��¼CS�ϵĵ�ѹ
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	CS_NC3.Set(FI, 0, FOVI_1V, FOVI_1MA, RELAY_SENSE_ON);
	delay_ms(2);
	CS_NC3.MeasureVI(200, 100);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = CS_NC3.GetMeasResult(i, MVRET);
		V_fgwd_1->SetTestResult(i, 0, adresult[i]);
		I_fgwd_1->SetTestResult(i, 0, adresult[i] / 10e3*1e6);
	}
	CS_NC3.Set(FI, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(2);
	////////////////////MODE7/////////////////////////////
	NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	CS_NC3.Set(FI, 0, FOVI_1V, FOVI_1MA, RELAY_SENSE_ON);
	delay_ms(2);
	CS_NC3.MeasureVI(200, 100);
	for (i = 0; i<SITENUM; i++)
	{
		adresult[i] = CS_NC3.GetMeasResult(i, MVRET);
		V_fgwdb_1->SetTestResult(i, 0, adresult[i]);
		I_fgwdb_1->SetTestResult(i, 0, adresult[i] / 10e3*1e6);
	}
	CS_NC3.Set(FI, 0, FOVI_2V, FOVI_1MA, RELAY_OFF);
	delay_ms(2);
	//////////////////////MODE8/////////////////////////////
	//NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//////////////////////MODE9/////////////////////////////
	//NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//////////////////////MODE10/////////////////////////////
	//NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//////////////////////MODE11/////////////////////////////
	//NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//////////////////////MODE12/////////////////////////////
	//NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//////////////////////MODE13/////////////////////////////
	//NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//////////////////////MODE14/////////////////////////////
	//NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//////////////////////MODE15/////////////////////////////
	//NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//////////////////////MODE16/////////////////////////////
	//NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);

	//////////////////////MODE17/////////////////////////////
	//NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//////////////////////MODE18/////////////////////////////
	//NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	//NC5.Set(FV, 15, FOVI_20V, FOVI_100MA, RELAY_ON);
	//delay_ms(5);
	NC4.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	UART_CH.Disconnect();
	delay_ms(5);
	FPVI3.Set(FV, 0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(2);
	PULL_UP.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	CBIT.SetOn(-1);
	delay_ms(2);
	FPVI3.Set(FV, 0.0, FPVI10_10V, FPVI10_10MA, RELAY_OFF);
	PULL_UP.Set(FV, 0, FOVI_10V, FOVI_100MA, RELAY_OFF);
	FOVI30.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	FOVI29.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	FOVI28.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	FOVI31.Set(FV, 0, FOVI_10V, FOVI_1MA, RELAY_OFF);
	delay_ms(3);
	NC5.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_OFF);
	NC4.Set(FV, 0, FOVI_20V, FOVI_100MA, RELAY_OFF);
	delay_ms(10);


    return 0;
}
